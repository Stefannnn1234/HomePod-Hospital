#!/bin/sh
# audio.cgi -- how sound reaches the speakers on this build, as JSON for the Speaker tab.
# Nicotine has no kernel sound driver: playback is done from user space. This page says so
# plainly instead of listing "missing drivers" as if audio did not work.
printf 'Content-Type: application/json\r\nCache-Control: no-store\r\n\r\n'

esc() { sed 's/\\/\\\\/g; s/"/\\"/g' | awk '{ printf "%s\\n", $0 }'; }
up() { pidof "$1" >/dev/null 2>&1 && echo running || echo "NOT running"; }
daemon=NOT\ running
for d in /proc/[0-9]*; do
	if tr '\0' ' ' 2>/dev/null < $d/cmdline | grep -q "^python3 .*homepod-audio\.py"; then daemon=running; break; fi
done

status=$(cat <<TXT
Sound works on this build, but not through the kernel's sound system (ALSA).

How it plays today (all in user space):
  AirPlay / Bluetooth  ->  PCM pipes in /run/homepod
  hpfeed ($(up hpfeed))  ->  Apple-derived DSP, then written straight into the
                              I2S controller (MCA3) through /dev/mem, 48 kHz, 8 channels
  homepod-audio.py ($daemon)  ->  amplifier board (its own microcontroller) over a serial
                              line: power states, temperatures; the woofer and tweeter
                              amplifiers hang off that microcontroller, not off the SoC

What a kernel driver would add, and what its absence costs:
  - no sound card: programs that expect ALSA / PipeWire cannot play; everything has to
    come in through the two pipes above
  - no DMA: hpfeed fills the hardware buffer by polling, so one of the two CPU cores is
    reserved for it (isolcpus=1) and it runs with real-time priority
  - no capture: the six-microphone array has no driver at all, so no room correction,
    no voice, no echo reference
  - /dev/mem access from user space: fine on a speaker you own, not something to ship
    as a general-purpose system

Not written yet: an MCA (I2S) driver for the T7000 with its DMA controller, a machine
driver that describes the 1 woofer + 7 tweeter layout, and a driver for the microphone
converters. None of it is needed for what the speaker does now.
TXT
)
if [ -f /proc/asound/cards ]; then
	devices=$(cat /proc/asound/cards 2>/dev/null)
else
	devices="None. No ALSA sound card exists on this build (see above); that is expected."
fi
printf '{\n  "status": "%s",\n  "devices": "%s"\n}\n' "$(printf '%s\n' "$status" | esc | sed 's/\\n$//')" "$(printf '%s\n' "$devices" | esc | sed 's/\\n$//')"
