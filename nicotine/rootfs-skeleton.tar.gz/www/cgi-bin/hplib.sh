# hplib.sh -- shared helpers for the HomePod web UI CGIs.
# Sourced by wifi.cgi / speaker.cgi / airplay.cgi / bluetooth.cgi; not a CGI itself.
#
# Rules every CGI here follows:
#  - Requests carry only [A-Za-z0-9_=&.-]. Free text (SSID, password, AirPlay
#    name) travels hex-encoded in both directions, so nothing a user or a
#    neighbour's access point chooses is ever placed unescaped into shell or JSON.
#  - State changes need POST with Content-Type application/x-homepod. A page on
#    another site cannot send that type without a CORS preflight, which
#    busybox httpd does not answer.
#  - Slow work (service start/stop, joining a network) runs detached and the
#    page polls for the outcome.
PATH=/usr/sbin:/usr/bin:/sbin:/bin
export PATH
RUN=/run/homepod
API=http://127.0.0.1:7001
REQ=""

json_head() {
	# CRLF line ends: httpd passes CGI headers through untouched, and strict
	# HTTP clients reject bare LF there.
	printf 'Content-Type: application/json\r\nCache-Control: no-store\r\n\r\n'
}

# stdin -> body of a JSON string (no surrounding quotes). ASCII only: control
# characters become spaces, bytes >= 0x80 become '?', newlines become \n.
jesc() {
	awk 'BEGIN { for (i = 1; i < 256; i++) ord[sprintf("%c", i)] = i }
	{
		if (NR > 1) printf "\\n"
		n = length($0); out = ""
		for (i = 1; i <= n; i++) {
			c = substr($0, i, 1); o = ord[c] + 0
			if (c == "\\") out = out "\\\\"
			else if (c == "\"") out = out "\\\""
			else if (o < 32 || o == 127) out = out " "
			else if (o >= 128) out = out "?"
			else out = out c
		}
		printf "%s", out
	}'
}

tohex() { hexdump -v -e '/1 "%02x"'; }

# hex string (already validated) -> bytes on stdout
unhex() { printf "$(printf '%s' "$1" | sed 's/../\\x&/g')"; }

# hex_bytes_ok HEX MINLEN MAXLEN LOW HIGH "excluded bytes, e.g. 22 5c"
hex_bytes_ok() {
	printf '%s\n' "$1" | awk -v mn="$2" -v mx="$3" -v lo="$4" -v hi="$5" -v ex=" $6 " '
	BEGIN { h = "0123456789abcdef"; rc = 0 }
	NR == 1 {
		L = length($0); n = L / 2
		if (L % 2 || n < mn || n > mx) { rc = 1; exit }
		for (i = 1; i <= L; i += 2) {
			a = index(h, substr($0, i, 1)); b = index(h, substr($0, i + 1, 1))
			if (!a || !b) { rc = 1; exit }
			v = (a - 1) * 16 + b - 1
			if (v < lo || v > hi || index(ex, " " substr($0, i, 2) " ")) { rc = 1; exit }
		}
	}
	END { exit rc }'
}

fail() {
	json_head
	printf '{"ok":false,"error":"%s"}\n' "$(printf '%s' "$1" | jesc)"
	exit 0
}

read_request() {
	if [ "$REQUEST_METHOD" = POST ]; then
		case "$CONTENT_LENGTH" in ''|*[!0-9]*) fail "bad request" ;; esac
		[ "$CONTENT_LENGTH" -le 4096 ] || fail "request too large"
		REQ=$(head -c "$CONTENT_LENGTH")
	else
		REQ=$QUERY_STRING
	fi
	case "$REQ" in *[!A-Za-z0-9_=\&.-]*) fail "bad characters in request" ;; esac
}

param() { printf '&%s&' "$REQ" | sed -n "s/.*&$1=\([^&]*\)&.*/\1/p"; }

need_post() {
	[ "$REQUEST_METHOD" = POST ] || fail "this action needs POST"
	case "$CONTENT_TYPE" in application/x-homepod*) ;; *) fail "wrong content type" ;; esac
}

is_int() { case "$1" in ''|*[!0-9]*|0?*) return 1 ;; esac; [ ${#1} -le 4 ]; }

# One detached job per name at a time. lock_take NAME -> 0 if we own it now.
# A lock older than two minutes belongs to a job that died and is discarded.
lock_take() {
	mkdir -p $RUN
	L=$RUN/ui-$1.lock
	[ -d "$L" ] && [ -n "$(find "$L" -maxdepth 0 -mmin +2 2>/dev/null)" ] && rmdir "$L" 2>/dev/null
	mkdir "$L" 2>/dev/null
}
lock_busy() { [ -d "$RUN/ui-$1.lock" ]; }

# awk helpers shared by the CGIs (prepended to awk programs).
#  js(s)       JSON-escape an ASCII string (same rules as jesc)
#  esc2hex(s)  decode the SSID escaping used by iw (\xNN) and by wpa_cli
#              (\\ \" \e \n \r \t \xNN) into a plain hex string of the raw bytes
AWKLIB='
function hp_init(   i) { for (i = 1; i < 256; i++) ord[sprintf("%c", i)] = i }
function js(s,   out, i, n, c, o) {
	out = ""; n = length(s)
	for (i = 1; i <= n; i++) {
		c = substr(s, i, 1); o = ord[c] + 0
		if (c == "\\") out = out "\\\\"
		else if (c == "\"") out = out "\\\""
		else if (o < 32 || o == 127) out = out " "
		else if (o >= 128) out = out "?"
		else out = out c
	}
	return out
}
function esc2hex(s,   out, i, n, c, d, h) {
	out = ""; n = length(s); i = 1
	while (i <= n) {
		c = substr(s, i, 1)
		if (c == "\\" && i < n) {
			d = substr(s, i + 1, 1)
			if (d == "x") {
				h = tolower(substr(s, i + 2, 2))
				if (h ~ /^[0-9a-f][0-9a-f]$/) { out = out h; i += 4; continue }
			}
			else if (d == "\\") { out = out "5c"; i += 2; continue }
			else if (d == "\"") { out = out "22"; i += 2; continue }
			else if (d == "n") { out = out "0a"; i += 2; continue }
			else if (d == "r") { out = out "0d"; i += 2; continue }
			else if (d == "t") { out = out "09"; i += 2; continue }
			else if (d == "e") { out = out "1b"; i += 2; continue }
		}
		out = out sprintf("%02x", ord[c]); i++
	}
	return out
}
function num(v) { return (v ~ /^-?[0-9]+(\.[0-9]+)?$/) ? v : "null" }
'

# Run "$@" detached from the CGI (httpd waits for every holder of the CGI's
# stdout, so the job must not inherit it). Result goes to $RUN/ui-NAME.result.
bg_job() {
	name=$1; shift
	(
		trap '' HUP
		"$@" > $RUN/ui-$name.out 2>&1
		rc=$?
		printf 'rc=%s\ncmd=%s\n' "$rc" "$*" > $RUN/ui-$name.result
		rmdir $RUN/ui-$name.lock 2>/dev/null
	) </dev/null >/dev/null 2>&1 &
}

# last line of a job's output, JSON-escaped; rc of the last job or null
job_json() {
	rc=$(sed -n 's/^rc=\([0-9]*\)$/\1/p' $RUN/ui-$1.result 2>/dev/null | head -1)
	cmd=$(sed -n 's/^cmd=//p' $RUN/ui-$1.result 2>/dev/null | head -1 | jesc)
	msg=$(tail -n 1 $RUN/ui-$1.out 2>/dev/null | cut -c1-200 | jesc)
	if lock_busy "$1"; then b=true; else b=false; fi
	printf '"busy":%s,"last_rc":%s,"last_cmd":"%s","last_msg":"%s"' "$b" "${rc:-null}" "$cmd" "$msg"
}
