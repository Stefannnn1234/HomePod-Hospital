#!/bin/sh
# exec.cgi -- run one command as root and return its output (the Terminal tab).
#   POST cmd=<hex of the command line>     Content-Type: application/x-homepod
# There is still no login: anyone who can reach this page can run commands. What changed in
# build 108 is that the request can no longer be made by another web site through your
# browser: it needs POST with a content type a foreign page cannot send (see hplib.sh).
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"

read_request
need_post
HEX=$(param cmd)
hex_bytes_ok "$HEX" 1 2000 9 126 "" || fail "command must be 1 to 2000 printable characters"
CMD=$(unhex "$HEX")

# not a security boundary, just a guard against the classic slip
case "$CMD" in
*rm\ -rf\ /*) fail "blocked: destructive command on the root filesystem" ;;
esac

cd /
OUT=$(timeout 5 sh -c "$CMD" 2>&1 | head -c 200000 | tohex)
json_head
printf '{"ok":true,"output_hex":"%s"}\n' "$OUT"
