#!/bin/sh
# wifi.cgi -- WiFi panel backend.
#   GET  ?action=status               current link + state of the last join
#   POST action=scan                  scan (about 6 s), networks sorted by signal
#   POST action=join&ssid=HEX[&psk=HEX]   join in the background, with rollback
#   POST action=forget&id=N&ssid=HEX[&confirm=current]
#                                     remove a saved network (wpa_cli remove_network
#                                     + save_config). The network in use needs
#                                     confirm=current and is removed 2 s after the
#                                     answer has gone out, so the page gets it.
# SSID and passphrase are hex strings of their raw bytes. A join only changes
# the running wpa_supplicant and its config file in RAM: it is gone after reboot.
# The status also carries the link detail (iw link / station dump), the saved
# networks (wpa_cli list_networks) and the regulatory country (read-only).
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"
IF=wlan0
JR=$RUN/wifi-join.result
CONF=/etc/wpa_supplicant/wpa_supplicant.conf
W() { timeout 4 wpa_cli -i $IF "$@" 2>/dev/null; }

# ---- detached join worker (started by do_join below, never by httpd) ----
join_worker() {
	note() { printf 'state=%s\nssid_hex=%s\ndetail=%s\n' "$1" "$HP_SSID" "$2" > $JR.tmp && mv $JR.tmp $JR; }
	undo() {
		W remove_network "$id" >/dev/null
		W enable_network all >/dev/null
		W reassociate >/dev/null
	}
	note pending "configuring"
	id=$(W add_network | tail -n 1)
	case "$id" in ''|*[!0-9]*) note failed "wpa_supplicant did not accept a new network"; return ;; esac
	ok=1
	[ "$(W set_network "$id" ssid "$HP_SSID")" = OK ] || ok=0
	if [ -n "$HP_PSK" ]; then
		if [ ${#HP_PSK} -eq 128 ]; then
			# 64 hex digits: a raw 256-bit key, passed unquoted
			[ "$(W set_network "$id" psk "$(unhex "$HP_PSK")")" = OK ] || ok=0
		else
			[ "$(W set_network "$id" psk "\"$(unhex "$HP_PSK")\"")" = OK ] || ok=0
		fi
	else
		[ "$(W set_network "$id" key_mgmt NONE)" = OK ] || ok=0
	fi
	W set_network "$id" scan_ssid 1 >/dev/null
	if [ $ok != 1 ]; then undo; note failed "wpa_supplicant rejected the settings"; return; fi
	note pending "connecting"
	W select_network "$id" >/dev/null
	i=0
	while [ $i -lt 25 ]; do
		sleep 1; i=$((i+1))
		st=$(W status)
		case "$st" in *wpa_state=COMPLETED*) ;; *) continue ;; esac
		[ "$(printf '%s\n' "$st" | sed -n 's/^id=//p')" = "$id" ] || continue
		W enable_network all >/dev/null
		W save_config >/dev/null
		note ok "connected"
		return
	done
	undo
	note failed "could not connect within 25 s (wrong password or out of range); went back to the previous network"
}
if [ "$HP_BG" = wifi-join ] && [ -z "$GATEWAY_INTERFACE" ]; then
	join_worker
	rmdir $RUN/ui-wifijoin.lock 2>/dev/null
	exit 0
fi
# ---- detached forget of the network in use (started by do_forget) ----
if [ "$HP_BG" = wifi-forget ] && [ -z "$GATEWAY_INTERFACE" ]; then
	sleep 2
	case "$HP_ID" in ''|*[!0-9]*) ;; *)
		[ "$(W remove_network "$HP_ID")" = OK ] && W save_config >/dev/null ;;
	esac
	rmdir $RUN/ui-wififorget.lock 2>/dev/null
	exit 0
fi

read_request
ACTION=$(param action)

# Everything the status needs, as one stream of "@section" headers and the
# commands' own output, parsed by one awk (few processes: this runs every 5 s).
wifi_dump() {
	echo "@wpa"; W status
	echo "@link"; timeout 3 iw dev $IF link 2>/dev/null </dev/null
	echo "@sta"; timeout 3 iw dev $IF station dump 2>/dev/null </dev/null
	echo "@nets"; W list_networks
	echo "@ip"; timeout 3 ip -4 -o addr show dev $IF 2>/dev/null </dev/null
	echo "@route"; timeout 3 ip -4 route show default 2>/dev/null </dev/null
}

status_fields() {
	[ -d /sys/class/net/$IF ] || { echo '"present":false,"connected":false,"saved":[]'; return; }
	wifi_dump | awk -v conf="$CONF" -v macf="/sys/class/net/$IF/address" "$AWKLIB"'
	function rate(v,   r) { r = v; sub(/[ \t].*/, "", r); return num(r) }
	function mode(v) { sub(/^[0-9.]+[ \t]*MBit\/s[ \t]*/, "", v); return v }
	function val(l,   p) { p = index(l, ":"); l = substr(l, p + 1); sub(/^[ \t]+/, "", l); sub(/[ \t]+$/, "", l); return l }
	BEGIN { hp_init(); sec = ""; nn = 0 }
	/^@[a-z]+$/ { sec = substr($0, 2); next }
	sec == "wpa" { p = index($0, "="); if (p > 1) kv[substr($0, 1, p - 1)] = substr($0, p + 1); next }
	sec == "link" || sec == "sta" {
		l = $0; sub(/^[ \t]+/, "", l)
		if (l ~ /^signal:/) { v = val(l); sub(/[^-0-9].*/, "", v); if (lk["signal"] == "") lk["signal"] = v }
		else if (l ~ /^signal avg:/) { v = val(l); sub(/[^-0-9].*/, "", v); lk["signal_avg"] = v }
		else if (l ~ /^rx bitrate:/ && lk["rx"] == "") lk["rx"] = val(l)
		else if (l ~ /^tx bitrate:/ && lk["tx"] == "") lk["tx"] = val(l)
		else if (l ~ /^connected time:/) { v = val(l); sub(/[^0-9].*/, "", v); lk["conn"] = v }
		else if (l ~ /^tx retries:/) { v = val(l); sub(/[^0-9].*/, "", v); lk["retries"] = v }
		else if (l ~ /^tx failed:/) { v = val(l); sub(/[^0-9].*/, "", v); lk["failed"] = v }
		else if (l ~ /^tx packets:/) { v = val(l); sub(/[^0-9].*/, "", v); lk["txp"] = v }
		next
	}
	sec == "nets" {
		# "network id / ssid / bssid / flags" header, then id<TAB>ssid<TAB>bssid<TAB>flags
		n = split($0, f, "\t")
		if (n < 3 || f[1] !~ /^[0-9]+$/) next
		ssid = f[2]; for (i = 3; i < n - 1; i++) ssid = ssid "\t" f[i]
		fl = (n >= 4) ? f[n] : ""
		if (nn < 32) nets[nn++] = sprintf("{\"id\":%d,\"ssid_hex\":\"%s\",\"current\":%s,\"disabled\":%s,\"temp_disabled\":%s}", f[1], esc2hex(ssid),
			index(fl, "[CURRENT]") ? "true" : "false", index(fl, "[DISABLED]") ? "true" : "false", index(fl, "[TEMP-DISABLED]") ? "true" : "false")
		next
	}
	sec == "ip" && $3 == "inet" && ip == "" { ip = $4; next }
	sec == "route" && $1 == "default" && gw == "" { for (i = 2; i < NF; i++) if ($i == "via") gw = $(i + 1); next }
	END {
		mac = ""; if ((getline mac < macf) <= 0) mac = ""
		country = ""
		while ((getline l < conf) > 0) if (l ~ /^country=[A-Z0-9][A-Z0-9]$/) country = substr(l, 9, 2)
		w = ""; m = lk["rx"] " " lk["tx"]
		if (match(m, /[0-9]+MHz/)) w = substr(m, RSTART, RLENGTH - 3)
		gen = (m ~ /EHT-MCS/) ? 7 : (m ~ /HE-MCS/) ? 6 : (m ~ /VHT-MCS/) ? 5 : (m ~ /MCS/) ? 4 : (lk["tx"] != "" ? 0 : "null")
		printf "\"present\":true"
		printf ",\"connected\":%s", (kv["wpa_state"] == "COMPLETED") ? "true" : "false"
		printf ",\"wpa_state\":\"%s\"", js(kv["wpa_state"])
		printf ",\"ssid_hex\":\"%s\"", esc2hex(kv["ssid"])
		printf ",\"bssid\":\"%s\"", js(kv["bssid"])
		printf ",\"network_id\":%s", num(kv["id"])
		printf ",\"freq\":%s", num(kv["freq"])
		printf ",\"key_mgmt\":\"%s\"", js(kv["key_mgmt"])
		printf ",\"signal_dbm\":%s", num(lk["signal"])
		printf ",\"signal_avg_dbm\":%s", num(lk["signal_avg"])
		printf ",\"rx_mbit\":%s,\"tx_mbit\":%s", rate(lk["rx"]), rate(lk["tx"])
		printf ",\"rx_mode\":\"%s\",\"tx_mode\":\"%s\"", js(mode(lk["rx"])), js(mode(lk["tx"]))
		printf ",\"width_mhz\":%s,\"wifi_gen\":%s", num(w), gen
		printf ",\"connected_s\":%s", num(lk["conn"])
		printf ",\"tx_packets\":%s,\"tx_retries\":%s,\"tx_failed\":%s", num(lk["txp"]), num(lk["retries"]), num(lk["failed"])
		sub(/\/.*/, "", ip)
		printf ",\"ip\":\"%s\"", js(ip)
		printf ",\"gateway\":\"%s\"", js(gw)
		printf ",\"mac\":\"%s\"", js(mac)
		printf ",\"country\":\"%s\"", country
		printf ",\"saved\":["
		for (i = 0; i < nn; i++) printf "%s%s", (i ? "," : ""), nets[i]
		printf "]"
	}'
}

join_fields() {
	s=$(sed -n 's/^state=\([a-z]*\)$/\1/p' $JR 2>/dev/null | head -1)
	h=$(sed -n 's/^ssid_hex=\([0-9a-f]*\)$/\1/p' $JR 2>/dev/null | head -1)
	d=$(sed -n 's/^detail=//p' $JR 2>/dev/null | head -1 | jesc)
	# a worker that died leaves "pending" behind; the lock tells the truth
	if [ "$s" = pending ] && ! lock_busy wifijoin; then s=failed; d="join was interrupted"; fi
	printf '"join":{"state":"%s","ssid_hex":"%s","detail":"%s"}' "${s:-none}" "$h" "$d"
}

do_status() {
	F=$(status_fields)
	[ -n "$F" ] || F='"present":false,"connected":false'
	json_head
	printf '{"ok":true,%s,%s}\n' "$F" "$(join_fields)"
}

do_scan() {
	need_post
	lock_busy wifijoin && fail "a join is in progress"
	lock_take wifiscan || fail "a scan is already running"
	T=$RUN/ui-wifiscan.$$
	trap 'rm -f $T; rmdir $RUN/ui-wifiscan.lock 2>/dev/null' EXIT
	# Output goes to a file, not a pipe: if the time limit hits, children of
	# homepod-wifi may live a little longer and a pipe would keep us waiting.
	timeout 9 homepod-wifi scan 5 > $T 2>/dev/null </dev/null
	[ $? -ge 124 ] && fail "the scan took too long, try again"
	N=$(awk -F'\t' "$AWKLIB"'
	BEGIN { hp_init(); n = 0 }
	NF >= 3 && $1 ~ /^-?[0-9]+$/ {
		ssid = $4; for (i = 5; i <= NF; i++) ssid = ssid "\t" $i
		h = esc2hex(ssid)
		hidden = (h == "" || h ~ /^(00)+$/) ? "true" : "false"
		if (length(h) > 64) next
		sec = ($3 == "wpa2" || $3 == "wpa" || $3 == "open") ? $3 : "unknown"
		key = h "|" sec
		if (key in seen) { cnt[seen[key]]++; next }
		if (n >= 60) next
		seen[key] = n; cnt[n] = 1
		row[n] = sprintf("{\"ssid_hex\":\"%s\",\"hidden\":%s,\"signal_dbm\":%d,\"freq\":%s,\"security\":\"%s\"", h, hidden, $1, num($2), sec)
		n++
	}
	END {
		for (i = 0; i < n; i++) printf "%s%s,\"aps\":%d}", (i ? "," : ""), row[i], cnt[i]
	}' $T)
	json_head
	printf '{"ok":true,"networks":[%s]}\n' "$N"
}

do_join() {
	need_post
	SSID=$(param ssid); PSK=$(param psk)
	hex_bytes_ok "$SSID" 1 32 0 255 "" || fail "network name must be 1 to 32 bytes"
	if [ -n "$PSK" ]; then
		if [ ${#PSK} -eq 128 ]; then
			# 64 characters: must be hex digits (raw key)
			hex_bytes_ok "$PSK" 64 64 48 102 "3a 3b 3c 3d 3e 3f 40 47 48 49 4a 4b 4c 4d 4e 4f 50 51 52 53 54 55 56 57 58 59 5a 5b 5c 5d 5e 5f 60" ||
				fail "a 64-character password must be 64 hex digits"
		else
			hex_bytes_ok "$PSK" 8 63 32 126 "" || fail "password must be 8 to 63 printable ASCII characters"
		fi
	fi
	[ "$(W ping)" = PONG ] || fail "wpa_supplicant is not running"
	lock_busy wifiscan && fail "a scan is running, try again in a few seconds"
	lock_take wifijoin || fail "another join is in progress"
	printf 'state=pending\nssid_hex=%s\ndetail=starting\n' "$SSID" > $JR
	# clean environment: the worker must not look like a CGI request
	env -i HP_BG=wifi-join HP_SSID="$SSID" HP_PSK="$PSK" setsid sh "$HERE/wifi.cgi" </dev/null >/dev/null 2>&1 &
	json_head
	echo '{"ok":true,"pending":true}'
}

# one saved network as "id<TAB>ssid_hex<TAB>current(0/1)", from wpa_cli itself
saved_net() {
	W list_networks | awk -F'\t' -v want="$1" "$AWKLIB"'
	BEGIN { hp_init() }
	$1 == want && NF >= 3 {
		ssid = $2; for (i = 3; i < NF - 1; i++) ssid = ssid "\t" $i
		printf "%s\t%s\t%d\n", $1, esc2hex(ssid), index($NF, "[CURRENT]") ? 1 : 0
	}'
}

do_forget() {
	need_post
	ID=$(param id); SSID=$(param ssid); CONFIRM=$(param confirm)
	is_int "$ID" || fail "bad network id"
	hex_bytes_ok "$SSID" 0 32 0 255 "" || fail "bad network name"
	[ "$(W ping)" = PONG ] || fail "wpa_supplicant is not running"
	lock_busy wifijoin && fail "a join is in progress, try again when it has finished"
	lock_busy wififorget && fail "a network is being removed already"
	N=$(saved_net "$ID")
	[ -n "$N" ] || fail "that network is not saved (any more); reload the list"
	H=$(printf '%s\n' "$N" | cut -f2); CUR=$(printf '%s\n' "$N" | cut -f3)
	[ "$H" = "$SSID" ] || fail "the saved networks have changed; reload the list"
	if [ "$CUR" = 1 ]; then
		[ "$CONFIRM" = current ] || fail "this is the network the HomePod is using now; confirm to remove it"
		lock_take wififorget || fail "a network is being removed already"
		env -i HP_BG=wifi-forget HP_ID="$ID" setsid sh "$HERE/wifi.cgi" </dev/null >/dev/null 2>&1 &
		json_head
		echo '{"ok":true,"pending":true,"current":true}'
		return
	fi
	[ "$(W remove_network "$ID")" = OK ] || fail "wpa_supplicant did not remove the network"
	[ "$(W save_config)" = OK ] || fail "removed for now, but the configuration file could not be written"
	json_head
	echo '{"ok":true,"current":false}'
}

case "$ACTION" in
''|status) do_status ;;
scan) do_scan ;;
join) do_join ;;
forget) do_forget ;;
*) fail "unknown action" ;;
esac
