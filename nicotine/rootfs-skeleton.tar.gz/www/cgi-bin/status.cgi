#!/bin/sh
# status.cgi -- Overview panel backend: system status as JSON (GET only).
#
# Cheap on purpose: the Overview tab asks for this every 5 seconds. The old
# version forked about 300 processes per call (several awk/sed/echo pipelines
# per row of the process list); this one forks six (ip under timeout, ps, awk,
# and the shell for the pipe) and reads everything else from /proc inside a
# single awk. The mDNS name comes from avahi over D-Bus and is cached for a
# minute in /run/homepod (one more dbus-send when the cache is stale).
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"

UP=0
read -r UP _ < /proc/uptime 2>/dev/null
UP=${UP%.*}
case "$UP" in ''|*[!0-9]*) UP=0 ;; esac

# The name avahi really announces (it adds "-2" and so on when another device on
# the network already has ours). "-" in the cache means "avahi did not answer".
MD=- MDT=-999
[ -r $RUN/ui-mdns ] && read -r MDT MD < $RUN/ui-mdns
case "$MDT" in ''|*[!0-9-]*) MDT=-999 ;; esac
if [ $((UP - MDT)) -ge 60 ] || [ "$UP" -lt "$MDT" ]; then
	R=$(timeout 2 dbus-send --system --print-reply --dest=org.freedesktop.Avahi / \
		org.freedesktop.Avahi.Server.GetHostNameFqdn 2>/dev/null </dev/null)
	MD=-
	case "$R" in *'string "'*)
		R=${R#*string \"}; R=${R%%\"*}
		case "$R" in ''|*[!A-Za-z0-9.-]*) ;; *) MD=$R ;; esac ;;
	esac
	[ -d $RUN ] && echo "$UP $MD" > $RUN/ui-mdns 2>/dev/null
fi

json_head
{
	timeout 3 ip -4 -o addr show 2>/dev/null
	echo @ps
	ps -o pid,user,rss,comm 2>/dev/null
} </dev/null | awk -v up="$UP" -v mdns="$MD" "$AWKLIB"'
function first(f,   l) { l = ""; if ((getline l < f) <= 0) l = ""; close(f); return l }
function unq(v) { gsub(/^"|"$/, "", v); return v }
BEGIN { hp_init(); na = 0; n = 0; inps = 0 }
$0 == "@ps" { inps = 1; next }
# ps: "  PID USER     RSS  COMMAND"; busybox shortens big sizes to "97.6m"
inps {
	if ($1 !~ /^[0-9]+$/) next
	r = $3; k = 1
	if (r ~ /m$/) k = 1024; else if (r ~ /g$/) k = 1048576
	r = int(r * k)
	if (r <= 0) next			# kernel threads
	c = $4; for (i = 5; i <= NF; i++) c = c " " $i
	P[n] = $1; U[n] = $2; R[n] = r; C[n] = substr(c, 1, 80); n++
	next
}
# ip -o: "3: wlan0    inet 192.168.1.20/24 brd ... scope global wlan0"
$3 == "inet" && $2 != "lo" {
	a = $4; sub(/\/.*/, "", a)
	if (a ~ /^[0-9.]+$/) { ifn[na] = $2; ipa[na] = a; na++ }
}
END {
	# uptime
	d = int(up / 86400); h = int((up % 86400) / 3600); m = int((up % 3600) / 60)
	ut = d > 0 ? d "d " h "h " m "m" : h > 0 ? h "h " m "m" : m "m"

	split(first("/proc/loadavg"), la, " ")
	load = la[1] " " la[2] " " la[3]
	ncpu = 0; cpum = ""
	while ((getline l < "/proc/cpuinfo") > 0) {
		if (l ~ /^processor[ \t]*:/) ncpu++
		else if (cpum == "" && l ~ /^(Hardware|model name)[ \t]*:/) { cpum = l; sub(/^[^:]*:[ \t]*/, "", cpum) }
	}
	close("/proc/cpuinfo")
	if (cpum == "") cpum = "ARM64"
	mt = 0; ma = -1; mf = 0
	while ((getline l < "/proc/meminfo") > 0) {
		split(l, f, /[ \t]+/)
		if (f[1] == "MemTotal:") mt = f[2] + 0
		else if (f[1] == "MemAvailable:") ma = f[2] + 0
		else if (f[1] == "MemFree:") mf = f[2] + 0
	}
	close("/proc/meminfo")
	if (ma < 0) ma = mf
	mu = mt > 0 ? mt - ma : 0

	while ((getline l < "/etc/os-release") > 0) {
		p = index(l, "="); if (p < 2) continue
		osr[substr(l, 1, p - 1)] = unq(substr(l, p + 1))
	}
	close("/etc/os-release")

	host = first("/proc/sys/kernel/hostname"); if (host == "") host = "homepod"
	krel = first("/proc/sys/kernel/osrelease")
	kver = first("/proc/sys/kernel/version")
	model = first("/proc/device-tree/model")	# NUL-terminated: getline stops there
	gsub(/[^ -~]/, "", model)
	if (model == "") model = "Apple HomePod (B238a)"

	# processes: top 15 by resident memory
	procs = ""
	for (k = 0; k < 15 && k < n; k++) {
		b = -1
		for (i = 0; i < n; i++) if (!(i in used) && (b < 0 || R[i] > R[b])) b = i
		used[b] = 1
		procs = procs (k ? "," : "") sprintf("{\"pid\":\"%s\",\"user\":\"%s\",\"rss\":\"%dk\",\"cmd\":\"%s\"}", js(P[b]), js(U[b]), R[b], js(C[b]))
	}

	addrs = ""; wip = ""; uip = ""
	for (i = 0; i < na; i++) {
		addrs = addrs (i ? "," : "") sprintf("{\"ifname\":\"%s\",\"ip\":\"%s\"}", js(ifn[i]), ipa[i])
		if (ifn[i] == "wlan0" && wip == "") wip = ipa[i]
		if (ifn[i] ~ /^usb/ && uip == "") uip = ipa[i]
	}

	printf "{\"ok\":true,\"uptime\":\"%s\",\"uptime_s\":%d", ut, up
	printf ",\"kernel\":\"%s\",\"kernel_short\":\"%s\"", js(krel), js(krel)
	printf ",\"kernel_full\":\"%s\"", js("Linux " host " " krel " " kver " aarch64")
	printf ",\"cpu\":\"%s\",\"cpu_model\":\"%s\",\"loadavg\":\"%s\"", ncpu " cores (" load ")", js(cpum), js(load)
	printf ",\"mem_total\":%d,\"mem_used\":%d", mt, mu
	printf ",\"hostname\":\"%s\",\"model\":\"%s\"", js(host), js(model)
	printf ",\"os_name\":\"%s\",\"build\":\"%s\",\"version_id\":\"%s\",\"variant\":\"%s\",\"variant_id\":\"%s\"", js(osr["NAME"]), js(osr["VERSION"]), js(osr["VERSION_ID"]), js(osr["VARIANT"]), js(osr["VARIANT_ID"])
	printf ",\"mdns_name\":\"%s\",\"mdns_live\":%s", js(mdns == "-" ? host ".local" : mdns), mdns == "-" ? "false" : "true"
	printf ",\"wifi_ip\":\"%s\",\"usb_ip\":\"%s\",\"addresses\":[%s]", wip, uip, addrs
	printf ",\"processes\":[%s]}\n", procs
}'
