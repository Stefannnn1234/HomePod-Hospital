#!/bin/sh
# speaker.cgi -- Speaker panel backend (amplifiers, feeder, volume).
#   GET  ?action=status
#   POST action=volume&pct=0..100  or  action=volume&dir=up|down    (homepod-audio volume)
#   POST action=mute&state=on|off|toggle
#   POST action=profile&name=apple3|apple2|apple
#   POST action=amp&state=standby|active
#   POST action=start | action=stop                   (homepod-audio, in background)
# Talks to the audio daemon on 127.0.0.1:7001 and to /usr/sbin/homepod-audio.
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"
LOG=/var/log/homepod-audio.log
AUDIO=/usr/sbin/homepod-audio
read_request
ACTION=$(param action)

daemon_pid() {
	for d in /proc/[0-9]*; do
		[ -r $d/cmdline ] || continue
		if tr '\0' ' ' 2>/dev/null < $d/cmdline | grep -q "^python3 .*homepod-audio\.py"; then
			echo "${d#/proc/}"; return
		fi
	done
}

word() { tr -cd 'a-z0-9_-' 2>/dev/null < "$1" | cut -c1-16; }

# POST a small JSON body to the daemon; prints our JSON answer.
daemon_post() {
	R=$(timeout 9 wget -q -T 8 -O - --post-data "$2" "$API/$1?cgi=1" 2>/dev/null)
	json_head
	case "$R" in
	'{"ok": true'*|'{"ok":true'*)
		echo '{"ok":true}' ;;
	'')
		echo '{"ok":false,"error":"audio daemon is not answering (is the service started?)"}' ;;
	*)
		# The daemon's error text is already a JSON string body (ASCII, escaped);
		# pass it through only if it is complete and plain, else say something generic.
		E=$(printf '%s\n' "$R" | awk '
			match($0, /"error": *"([^"\\]|[\\]["\\\/bfnrt]|[\\]u[0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F])*"/) {
				e = substr($0, RSTART, RLENGTH); sub(/^"error": *"/, "", e); sub(/"$/, "", e)
				if (length(e) <= 300 && e !~ /[^ -~]/) print e
				exit
			}')
		printf '{"ok":false,"error":"%s"}\n' "${E:-audio daemon refused the request}" ;;
	esac
}

do_status() {
	DP=$(daemon_pid); FP=$(pidof hpfeed 2>/dev/null | awk '{print $1}')
	case "$FP" in *[!0-9]*) FP= ;; esac
	D=$(timeout 4 wget -q -T 3 -O - "$API/status?cgi=1" 2>/dev/null | head -c 8192 | tohex)
	STATS=$(tail -n 200 $LOG 2>/dev/null | grep 'hpfeed:' | tail -n 1 | cut -c1-300 | jesc)
	LAST=$(tail -n 1 $LOG 2>/dev/null | cut -c1-300 | jesc)
	json_head
	printf '{"ok":true,"amp_state":"%s","feed_state":"%s"' "$(word $RUN/amp.state)" "$(word $RUN/feed.state)"
	printf ',"daemon_pid":%s,"feeder_pid":%s' "${DP:-null}" "${FP:-null}"
	# one call instead of three: each start of homepod-audio costs about 80 ms on the pod
	VV=$($AUDIO ui 2>/dev/null)
	V=$(printf '%s\n' "$VV" | sed -n 's/^volume=\([0-9.]*\)$/\1/p' | head -n 1)
	VD=$(printf '%s\n' "$VV" | sed -n 's/^volume_db=\(-\{0,1\}[0-9.]*\)$/\1/p' | head -n 1)
	VM=$(printf '%s\n' "$VV" | sed -n 's/^volume_max_db=\(-\{0,1\}[0-9.]*\)$/\1/p' | head -n 1)
	PR=$(printf '%s\n' "$VV" | sed -n 's/^profile=\([a-z0-9]*\)$/\1/p' | head -n 1)
	MU=$(printf '%s\n' "$VV" | sed -n 's/^mute=\([01]\)$/\1/p' | head -n 1)
	printf ',"volume":%s,"volume_db":%s,"volume_max_db":%s' "${V:-null}" "${VD:-null}" "${VM:-null}"
	printf ',"profile":"%s","muted":%s' "$PR" "$([ "$MU" = 1 ] && echo true || echo false)"
	printf ',"feeder_stats":"%s","log_last":"%s"' "$STATS" "$LAST"
	printf ',"daemon_json_hex":"%s",%s}\n' "$D" "$(job_json audio)"
}

# Run one homepod-audio command and answer with its outcome.
audio_cmd() {
	[ -x $AUDIO ] || fail "homepod-audio is not installed"
	[ -n "$(daemon_pid)" ] || fail "the audio service is not running"
	OUT=$(timeout 12 $AUDIO "$@" 2>&1) || fail "$(printf '%s' "$OUT" | tail -n 1 | cut -c1-200)"
	json_head
	echo '{"ok":true}'
}

do_volume() {
	need_post
	DIR=$(param dir); PCT=$(param pct)
	case "$DIR" in
	up|down) audio_cmd volume "$DIR" ;;
	'')
		printf '%s\n' "$PCT" | grep -Eq '^[0-9]{1,3}(\.[0-9])?$' || fail "volume must be 0 to 100"
		audio_cmd volume "$PCT" ;;
	*) fail "dir must be up or down" ;;
	esac
}

do_mute() {
	need_post
	S=$(param state)
	case "$S" in on|off|toggle) ;; *) fail "state must be on, off or toggle" ;; esac
	audio_cmd mute "$S"
}

do_profile() {
	need_post
	N=$(param name)
	case "$N" in apple3|apple2|apple) ;; *) fail "unknown profile" ;; esac
	audio_cmd profile "$N"
}

do_amp() {
	need_post
	S=$(param state)
	case "$S" in standby|active) ;; *) fail "state must be standby or active" ;; esac
	daemon_post amp "{\"state\":\"$S\"}"
}

do_service() {
	need_post
	[ -x /usr/sbin/homepod-audio ] || fail "homepod-audio is not installed"
	lock_take audio || fail "the audio service is already being started or stopped"
	bg_job audio /usr/sbin/homepod-audio "$1"
	json_head
	echo '{"ok":true,"pending":true}'
}

case "$ACTION" in
''|status) do_status ;;
volume) do_volume ;;
mute) do_mute ;;
profile) do_profile ;;
amp) do_amp ;;
start|stop) do_service "$ACTION" ;;
*) fail "unknown action" ;;
esac
