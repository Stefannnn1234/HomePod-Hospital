#!/bin/sh
# devices.cgi -- Devices panel backend (GET only): USB, I2C, device tree, GPIO.
# Reads what the kernel already knows from sysfs / procfs. Nothing here talks to
# hardware: no I2C bus scan (probing every address disturbs the power-management
# chip on bus 0 and collides with the top-panel daemon on bus 2, build 108), and
# no debugfs.
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"

rd() { tr -d '\0' < "$1" 2>/dev/null; }

usb_json=""
sep=""
for dev in /sys/bus/usb/devices/[0-9]*-[0-9]*; do
	[ -d "$dev" ] || continue
	case "$dev" in *:*) continue ;; esac		# interfaces, not devices
	info="$(rd "$dev/idVendor"):$(rd "$dev/idProduct") $(rd "$dev/manufacturer") $(rd "$dev/product")"
	usb_json="$usb_json$sep{\"device\":\"$(printf '%s' "${dev##*/}" | jesc)\",\"info\":\"$(printf '%s' "$info" | jesc)\"}"
	sep=","
done

i2c=$(
	for bus in /sys/class/i2c-adapter/i2c-*; do
		[ -d "$bus" ] || continue
		echo "${bus##*/}: $(rd "$bus/name")"
	done
	first=1
	for dev in /sys/bus/i2c/devices/[0-9]*-[0-9a-f]*; do
		[ -d "$dev" ] || continue
		[ $first = 1 ] && { echo; echo "Devices the kernel knows (device tree / drivers):"; first=0; }
		drv=""
		[ -L "$dev/driver" ] && drv=" (driver: $(basename "$(readlink "$dev/driver")"))"
		echo "  ${dev##*/}: $(rd "$dev/name")$drv"
	done
)

dt=""
if [ -d /proc/device-tree ]; then
	dt=$(
		echo "Model: $(rd /proc/device-tree/model)"
		echo "Compatible: $(tr '\0' ' ' < /proc/device-tree/compatible 2>/dev/null)"
		echo
		echo "Top-level nodes (disabled ones left out):"
		for node in /proc/device-tree/*/; do
			node=${node%/}
			st=$(rd "$node/status")
			case "$st" in disabled) continue ;; esac
			c=""
			[ -f "$node/compatible" ] && c=" ($(tr '\0' ',' < "$node/compatible" | sed 's/,$//'))"
			echo "  ${node##*/}${st:+ [$st]}$c"
		done
	)
fi

gpio=$(
	for chip in /sys/class/gpio/gpiochip*; do
		[ -d "$chip" ] || continue
		echo "${chip##*/}: $(rd "$chip/label") (base=$(rd "$chip/base"), count=$(rd "$chip/ngpio"))"
	done
)

json_head
printf '{"ok":true,"usb":[%s],"i2c":"%s","devicetree":"%s","gpio":"%s"}\n' "$usb_json" \
	"$(printf '%s' "$i2c" | jesc)" "$(printf '%s' "$dt" | jesc)" "$(printf '%s' "$gpio" | jesc)"
