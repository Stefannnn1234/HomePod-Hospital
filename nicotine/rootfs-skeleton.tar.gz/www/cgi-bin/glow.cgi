#!/bin/sh
# glow.cgi -- Sound Glow card backend (top LEDs follow the music) and the touch controls switch.
#   GET  ?action=status
#   POST action=on | action=off                    (homepod-glow on|off, in background)
#   POST action=set&brightness=1..100&palette=NAME  (either or both; applies at once)
#   POST action=touch&state=on|off                 (homepod-glow touch on|off, in background)
# Everything goes through /usr/sbin/homepod-glow; the setting lives in /etc/homepod-glow.conf.
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"
GLOW=/usr/sbin/homepod-glow

read_request
ACTION=$(param action)

do_status() {
	if [ ! -x $GLOW ]; then
		json_head
		echo '{"ok":true,"available":false}'
		exit 0
	fi
	S=$(timeout 8 $GLOW status 2>/dev/null </dev/null | head -c 4096)
	json_head
	printf '%s\n' "$S" | awk "$AWKLIB"'
	BEGIN { hp_init() }
	{ i = index($0, "="); if (i < 2) next; v[substr($0, 1, i - 1)] = substr($0, i + 1) }
	END {
		printf "{\"ok\":true,\"available\":true"
		printf ",\"enabled\":%s", (v["enabled"] == "1") ? "true" : "false"
		printf ",\"running\":%s", (v["running"] == "yes") ? "true" : "false"
		printf ",\"brightness\":%s", num(v["brightness"])
		printf ",\"palette\":\"%s\"", js(v["palette"])
		n = split(v["palettes"], p, " ")
		printf ",\"palettes\":["
		for (i = 1; i <= n; i++) printf "%s\"%s\"", (i > 1 ? "," : ""), js(p[i])
		printf "],\"state\":\"%s\",\"source\":\"%s\"", js(v["state"]), js(v["source"])
		n = split(v["colors"], c, ",")
		printf ",\"colors\":["
		k = 0
		for (i = 1; i <= n; i++)
			if (c[i] ~ /^#[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]$/) printf "%s\"%s\"", (k++ ? "," : ""), c[i]
		printf "],\"meter\":%s", (v["meter"] == "1") ? "true" : "false"
		printf ",\"meter_file\":%s", (v["meter_file"] == "present") ? "true" : "false"
		printf ",\"errors\":%s,\"frames\":%s,\"fps\":%s", num(v["errors"]), num(v["frames"]), num(v["fps"])
		printf ",\"last_error\":\"%s\"", js(substr(v["last_error"], 1, 160))
		t = v["touch"]; if (t != "on" && t != "off" && t != "dryrun") t = "off"
		printf ",\"touch\":\"%s\",\"touch_armed\":%s", t, (v["touch_armed"] == "1") ? "true" : "false"
		printf ",\"touch_last\":\"%s\"", js(substr(v["touch_last"], 1, 60))
		printf ",\"touch_events\":\"%s\"", js(substr(v["touch_events"], 1, 100))
	}'
	printf ',%s}\n' "$(job_json glow)"
}

do_switch() {
	need_post
	[ -x $GLOW ] || fail "homepod-glow is not installed"
	lock_take glow || fail "Sound Glow is already being switched"
	bg_job glow $GLOW "$1"
	json_head
	echo '{"ok":true,"pending":true}'
}

do_touch() {
	need_post
	[ -x $GLOW ] || fail "homepod-glow is not installed"
	S=$(param state)
	case "$S" in on|off) ;; *) fail "state must be on or off" ;; esac
	lock_take glow || fail "Sound Glow is already being switched"
	bg_job glow $GLOW touch "$S"
	json_head
	echo '{"ok":true,"pending":true}'
}

do_set() {
	need_post
	[ -x $GLOW ] || fail "homepod-glow is not installed"
	B=$(param brightness); P=$(param palette)
	[ -n "$B$P" ] || fail "nothing to set"
	if [ -n "$B" ]; then
		is_int "$B" && [ "$B" -ge 1 ] && [ "$B" -le 100 ] || fail "brightness must be 1 to 100"
	fi
	if [ -n "$P" ]; then
		case "$P" in *[!a-z]*|?????????????????*) fail "unknown palette" ;; esac
	fi
	if [ -n "$P" ]; then
		timeout 8 $GLOW palette "$P" >/dev/null 2>&1 </dev/null || fail "unknown palette"
	fi
	if [ -n "$B" ]; then
		timeout 8 $GLOW brightness "$((B))" >/dev/null 2>&1 </dev/null || fail "the brightness could not be saved"
	fi
	json_head
	echo '{"ok":true}'
}

case "$ACTION" in
''|status) do_status ;;
on|off) do_switch "$ACTION" ;;
set) do_set ;;
touch) do_touch ;;
*) fail "unknown action" ;;
esac
