#!/bin/sh
# bluetooth.cgi -- Bluetooth panel backend.
#   GET  ?action=status
#   POST action=pair[&seconds=10..600]   open the pairing window (homepod-bluetooth pair)
#   POST action=pair_stop                close it
#   POST action=forget&addr=AA-BB-CC-DD-EE-FF   remove one pairing
# Addresses travel with "-" because ":" is not allowed in a request.
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"
BT=${HOMEPOD_UI_BT:-/usr/sbin/homepod-bluetooth}

read_request
ACTION=$(param action)

do_status() {
	if [ ! -x $BT ]; then
		json_head
		echo '{"ok":true,"available":false}'
		exit 0
	fi
	T=$RUN/ui-bt.$$
	mkdir -p $RUN
	timeout 8 $BT status > $T 2>&1 </dev/null
	RC=$?
	H=$(head -c 4096 $T | tohex)
	val() { sed -n "s/^$1=//p" $T | head -n 1; }
	PAIRING=$(val pairing); LEFT=$(val pairing_left); ATBOOT=$(val pair_at_boot); SECS=$(val pair_seconds)
	UP=$(val bluetoothd); CONN=$(val connected); KNOWS=0
	grep -q '^pairing=' $T && KNOWS=1		# an older homepod-bluetooth has no pairing window
	case "$LEFT" in -1|[0-9]|[0-9][0-9]|[0-9][0-9][0-9]) ;; *) LEFT=0 ;; esac
	case "$SECS" in [1-9][0-9]|[1-9][0-9][0-9]) ;; *) SECS=180 ;; esac
	rm -f $T
	DEV=""
	if [ "$UP" = running ] && [ $KNOWS = 1 ]; then
		DEV=$(timeout 6 $BT devices 2>/dev/null </dev/null | head -n 20 | while read -r a c n; do
			echo "$a" | grep -Eq '^([0-9A-F]{2}:){5}[0-9A-F]{2}$' || continue
			printf '%s{"addr":"%s","connected":%s,"name_hex":"%s"}' "$SEP" "$a" \
				"$([ "$c" = connected ] && echo true || echo false)" "$(printf '%s' "$n" | head -c 64 | tohex)"
			SEP=,
		done)
	fi
	json_head
	printf '{"ok":true,"available":true,"rc":%d,"running":%s,"window":%s' "$RC" \
		"$([ "$UP" = running ] && echo true || echo false)" "$([ $KNOWS = 1 ] && echo true || echo false)"
	printf ',"pairing":%s,"pairing_left":%s,"pair_at_boot":%s,"pair_seconds":%s' \
		"$([ "$PAIRING" = yes ] && echo true || echo false)" "$LEFT" \
		"$([ "$ATBOOT" = 1 ] && echo true || echo false)" "$SECS"
	printf ',"connected":%s,"devices":[%s],"output_hex":"%s"}\n' \
		"$([ "$CONN" = yes ] && echo true || echo false)" "$DEV" "$H"
}

bt_cmd() {	# run one homepod-bluetooth command and answer with its outcome
	[ -x $BT ] || fail "Bluetooth is not installed"
	OUT=$(timeout 12 $BT "$@" 2>&1 </dev/null) || fail "$(printf '%s' "$OUT" | tail -n 1 | cut -c1-200)"
	json_head
	echo '{"ok":true}'
}

case "$ACTION" in
''|status) do_status ;;
pair)
	need_post
	S=$(param seconds)
	if [ -n "$S" ]; then
		is_int "$S" && [ "$S" -ge 10 ] && [ "$S" -le 600 ] || fail "seconds must be 10 to 600"
		bt_cmd pair "$S"
	else
		bt_cmd pair
	fi ;;
pair_stop)
	need_post
	bt_cmd pair off ;;
forget)
	need_post
	A=$(param addr)
	echo "$A" | grep -Eq '^([0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2}$' || fail "bad address"
	bt_cmd forget "$(echo "$A" | tr - :)" ;;
*) fail "unknown action" ;;
esac
