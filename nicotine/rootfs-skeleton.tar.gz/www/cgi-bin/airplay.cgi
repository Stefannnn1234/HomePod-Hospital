#!/bin/sh
# airplay.cgi -- AirPlay panel backend.
#   GET  ?action=status    service state, name, whether the pod can steer the
#                          sender (remote_control), and the session from
#                          /run/homepod/nowplaying.json (passed on as hex)
#   POST action=start | stop | restart        (homepod-airplay, in background)
#   POST action=rename&name=HEX               (edit general.name, then restart)
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"
CONF=/etc/shairport-sync.conf
NP=$RUN/nowplaying.json

read_request
ACTION=$(param action)

conf_name_hex() {
	sed -n 's/^[[:space:]]*name[[:space:]]*=[[:space:]]*"\([^"]*\)".*/\1/p' $CONF 2>/dev/null |
		head -n 1 | tr -d '\n' | tohex
}

do_status() {
	F=$(timeout 6 homepod-airplay status 2>/dev/null | awk "$AWKLIB"'
	BEGIN { hp_init() }
	{ p = index($0, "="); if (p > 1) kv[substr($0, 1, p - 1)] = substr($0, p + 1) }
	END {
		printf "\"running\":%s", (kv["shairport-sync"] == "running") ? "true" : "false"
		printf ",\"shairport\":\"%s\"", js(kv["shairport-sync"])
		printf ",\"nqptp\":\"%s\"", js(kv["nqptp"])
		printf ",\"avahi\":\"%s\"", js(kv["avahi-daemon"])
		printf ",\"dbus\":\"%s\"", js(kv["dbus-daemon"])
		printf ",\"model\":\"%s\"", js(kv["model"])
		printf ",\"mdns_backend\":\"%s\"", js(kv["mdns_backend"])
		printf ",\"pcm_fifo_present\":\"%s\"", js(kv["pcm_fifo_present"])
		printf ",\"device_id\":\"%s\"", js(kv["device_id"])
		printf ",\"remote_control\":%s", (kv["remote_control"] == "1") ? "true" : (kv["remote_control"] == "0") ? "false" : "null"
	}')
	[ -n "$F" ] || F='"running":false,"shairport":"unknown"'
	if [ -x /usr/sbin/homepod-airplay ]; then I=true; else I=false; fi
	json_head
	# the now-playing file is small JSON written by another service: pass it on
	# untouched (hex), the page parses it; at most 4 KB
	H=$(head -c 4096 $NP 2>/dev/null | tohex)
	printf '{"ok":true,"installed":%s,%s,"name_hex":"%s","nowplaying_hex":"%s",%s}\n' "$I" "$F" "$(conf_name_hex)" "$H" "$(job_json airplay)"
}

do_service() {
	need_post
	[ -x /usr/sbin/homepod-airplay ] || fail "homepod-airplay is not installed"
	lock_take airplay || fail "AirPlay is already being started or stopped"
	bg_job airplay /usr/sbin/homepod-airplay "$1"
	json_head
	echo '{"ok":true,"pending":true}'
}

do_rename() {
	need_post
	N=$(param name)
	# 1..63 bytes, nothing below space, no DEL, and none of  " ' \ $
	# ($ would start a ${VAR} expansion in the config file).
	hex_bytes_ok "$N" 1 63 32 255 "22 27 5c 24 7f" ||
		fail "name must be 1 to 63 characters without quotes, backslash or dollar sign"
	case "$N" in 20*|*20) fail "name must not start or end with a space" ;; esac
	[ -f $CONF ] || fail "no $CONF"
	[ "$(conf_name_hex)" = "$N" ] && { json_head; echo '{"ok":true,"unchanged":true}'; return; }
	lock_take airplay || fail "AirPlay is being started or stopped, try again in a moment"
	T=$CONF.ui.$$
	if HP_NAME=$(unhex "$N") awk '
		BEGIN { done = 0 }
		!done && match($0, /^[ \t]*name[ \t]*=[ \t]*"[^"]*"/) {
			head = substr($0, 1, RLENGTH); rest = substr($0, RLENGTH + 1)
			sub(/"[^"]*"$/, "", head)
			print head "\"" ENVIRON["HP_NAME"] "\"" rest
			done = 1; next
		}
		{ print }
		END { exit done ? 0 : 3 }' $CONF > $T && [ -s $T ]; then
		cp $CONF $CONF.ui.bak && cat $T > $CONF
		rm -f $T
	else
		rm -f $T; rmdir $RUN/ui-airplay.lock 2>/dev/null
		fail "could not find the name line in $CONF"
	fi
	if [ "$(conf_name_hex)" != "$N" ]; then
		cat $CONF.ui.bak > $CONF; rmdir $RUN/ui-airplay.lock 2>/dev/null
		fail "the edit did not verify; config restored"
	fi
	if [ -x /usr/sbin/homepod-airplay ] && pidof shairport-sync >/dev/null 2>&1; then
		bg_job airplay /usr/sbin/homepod-airplay restart
		json_head; echo '{"ok":true,"pending":true,"restarting":true}'
	else
		rmdir $RUN/ui-airplay.lock 2>/dev/null
		json_head; echo '{"ok":true,"restarting":false}'
	fi
}

case "$ACTION" in
''|status) do_status ;;
start|stop|restart) do_service "$ACTION" ;;
rename) do_rename ;;
*) fail "unknown action" ;;
esac
