#!/bin/sh
# network.cgi -- Network panel backend (GET only): interfaces, routes, DNS, as
# the tools print them. WiFi detail and changes are on the WiFi tab (wifi.cgi).
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"

IFS_TXT=$(timeout 3 ip addr 2>/dev/null </dev/null | jesc)
RT_TXT=$( { timeout 3 ip -4 route 2>/dev/null; timeout 3 ip -6 route 2>/dev/null | grep -v '^fe80::/64\|^multicast\|^ff00::/8'; } </dev/null | jesc)
DNS_TXT=$(grep -v '^#' /etc/resolv.conf 2>/dev/null | jesc)

json_head
printf '{"ok":true,"interfaces":"%s","routes":"%s","dns":"%s"}\n' "${IFS_TXT:-no network tools}" "${RT_TXT:-no routes}" "${DNS_TXT:-no /etc/resolv.conf}"
