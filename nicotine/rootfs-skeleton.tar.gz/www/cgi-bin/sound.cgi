#!/bin/sh
# sound.cgi -- Sound and Equaliser cards of the Speaker tab.
#   GET  ?action=status
#        -> {"ok":true,"available":true,"running":bool,"sound":{...}}   from "homepod-audio sound"
#   POST action=set&k=<key>&v=<hex of value>
#        action=set&k1=<key>&v1=<hex>&k2=...&v2=...   (up to 16 pairs, applied as ONE
#        "homepod-audio sound set" call, so a whole EQ preset is one DSP reload)
#        -> {"ok":true,"sound":{...}} or {"ok":false,"error":"<the script's one line>"}
#   POST action=identify&slot=1..7
#        -> only that tweeter plays for 2 s ("homepod-audio tune solo=N", then solo=0)
# Values travel hex-encoded because EQ bands contain commas.
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"
AUDIO=/usr/sbin/homepod-audio
IDF=$RUN/ui-sound-identify		# "<pid> <epoch>" of the identify in progress
read_request
ACTION=$(param action)
set -f

# stdin: key=value lines of "homepod-audio sound" -> JSON object (with braces)
sound_json() {
	awk '
	function isnum(v) { return v ~ /^[-+]?[0-9]+(\.[0-9]+)?$/ }
	function n(v) { if (!isnum(v)) return "null"; sub(/^\+/, "", v); return v + 0 }
	function w(v) { return (v ~ /^[a-z0-9]+$/ && length(v) <= 16) ? "\"" v "\"" : "null" }
	BEGIN { for (i = 0; i < 10; i++) band[i] = "null" }
	{
		p = index($0, "="); if (!p) next
		k = substr($0, 1, p - 1); v = substr($0, p + 1); sub(/[ \t\r]+$/, "", v)
		if (k ~ /^eq[0-9]$/) {
			i = substr(k, 3) + 0
			if (split(v, f, ",") == 4 && f[1] ~ /^(peak|lowshelf|highshelf)$/ && isnum(f[2]) && isnum(f[3]) && isnum(f[4]))
				band[i] = "{\"type\":\"" f[1] "\",\"hz\":" n(f[2]) ",\"db\":" n(f[3]) ",\"q\":" n(f[4]) "}"
			else band[i] = "null"
		} else val[k] = v
	}
	END {
		printf "{\"reduce_bass\":%s,\"loudness\":%s,\"placement\":%s,\"ambient_db\":%s,\"front_deg\":%s",
			n(val["reduce_bass"]), w(val["loudness"]), w(val["placement"]), n(val["ambient_db"]), n(val["front_deg"])
		printf ",\"channels\":%s,\"sync_ms\":%s,\"eq\":%s,\"eq_pre\":%s,\"profile\":%s,\"eq_bands\":[",
			w(val["channels"]), n(val["sync_ms"]), n(val["eq"]), n(val["eq_pre"]), w(val["profile"])
		for (i = 0; i < 10; i++) printf "%s%s", (i ? "," : ""), band[i]
		printf "]}"
	}'
}

feeder_running() { pidof hpfeed >/dev/null 2>&1 && echo true || echo false; }

# run the audio script; stdout in $OUT, first stderr line in $ERR, exit code in $RC
run_audio() {
	mkdir -p $RUN
	EF=$RUN/ui-sound.$$.err
	OUT=$(timeout 15 $AUDIO "$@" 2>$EF); RC=$?
	ERR=$(head -n 1 $EF 2>/dev/null | cut -c1-200); rm -f $EF
	case $RC in 124|143) ERR="the speaker did not answer in time" ;; esac
}

solo_off() { timeout 10 $AUDIO tune solo=0 >/dev/null 2>&1; }

# An identify whose own reset never ran (job killed) is undone here, at most 10 s late.
identify_sweep() {
	[ -f $IDF ] || return 0
	set -- $(cat $IDF 2>/dev/null)
	NOW=$(date +%s)
	case "$2" in ''|*[!0-9]*) ;; *) [ $((NOW - $2)) -lt 10 ] && return 0 ;; esac
	solo_off; rm -f $IDF
}

do_status() {
	[ -x $AUDIO ] || fail "the sound settings need a newer homepod-audio"
	identify_sweep
	run_audio sound
	[ $RC = 0 ] || fail "${ERR:-homepod-audio sound failed}"
	printf '%s\n' "$OUT" | grep -q '^reduce_bass=' || fail "the sound settings need a newer homepod-audio"
	S=$(printf '%s\n' "$OUT" | sound_json)
	json_head
	printf '{"ok":true,"available":true,"running":%s,"sound":%s}\n' "$(feeder_running)" "$S"
}

do_set() {
	need_post
	[ -x $AUDIO ] || fail "the sound settings need a newer homepod-audio"
	# Pairs k/v, k1/v1 .. k16/v16 -> validated key=value lines, or "ERR message".
	ARGS=$(printf '%s\n' "$REQ" | awk -F'&' '
	function isnum(v) { return v ~ /^[-+]?[0-9]+(\.[0-9]+)?$/ && length(v) <= 9 }
	function rng(v, lo, hi) { return isnum(v) && v + 0 >= lo && v + 0 <= hi }
	function bad(m) { print "ERR " m; err = 1; exit }
	function unhex(h,   i, a, b, c, s) {
		if (h == "" || length(h) % 2 || length(h) > 96) return ""
		s = ""
		for (i = 1; i <= length(h); i += 2) {
			a = index(hx, substr(h, i, 1)); b = index(hx, substr(h, i + 1, 1))
			if (!a || !b) return ""
			c = (a - 1) * 16 + b - 1
			# allowed: + , - . 0-9 a-z
			if (!((c >= 43 && c <= 46) || (c >= 48 && c <= 57) || (c >= 97 && c <= 122))) return ""
			s = s sprintf("%c", c)
		}
		return s
	}
	function ok(k, v,   f) {
		if (k == "reduce_bass" || k == "eq") return v ~ /^[01]$/
		if (k == "loudness") return v ~ /^(auto|off)$/
		if (k == "placement") return v ~ /^(free|wall|book)$/
		if (k == "channels") return v ~ /^(stereo|mono|left|right)$/
		if (k == "ambient_db") return rng(v, -12, 6)
		if (k == "front_deg") return rng(v, 0, 360)
		if (k == "eq_pre") return rng(v, -12, 0)
		if (k ~ /^eq[0-9]$/) {
			if (v == "off") return 1
			return split(v, f, ",") == 4 && f[1] ~ /^(peak|lowshelf|highshelf)$/ &&
				rng(f[2], 20, 20000) && rng(f[3], -12, 6) && rng(f[4], 0.3, 10)
		}
		return -1
	}
	BEGIN { hx = "0123456789abcdef" }
	{
		for (i = 1; i <= NF; i++) {
			p = index($i, "="); if (!p) continue
			nm = substr($i, 1, p - 1); v = substr($i, p + 1)
			if (nm ~ /^[kv]([1-9]|1[0-6])?$/) { if (nm in seen) bad("the same field twice"); seen[nm] = 1; P[nm] = v }
		}
	}
	END {
		if (err) exit 0
		n = 0
		for (j = 0; j <= 16; j++) {
			ix = j ? j : ""
			if (!(("k" ix) in P) && !(("v" ix) in P)) continue
			if (!(("k" ix) in P) || !(("v" ix) in P)) bad("a key without a value")
			k = P["k" ix]; v = unhex(P["v" ix])
			if (k in done) bad("the same setting twice: " k)
			done[k] = 1
			r = ok(k, v)
			if (r == -1) bad("unknown setting: " k)
			if (v == "") bad("bad characters in the value of " k)
			if (!r) bad("value out of range for " k ": " v)
			out[++n] = k "=" v
		}
		if (!n) bad("nothing to set")
		for (j = 1; j <= n; j++) print out[j]
	}')
	case "$ARGS" in
	'')	fail "bad request" ;;
	ERR*)	fail "${ARGS#ERR }" ;;
	esac
	run_audio sound set $ARGS
	[ $RC = 0 ] || fail "${ERR:-the speaker refused the setting}"
	json_head
	if printf '%s\n' "$OUT" | grep -q '^reduce_bass='; then
		printf '{"ok":true,"sound":%s}\n' "$(printf '%s\n' "$OUT" | sound_json)"
	else
		echo '{"ok":true}'
	fi
}

do_identify() {
	need_post
	SLOT=$(param slot)
	case "$SLOT" in [1-7]) ;; *) fail "slot must be 1 to 7" ;; esac
	[ -x $AUDIO ] || fail "homepod-audio is missing"
	mkdir -p $RUN
	TOK="$$ $(date +%s)"
	echo "$TOK" > $IDF		# a newer identify takes over; the older one then leaves solo alone
	run_audio tune solo=$SLOT
	if [ $RC != 0 ]; then
		solo_off; rm -f $IDF
		fail "${ERR:-could not solo that tweeter}"
	fi
	# The reset runs detached (httpd waits for every holder of our stdout). Whoever owns
	# $IDF when the 2 s are up turns solo off; a TERM also turns it off.
	(
		trap '' HUP
		trap 'solo_off; rm -f $IDF; exit 0' TERM INT
		sleep 2
		if [ "$(cat $IDF 2>/dev/null)" = "$TOK" ]; then solo_off; rm -f $IDF; fi
	) </dev/null >/dev/null 2>&1 &
	json_head
	printf '{"ok":true,"slot":%s,"seconds":2}\n' "$SLOT"
}

case "$ACTION" in
status|'') do_status ;;
set) do_set ;;
identify) do_identify ;;
*) fail "unknown action" ;;
esac
