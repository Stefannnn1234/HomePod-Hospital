#!/bin/sh
# config.cgi -- backup & restore backend (front end for /usr/sbin/homepod-config).
#   GET  ?action=info      what would be backed up, when the last backup and
#                          restore happened, and the last restore's report
#   GET  ?action=export    the backup itself, as a download
#   POST ?action=import    restore: the request body is the backup file, byte
#                          for byte (Content-Type application/x-homepod, like
#                          every other state change here). The action is in
#                          the query string because the body is not text.
#                          Runs "homepod-config import --apply" and answers
#                          when it has finished (WiFi may take 25 s).
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"
HC=/usr/sbin/homepod-config
MAXZ=1048576

REQ=$QUERY_STRING
case "$REQ" in *[!A-Za-z0-9_=\&.-]*) fail "bad characters in request" ;; esac
ACTION=$(param action)

do_info() {
	if [ ! -x $HC ]; then
		json_head
		echo '{"ok":true,"available":false}'
		return
	fi
	F=$(timeout 6 $HC info 2>/dev/null </dev/null | awk "$AWKLIB"'
	BEGIN { hp_init() }
	{ p = index($0, "="); if (p > 1) kv[substr($0, 1, p - 1)] = substr($0, p + 1) }
	END {
		printf "\"unit\":\"%s\"", js(kv["unit"])
		printf ",\"wifi_mac\":\"%s\"", js(kv["wifi_mac"])
		printf ",\"bt_addr\":\"%s\"", js(kv["bt_addr"])
		printf ",\"wifi_secret\":\"%s\"", js(kv["wifi_secret"])
		printf ",\"bt_devices\":%s", num(kv["bt_devices"])
		printf ",\"last_export\":\"%s\"", js(kv["last_export"])
		printf ",\"last_import\":\"%s\"", js(kv["last_import"])
		printf ",\"last_import_result\":\"%s\"", js(kv["last_import_result"])
		printf ",\"last_import_epoch\":%s", num(kv["last_import_epoch"])
	}')
	[ -n "$F" ] || fail "homepod-config info did not answer"
	if [ -d $RUN/config.lock ]; then B=true; else B=false; fi
	H=$(head -c 4096 $RUN/config.last_result 2>/dev/null | tohex)
	json_head
	printf '{"ok":true,"available":true,%s,"busy":%s,"last_output_hex":"%s"}\n' "$F" "$B" "$H"
}

do_export() {
	[ "$REQUEST_METHOD" = GET ] || fail "export is a GET"
	[ -x $HC ] || fail "homepod-config is not installed"
	mkdir -p $RUN
	T=$RUN/ui-config-export.$$
	timeout 30 $HC export > $T 2> $T.err </dev/null
	RC=$?
	N=$(wc -c < $T | tr -d ' ')
	if [ $RC != 0 ] || [ "$N" -lt 20 ]; then
		E=$(tail -n 1 $T.err | cut -c1-200)
		rm -f $T $T.err
		fail "could not make the backup${E:+: $E}"
	fi
	U=$($HC info 2>/dev/null </dev/null | sed -n 's/^unit=//p' | head -n 1 | tr -cd '0-9A-Fa-f' | cut -c1-8)
	printf 'Content-Type: application/gzip\r\n'
	printf 'Content-Disposition: attachment; filename="homepod-config-%s.tar.gz"\r\n' "${U:-0000}"
	printf 'Content-Length: %s\r\nCache-Control: no-store\r\n\r\n' "$N"
	cat $T
	rm -f $T $T.err
}

do_import() {
	need_post
	[ -x $HC ] || fail "homepod-config is not installed"
	case "$CONTENT_LENGTH" in ''|*[!0-9]*) fail "bad request" ;; esac
	[ ${#CONTENT_LENGTH} -le 9 ] || fail "backup is larger than 1 MB"
	if [ "$CONTENT_LENGTH" -gt $MAXZ ]; then
		# take a moderately oversized upload off the socket so the browser
		# gets to read this answer instead of a reset connection
		[ "$CONTENT_LENGTH" -le 8388608 ] && head -c "$CONTENT_LENGTH" > /dev/null
		fail "backup is larger than 1 MB"
	fi
	[ "$CONTENT_LENGTH" -ge 20 ] || fail "no backup received"
	mkdir -p $RUN
	T=$RUN/ui-config-import.$$
	# head -c copies bytes as they are; nothing here treats the body as text
	head -c "$CONTENT_LENGTH" > $T
	if [ "$(wc -c < $T | tr -d ' ')" != "$CONTENT_LENGTH" ]; then
		rm -f $T
		fail "the upload was cut short"
	fi
	# stdin, stdout and stderr all point at files: services that the import
	# restarts must not inherit the pipe to httpd, or this request never ends
	timeout 150 $HC import --apply < $T > $T.out 2>&1
	RC=$?
	rm -f $T
	cp $T.out $RUN/config.last_result.tmp && mv -f $RUN/config.last_result.tmp $RUN/config.last_result
	H=$(head -c 4096 $T.out | tohex)
	E=$(sed -n 's/^error=//p' $T.out | head -n 1 | cut -c1-200 | jesc)
	rm -f $T.out
	case $RC in
	0) OK=true; P=false ;;
	2) OK=true; P=true ;;
	1) OK=false; P=false; [ -n "$E" ] || E="the backup was refused" ;;
	*) OK=false; P=false; E="the restore did not finish (exit status $RC)" ;;
	esac
	json_head
	if [ $OK = true ]; then
		printf '{"ok":true,"partial":%s,"rc":%d,"output_hex":"%s"}\n' "$P" "$RC" "$H"
	else
		printf '{"ok":false,"error":"%s","rc":%d,"output_hex":"%s"}\n' "$E" "$RC" "$H"
	fi
}

case "$ACTION" in
''|info) do_info ;;
export) do_export ;;
import) do_import ;;
*) fail "unknown action" ;;
esac
