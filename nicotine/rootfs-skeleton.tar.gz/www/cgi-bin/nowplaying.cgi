#!/bin/sh
# nowplaying.cgi -- backend of the Now Playing tab (polled every 3 s while it is open).
#   GET  ?action=status
#        {"ok":true,"now":{...},"volume":0..100|null,"muted":true|false,
#         "can":{"playpause":bool,"next":bool,"previous":bool},"time":<unix s>}
#        "time" (the pod's clock) lets the page correct for a phone whose clock differs.
#        "now" is the record of /run/homepod/nowplaying.json (written by shairport-sync)
#        or, while a phone plays over Bluetooth, the same shape from
#        /usr/libexec/homepod-nowplaying-bt. Both are produced by programs that escape
#        their text as JSON (UTF-8); it is passed through unchanged, not hex-encoded.
#   POST action=transport&cmd=playpause|next|previous
#        /opt/led/touch-action playpause|next|prev, detached; answers at once.
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"
NPFILE=${HOMEPOD_NP_FILE:-$RUN/nowplaying.json}
BTHELP=${HOMEPOD_NP_BT:-/usr/libexec/homepod-nowplaying-bt}
TOUCH=${HOMEPOD_NP_TOUCH:-/opt/led/touch-action}
AUDIO=${HOMEPOD_NP_AUDIO:-/usr/sbin/homepod-audio}
TLOG=${HOMEPOD_NP_TLOG:-/var/log/homepod-glow.log}
read_request
ACTION=$(param action)

NONE='{"source":"none","state":"stopped","title":"","artist":"","album":"","duration":0.0,"position":0.0,"position_at":0.0,"client":"","cover":"","updated":0.0}'

# a complete record, as the two writers make it (one line, starts with "source")
good() { case "$1" in '{"source":"'*'}') return 0 ;; esac; return 1; }

do_status() {
	AP=; BS=; NOW=
	[ -r "$NPFILE" ] && read -r AP < "$NPFILE"
	good "$AP" || AP=$NONE
	[ -r "$RUN/bt.streaming" ] && read -r BS < "$RUN/bt.streaming"
	if [ "$BS" = 1 ] && [ -x "$BTHELP" ]; then
		NOW=$("$BTHELP" 2>/dev/null)                 # the phone is playing: it wins
	fi
	if ! good "$NOW"; then
		case "$AP" in
		'{"source":"airplay"'*) NOW=$AP ;;
		*)	# no AirPlay session: a connected phone may be paused
			if [ -s "$RUN/bt.device" ] && [ -x "$BTHELP" ]; then NOW=$("$BTHELP" 2>/dev/null); fi
			good "$NOW" || NOW=$AP ;;
		esac
	fi

	V=$("$AUDIO" volume 2>/dev/null | sed -n 's/^volume=\([0-9]\{1,3\}\(\.[0-9]\{1,2\}\)\{0,1\}\)$/\1/p' | head -n 1)
	M=$("$AUDIO" mute 2>/dev/null | sed -n 's/^mute=\([01]\)$/\1/p' | head -n 1)

	case "$NOW" in
	'{"source":"none"'*)
		# nothing plays: a tap can still wake a sender we paused or a connected phone
		if [ -e "$RUN/touch.ap-paused" ] || [ -s "$RUN/bt.device" ]; then PP=true; else PP=false; fi
		NX=false ;;
	*)	PP=true; NX=true ;;
	esac
	json_head
	printf '{"ok":true,"now":%s,"volume":%s,"muted":%s,"can":{"playpause":%s,"next":%s,"previous":%s},"time":%s}\n' \
		"$NOW" "${V:-null}" "$([ "$M" = 1 ] && echo true || echo false)" "$PP" "$NX" "$NX" "$(date +%s)"
}

do_transport() {
	need_post
	C=$(param cmd)
	case "$C" in
	playpause|next) A=$C ;;
	previous) A=prev ;;
	*) fail "cmd must be playpause, next or previous" ;;
	esac
	[ -x "$TOUCH" ] || fail "transport control is not installed"
	rm -f "$RUN/nowplaying-bt.cache"               # next status asks the phone again
	L=/dev/null; [ -w "$TLOG" ] && L=$TLOG
	( trap '' HUP; "$TOUCH" "$A" ) </dev/null >/dev/null 2>>"$L" &
	json_head
	echo '{"ok":true}'
}

case "$ACTION" in
status) do_status ;;
transport) do_transport ;;
*) fail "unknown action" ;;
esac
