#!/bin/sh
# settings.cgi -- "Start-up and limits" card on the Overview tab.
#   GET  ?action=status
#        -> startup_volume ("last" or 0..100), volume_limit (10..100),
#           idle_standby (30..3600 s): what "homepod-audio setting" prints
#   POST action=set[&startup_volume=last|0..100][&volume_limit=10..100][&idle_standby=30..3600]
#        -> "homepod-audio setting set key=value ...", which checks the values
#           again, applies them and remembers them in /etc/homepod-audio.conf
#           (part of the settings backup). Answers with the new values.
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"
AUDIO=/usr/sbin/homepod-audio

read_request
ACTION=$(param action)

# "key=value" lines on stdin -> JSON members (only the three known keys, checked)
to_json() {
	awk '
	{ p = index($0, "="); if (p > 1) kv[substr($0, 1, p - 1)] = substr($0, p + 1) }
	function intin(v, lo, hi) { return v ~ /^[0-9]+$/ && v + 0 >= lo && v + 0 <= hi }
	END {
		s = kv["startup_volume"]; l = kv["volume_limit"]; t = kv["idle_standby"]
		if (!(s == "last" || intin(s, 0, 100)) || !intin(l, 10, 100) || !intin(t, 30, 3600)) { print "BAD"; exit }
		printf "\"startup_volume\":%s,\"volume_limit\":%d,\"idle_standby\":%d", (s == "last") ? "\"last\"" : s + 0, l, t
	}'
}

answer() {	# answer OUTPUT-OF-setting
	F=$(printf '%s\n' "$1" | to_json)
	[ -n "$F" ] && [ "$F" != BAD ] || fail "homepod-audio printed settings this page does not understand"
	json_head
	printf '{"ok":true,"available":true,%s}\n' "$F"
}

do_status() {
	if [ ! -x $AUDIO ]; then json_head; echo '{"ok":true,"available":false}'; return; fi
	OUT=$(timeout 5 $AUDIO setting 2>/dev/null </dev/null)
	case "$OUT" in
	*startup_volume=*) answer "$OUT" ;;
	*) json_head; echo '{"ok":true,"available":false}' ;;	# an older homepod-audio
	esac
}

do_set() {
	need_post
	[ -x $AUDIO ] || fail "homepod-audio is not installed"
	set --
	V=$(param startup_volume)
	if [ -n "$V" ]; then
		[ "$V" = last ] || { is_int "$V" && [ "$V" -le 100 ]; } || fail "volume after start-up must be \"last\" or 0 to 100"
		set -- "$@" "startup_volume=$V"
	fi
	V=$(param volume_limit)
	if [ -n "$V" ]; then
		is_int "$V" && [ "$V" -ge 10 ] && [ "$V" -le 100 ] || fail "maximum volume must be 10 to 100"
		set -- "$@" "volume_limit=$V"
	fi
	V=$(param idle_standby)
	if [ -n "$V" ]; then
		is_int "$V" && [ "$V" -ge 30 ] && [ "$V" -le 3600 ] || fail "standby time must be 30 to 3600 seconds"
		set -- "$@" "idle_standby=$V"
	fi
	[ $# -gt 0 ] || fail "nothing to change"
	T=$RUN/ui-settings.$$
	mkdir -p $RUN
	timeout 10 $AUDIO setting set "$@" > $T 2> $T.err </dev/null
	RC=$?
	OUT=$(cat $T); E=$(tail -n 1 $T.err | cut -c1-200)
	rm -f $T $T.err
	[ $RC = 0 ] || fail "${E:-the setting was refused (exit status $RC)}"
	case "$OUT" in *startup_volume=*) ;; *) OUT=$(timeout 5 $AUDIO setting 2>/dev/null </dev/null) ;; esac
	answer "$OUT"
}

case "$ACTION" in
''|status) do_status ;;
set) do_set ;;
*) fail "unknown action" ;;
esac
