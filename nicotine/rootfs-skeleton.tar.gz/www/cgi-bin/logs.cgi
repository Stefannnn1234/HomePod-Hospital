#!/bin/sh
# logs.cgi -- Logs panel backend (GET only; nothing here changes anything).
#   ?action=list                         JSON: the logs this page offers and which exist
#   ?action=read&log=NAME[&lines=N][&stats=1]
#                                        text/plain: the last N lines (10..5000, default 200)
#   ?action=download&log=NAME[&stats=1]  the whole log (at most its last 2 MB) as a file
# NAME is one of the fixed names below; the file name never comes from the request.
# In the audio log the feeder's statistics line (one every 5 s) is left out
# unless stats=1.
case "$0" in */*) HERE=${0%/*} ;; *) HERE=. ;; esac
. "$HERE/hplib.sh"
MAXB=2097152

read_request
ACTION=$(param action)

# name -> file ("kernel" is dmesg). Order is the order in the page.
LOGS="kernel audio airplay bluetooth glow nqptp avahi bluetoothd bluealsa dbus"
log_file() {
	case "$1" in
	audio) echo /var/log/homepod-audio.log ;;
	airplay) echo /var/log/shairport-sync.log ;;
	bluetooth) echo /var/log/homepod-bluetooth.log ;;
	glow) echo /var/log/homepod-glow.log ;;
	nqptp) echo /var/log/nqptp.log ;;
	avahi) echo /var/log/avahi.log ;;
	bluetoothd) echo /var/log/bluetoothd.log ;;
	bluealsa) echo /var/log/bluealsa.log ;;
	dbus) echo /var/log/dbus.log ;;
	*) return 1 ;;
	esac
}
log_title() {
	case "$1" in
	kernel) echo "Kernel" ;;
	audio) echo "Amplifiers and audio feeder" ;;
	airplay) echo "AirPlay (shairport-sync)" ;;
	bluetooth) echo "Bluetooth speaker" ;;
	glow) echo "Sound Glow (top light)" ;;
	nqptp) echo "AirPlay clock (nqptp)" ;;
	avahi) echo "Network name (avahi)" ;;
	bluetoothd) echo "Bluetooth stack (bluetoothd)" ;;
	bluealsa) echo "Bluetooth audio (bluealsa)" ;;
	dbus) echo "D-Bus" ;;
	esac
}

# the feeder's 5-second statistics: "hpfeed: play frames=..." / "hpfeed: idle frames=..."
STATS_RE='^hpfeed: (play|idle) frames='

# log source on stdout, never more than the last MAXB bytes
emit() {
	if [ "$1" = kernel ]; then
		timeout 5 dmesg 2>/dev/null </dev/null | tail -c $MAXB
	else
		tail -c $MAXB "$2" 2>/dev/null
	fi
}

pick() {
	L=$(param log)
	case " $LOGS " in *" $L "*) ;; *) fail "unknown log" ;; esac
	F=
	if [ "$L" != kernel ]; then
		F=$(log_file "$L")
		[ -f "$F" ] || fail "this log does not exist (yet): the service has not written anything since the start"
	fi
	STATS=$(param stats)
	case "$STATS" in ''|0) STATS=0 ;; 1) ;; *) fail "stats must be 0 or 1" ;; esac
}

filtered() {	# filtered NAME FILE
	if [ "$1" = audio ] && [ "$STATS" = 0 ]; then
		emit "$1" "$2" | grep -Ev "$STATS_RE"
	else
		emit "$1" "$2"
	fi
}

do_list() {
	json_head
	printf '{"ok":true,"logs":['
	S=
	for L in $LOGS; do
		if [ $L = kernel ]; then E=true; B=null
		else
			F=$(log_file $L)
			if [ -f "$F" ]; then E=true; B=$(wc -c < "$F" | tr -cd 0-9); B=${B:-0}; else E=false; B=null; fi
		fi
		printf '%s{"name":"%s","title":"%s","exists":%s,"bytes":%s}' "$S" $L "$(log_title $L)" $E $B
		S=,
	done
	printf ']}\n'
}

do_read() {
	pick
	N=$(param lines)
	[ -n "$N" ] || N=200
	is_int "$N" && [ "$N" -ge 10 ] && [ "$N" -le 5000 ] || fail "lines must be 10 to 5000"
	printf 'Content-Type: text/plain; charset=utf-8\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n\r\n'
	filtered "$L" "$F" | tail -n "$N"
}

do_download() {
	pick
	U=$(sed -n 's/^\([0-9]*\).*/\1/p' /proc/uptime 2>/dev/null)
	printf 'Content-Type: text/plain; charset=utf-8\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n'
	printf 'Content-Disposition: attachment; filename="%s-%s-up%ss.log"\r\n\r\n' "$(hostname 2>/dev/null | tr -cd 'A-Za-z0-9-' | cut -c1-32)" "$L" "${U:-0}"
	filtered "$L" "$F"
}

[ "$REQUEST_METHOD" = GET ] || [ "$REQUEST_METHOD" = HEAD ] || fail "logs are read with GET"
case "$ACTION" in
''|list) do_list ;;
read) do_read ;;
download) do_download ;;
*) fail "unknown action" ;;
esac
