/*
 * hpdsp3.h - third-pass speaker processing for the HomePod (1st gen),
 * profile "apple3". Same front end and beamformer as hpdsp2.h ("apple2",
 * left untouched); the four dynamics processors are rebuilt from what
 * audioOS 18.3's libAudioDSP.dylib actually does (NOTES-pass3.md has the
 * evidence, function by function):
 *
 *   systemDRC   'mstk'  DspLib::MeisterStueck   4-band compressor       a3_ms_*
 *   bk          'bkng'  DspLib::BassKoenig      bass extension +
 *                                               excursion limiter       a3_bk_*
 *   cfrk0..6 /  'cfrk'  DspLib::ControlFreak    look-ahead peak limiter
 *   bootyFreak                                  with a slow gain stage  a3_cf_*
 *   powerGuard  'appg'  DspLib::PeakPowerGuard  48 V / 12 V rail power
 *                                               limiter                 a3_pg_*
 *
 * Scale. Apple applies the volume digitally in front of this chain and runs
 * the amplifiers at a fixed gain, so that full scale here is 39 V on the
 * woofer and 12.6 V on a tweeter. Linux has the volume in the amplifiers
 * (cfg.volume_db, <= 0). To make every model see the levels it was tuned
 * for, the chain runs at Apple's scale: the input is attenuated by
 * volume_db + aref_db, the result is boosted by -volume_db in front of the
 * DAC, and the peak limiters get a second ceiling so that this boost cannot
 * clip. A unit signal inside the chain is then worth exactly Apple's volts
 * at the speaker terminals, whatever the master volume is.
 *
 * Latency: woofer and tweeters 808 samples (BassKoenig 784 + limiter 24;
 * beamformer 194 + limiter 24 + array delay 590), plus 480 for the power
 * limiter = 1288 samples, 26.8 ms. Apple's echo-reference delay is 1287.
 */
#ifndef HPDSP3_H
#define HPDSP3_H

#include "hpdsp2.h"
#include "apple_b238a_v3.h"

#define A3_BK_N      30          /* NumXchannels */
#define A3_BK_DS     16          /* DownsamplingFactor */
#define A3_BK_LA     45          /* LookaheadDelay 15 ms at 3 kHz */
#define A3_BK_TAPS   129
#define A3_CF_L      24          /* Lookahead 0.5 ms */
#define A3_CF_RING   512
#define A3_PG_DS     12          /* 48 kHz -> 4 kHz, the admittance filter's rate */
#define A3_PG_LA     480         /* Lookahead Time 10 ms */
#define A3_ARRAY_DLY (526 + 256 - A2_MODAL_DELAY)   /* Apple's arrayDelay, plus what hpdsp2 trimmed off the modal FIRs */
#define A3_AREF_DEFAULT (-22.5)  /* same loudness as apple2 (out_db -6) at low level; see NOTES-pass3.md */

/* ------------------------------------------------------------------ */
/* small parts                                                        */
/* ------------------------------------------------------------------ */

/* RBJ / bilinear sections at an arbitrary sample rate. type: 0 LP2, 1 HP2, 2 AP2, 3 LP1, 4 HP1 */
static void a3_bq(struct dbq *q, int type, double f, double Q, double fs)
{
	double w = 2.0 * M_PI * f / fs, c = cos(w), s = sin(w), al = s / (2.0 * Q), k = tan(w / 2.0);

	switch (type) {
	case 0: dbq_coef(q, (1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al); break;
	case 1: dbq_coef(q, (1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al); break;
	case 2: dbq_coef(q, 1 - al, -2 * c, 1 + al, 1 + al, -2 * c, 1 - al); break;
	case 3: dbq_coef(q, k, k, 0, 1 + k, k - 1, 0); break;
	default: dbq_coef(q, 1, -1, 0, 1 + k, k - 1, 0); break;
	}
}

/*
 * Analytic signal by two all-pass chains 90 degrees apart (O. Niemitalo's
 * coefficients, public domain; good from 0.002 fs to 0.498 fs). Apple's
 * EnvelopeProcessor / AnalyticSignalTransform classes do the same job with
 * their own all-pass pairs. Returns the squared envelope.
 */
struct a3_hilb { double a[4][4], b[4][4], d; };

static inline double a3_ap(double c, double *s, double x)
{
	double y = c * (x + s[3]) - s[1];

	s[1] = s[0]; s[0] = x; s[3] = s[2]; s[2] = y;
	return y;
}

static inline double a3_env2(struct a3_hilb *h, double x)
{
	static const double ca[4] = { 0.6923878, 0.9360654322959, 0.9882295226860, 0.9987488452737 };
	static const double cb[4] = { 0.4021921162426, 0.8561710882420, 0.9722909545651, 0.9952884791278 };
	double a = x, b = x, i;
	int k;

	for (k = 0; k < 4; k++) {
		a = a3_ap(ca[k], h->a[k], a);
		b = a3_ap(cb[k], h->b[k], b);
	}
	i = h->d; h->d = a;
	return i * i + b * b;
}

/* DspLib::makeRaisedCosineWindow: w[i] = sin(pi (i+1) / (n+1)), unit sum */
static void a3_window(double *w, int n)
{
	double s = 0;
	int i;

	for (i = 0; i < n; i++) { w[i] = sin(M_PI * (i + 1) / (n + 1)); s += w[i]; }
	for (i = 0; i < n; i++) w[i] /= s;
}

/* ------------------------------------------------------------------ */
/* MeisterStueck                                                      */
/* ------------------------------------------------------------------ */

struct a3_msband {
	double p[13];                   /* B-spline control points: gain at -100, -90 .. 0 dB, clamped ends */
	double sc;                      /* side-chain gain: Apple's "bandwidth compensation" */
	double rel, st, g0, g1, gcur, makeup;
	int src, cnt, det, win, ramp, rampn;
	double e2;                      /* envelope^2 of the current kernel sample */
	double pk[16]; int pkpos;
	struct a3_hilb h[4];
	double box1[24], box2[24], s1, s2; int bpos;
};

struct a3_ms {
	struct dbq lp6[4][4], hp6[4][4], apl[4], aph[4], lp4[4][2], hp4[4][2], lp3[4][2], hp3[4][2];   /* [2], [3]: surround only */
	struct a3_msband b[4];
	double gin, gout;
};

static double a3_ms_static(const double *k, double L)
{
	double g;

	if (L < k[3]) { g = (1.0 - 1.0 / k[4]) * (k[3] - L); if (g > k[5]) g = k[5]; g += k[8]; }
	else if (L < k[0]) g = k[8];
	else { g = (1.0 - 1.0 / k[1]) * (k[0] - L); if (g < k[2]) g = k[2]; g += k[8]; }
	g = pow(10.0, g / 20.0);
	if (L < k[6]) {                 /* the expander only takes back upward gain */
		double e = g * pow(10.0, (k[7] - 1.0) * (L - k[6]) / 20.0), m = pow(10.0, k[8] / 20.0);
		g = e > m ? e : m;
	}
	return g;
}

/* Kernel::gainForEnvelope: uniform cubic B-spline through the 11 table points, 10 dB apart */
static inline double a3_ms_gain(const struct a3_msband *b, double e2)
{
	double x, t, t2, t3;
	const double *p;
	int j;

	if (e2 < 1e-10) e2 = 1e-10;           /* -100 dB: bottom of the table */
	if (e2 > 1.0) e2 = 1.0;
	x = (10.0 * log10(e2) + 100.0) * 0.1;
	if (x < 0.0) x = 0.0;
	j = (int)x; if (j > 9) j = 9;
	t = x - j; t2 = t * t; t3 = t2 * t;
	p = b->p + j;                   /* p[0] = P(j-1) .. p[3] = P(j+2); the array is padded by one at each end */
	return ((1 - 3 * t + 3 * t2 - t3) * p[0] + (4 - 6 * t2 + 3 * t3) * p[1] +
		(1 + 3 * t + 3 * t2 - 3 * t3) * p[2] + t3 * p[3]) / 6.0;
}

static void a3_ms_configure(struct a3_ms *m)
{
	static const double defx[5] = { 0, 100, 1000, 10000, 20000 };
	double fx[5] = { 0, apple_ms_xover[0], apple_ms_xover[1], apple_ms_xover[2], 20000 };
	int ch, i, b;

	for (ch = 0; ch < 4; ch++) {
		/* order 6 at 530 Hz: two 3rd-order Butterworths in series, high band inverted when summed */
		for (i = 0; i < 2; i++) {
			a3_bq(&m->lp6[ch][2 * i], 3, fx[2], 0, DSP_FS); a3_bq(&m->lp6[ch][2 * i + 1], 0, fx[2], 1.0, DSP_FS);
			a3_bq(&m->hp6[ch][2 * i], 4, fx[2], 0, DSP_FS); a3_bq(&m->hp6[ch][2 * i + 1], 1, fx[2], 1.0, DSP_FS);
		}
		/* order 4 at 150 Hz (Linkwitz-Riley), order 3 at 6011 Hz (Butterworth: LP + HP = 2nd-order all-pass, Q 1) */
		for (i = 0; i < 2; i++) {
			a3_bq(&m->lp4[ch][i], 0, fx[1], M_SQRT1_2, DSP_FS);
			a3_bq(&m->hp4[ch][i], 1, fx[1], M_SQRT1_2, DSP_FS);
		}
		a3_bq(&m->lp3[ch][0], 3, fx[3], 0, DSP_FS); a3_bq(&m->lp3[ch][1], 0, fx[3], 1.0, DSP_FS);
		a3_bq(&m->hp3[ch][0], 4, fx[3], 0, DSP_FS); a3_bq(&m->hp3[ch][1], 1, fx[3], 1.0, DSP_FS);
		a3_bq(&m->apl[ch], 2, fx[3], 1.0, DSP_FS);          /* what the 6011 Hz split does to the upper half */
		a3_bq(&m->aph[ch], 2, fx[1], M_SQRT1_2, DSP_FS);    /* what the 150 Hz split does to the lower half */
	}
	for (b = 0; b < 4; b++) {
		struct a3_msband *q = &m->b[b];
		const double *k = apple_ms_band[b];
		double fsk, r;

		for (i = 0; i < 11; i++)
			q->p[i + 1] = a3_ms_static(k, -100.0 + 10.0 * i);
		q->p[0] = q->p[1]; q->p[12] = q->p[11];
		q->makeup = pow(10.0, k[8] / 20.0);
		q->sc = (defx[b + 1] - defx[b]) / (fx[b + 1] - fx[b]);
		/* MeisterStueck::Algorithm::setSRCParameters, aliasing damping 80 dB: the lower bands run decimated */
		r = b < 3 ? DSP_FS / (2.0 * fx[b + 1] * pow(2.0, 80.0 / (6.0 * apple_ms_order[b]))) : 1.0;
		q->src = r < 1.0 ? 1 : (int)r;
		fsk = DSP_FS / q->src;
		q->win = ((int)floor(fsk * 2.0 / 1000.0 / 8.0 + 0.5)) | 1;        /* peak window 2 ms, detector at 1/8 */
		if (q->win > 16) q->win = 16;
		q->rel = 1.0 - exp(-1.0 / (APPLE_MS_RELEASE_MS * (fsk / 8.0) / 1000.0));
		q->rampn = q->src * 8;
	}
	m->gin = pow(10.0, APPLE_MS_IN_DB / 20.0);
	m->gout = pow(10.0, APPLE_MS_OUT_DB / 20.0);
}

static void a3_ms_clear(struct a3_ms *m)
{
	int b, i;

	memset(m, 0, sizeof(*m));
	for (b = 0; b < 4; b++) {
		struct a3_msband *q = &m->b[b];

		q->st = q->g0 = q->g1 = q->gcur = 1.0;
		for (i = 0; i < 24; i++) q->box1[i] = q->box2[i] = 1.0;
		q->s1 = q->s2 = 24.0;
	}
}

/* x[0], x[1]: the two programme channels (sum and difference); compressed in place, linked */
static inline void a3_ms_run(struct a3_ms *m, double *x, int on, double *gr_db)
{
	double band[2][4], lo, hi, g;
	int ch, b, i;

	for (ch = 0; ch < 2; ch++) {
		double in = x[ch] * m->gin;

		lo = hi = in;
		for (i = 0; i < 4; i++) { lo = dbq_run(&m->lp6[ch][i], lo); hi = dbq_run(&m->hp6[ch][i], hi); }
		lo = dbq_run(&m->apl[ch], lo);
		hi = -dbq_run(&m->aph[ch], hi);
		band[ch][0] = dbq_run(&m->lp4[ch][1], dbq_run(&m->lp4[ch][0], lo));
		band[ch][1] = dbq_run(&m->hp4[ch][1], dbq_run(&m->hp4[ch][0], lo));
		band[ch][2] = dbq_run(&m->lp3[ch][1], dbq_run(&m->lp3[ch][0], hi));
		band[ch][3] = dbq_run(&m->hp3[ch][1], dbq_run(&m->hp3[ch][0], hi));
	}
	x[0] = x[1] = 0.0;
	for (b = 0; b < 4; b++) {
		struct a3_msband *q = &m->b[b];

		if (++q->cnt >= q->src) {               /* one kernel sample */
			double e0 = a3_env2(&q->h[0], band[0][b]), e1 = a3_env2(&q->h[1], band[1][b]);

			q->cnt = 0;
			q->e2 = e0 > e1 ? e0 : e1;
			if (++q->det >= 8) {                    /* one detector sample */
				double pk = 0;

				q->det = 0;
				q->pk[q->pkpos] = q->e2;
				if (++q->pkpos >= q->win) q->pkpos = 0;
				for (i = 0; i < q->win; i++) if (q->pk[i] > pk) pk = q->pk[i];
				g = on ? a3_ms_gain(q, pk * q->sc * q->sc) : q->makeup;
				if (g < q->st) q->st = g; else q->st += (g - q->st) * q->rel;
				q->g0 = q->gcur; q->g1 = q->st; q->ramp = 0;
				if (gr_db) gr_db[b] = 20.0 * log10(q->st / q->makeup);
			}
		}
		/* linear interpolation over one detector period, then about 1 ms of smoothing */
		if (q->ramp < q->rampn) { q->ramp++; q->gcur = q->g0 + (q->g1 - q->g0) * q->ramp / q->rampn; }
		q->s1 += q->gcur - q->box1[q->bpos]; q->box1[q->bpos] = q->gcur;
		g = q->s1 / 24.0;
		q->s2 += g - q->box2[q->bpos]; q->box2[q->bpos] = g;
		if (++q->bpos >= 24) q->bpos = 0;
		g = q->s2 / 24.0;
		x[0] += band[0][b] * g;
		x[1] += band[1][b] * g;
	}
	x[0] *= m->gout;
	x[1] *= m->gout;
}

/* the same compressor over n channels (4 with a surround source), linked the same way: the loudest one counts */
static inline void a3_ms_run_n(struct a3_ms *m, double *x, int n, int on, double *gr_db)
{
	double band[4][4], lo, hi, g;
	int ch, b, i;

	for (ch = 0; ch < n; ch++) {
		double in = x[ch] * m->gin;

		lo = hi = in;
		for (i = 0; i < 4; i++) { lo = dbq_run(&m->lp6[ch][i], lo); hi = dbq_run(&m->hp6[ch][i], hi); }
		lo = dbq_run(&m->apl[ch], lo);
		hi = -dbq_run(&m->aph[ch], hi);
		band[ch][0] = dbq_run(&m->lp4[ch][1], dbq_run(&m->lp4[ch][0], lo));
		band[ch][1] = dbq_run(&m->hp4[ch][1], dbq_run(&m->hp4[ch][0], lo));
		band[ch][2] = dbq_run(&m->lp3[ch][1], dbq_run(&m->lp3[ch][0], hi));
		band[ch][3] = dbq_run(&m->hp3[ch][1], dbq_run(&m->hp3[ch][0], hi));
		x[ch] = 0.0;
	}
	for (b = 0; b < 4; b++) {
		struct a3_msband *q = &m->b[b];

		if (++q->cnt >= q->src) {               /* one kernel sample */
			double e = 0.0;

			for (ch = 0; ch < n; ch++) {
				double ec = a3_env2(&q->h[ch], band[ch][b]);

				if (ec > e) e = ec;
			}
			q->cnt = 0;
			q->e2 = e;
			if (++q->det >= 8) {                    /* one detector sample */
				double pk = 0;

				q->det = 0;
				q->pk[q->pkpos] = q->e2;
				if (++q->pkpos >= q->win) q->pkpos = 0;
				for (i = 0; i < q->win; i++) if (q->pk[i] > pk) pk = q->pk[i];
				g = on ? a3_ms_gain(q, pk * q->sc * q->sc) : q->makeup;
				if (g < q->st) q->st = g; else q->st += (g - q->st) * q->rel;
				q->g0 = q->gcur; q->g1 = q->st; q->ramp = 0;
				if (gr_db) gr_db[b] = 20.0 * log10(q->st / q->makeup);
			}
		}
		if (q->ramp < q->rampn) { q->ramp++; q->gcur = q->g0 + (q->g1 - q->g0) * q->ramp / q->rampn; }
		q->s1 += q->gcur - q->box1[q->bpos]; q->box1[q->bpos] = q->gcur;
		g = q->s1 / 24.0;
		q->s2 += g - q->box2[q->bpos]; q->box2[q->bpos] = g;
		if (++q->bpos >= 24) q->bpos = 0;
		g = q->s2 / 24.0;
		for (ch = 0; ch < n; ch++)
			x[ch] += band[ch][b] * g;
	}
	for (ch = 0; ch < n; ch++)
		x[ch] *= m->gout;
}

/* ------------------------------------------------------------------ */
/* BassKoenig                                                         */
/* ------------------------------------------------------------------ */

struct a3_bkch { struct dbq hp, m0, m1; struct a3_hilb h; float dl[64]; };

struct a3_bk {
	struct dbq inv[3], mm[2];        /* mm: the model once more, on the output, for the meter */
	struct a3_bkch ch[A3_BK_N];
	double gain, thr2, att, rel, state, minidx, start, win[A3_BK_LA];
	float idx[64], ih[16], ic[A3_BK_DS][9];
	int pos, ipos, phase;
	int designed;                   /* win[] and ic[][] are filled in */
	double xdc;                     /* mm per volt at DC, for the meter */
	double m_idx, m_x2, m_xo;
	double m_x2p, m_xop;            /* plain maxima of m_x2 / m_xo since a3_peek() last read them (meter2) */
};

/*
 * BassKoenig::calculateLoudspeakerModelCoefficientsImproved. Voltage to cone
 * excursion (mm/V) of the driver in its closed box,
 *   x/V = (1/Bl) / [ (Re + Le s)(Mm s^2 + Rm s + K) / Bl^2 + s ],  K = 1/Cm + rho c^2 Sd^2 / Vab,
 * bilinear transform without pre-warping, the three poles found in closed
 * form; Apple keeps the poles and a plain gain. mdl[2]: the model, inv[3]:
 * the "inverse box filter" (the model's poles as zeros, times a 2nd-order
 * low-pass at `cut` that stands in for a double integrator).
 */
static void a3_bk_model(const double *p, double fs, double gain_db, double cut, struct dbq *mdl, struct dbq *inv, double *xdc)
{
	double Sd = p[23] / 1e4, Bl = p[21], Cm = p[20] / 1e3, Vab = p[22] / 1e3;
	double Re = p[16], Le = p[17] / 1e3, Mm = p[18] / 1e3, Rm = p[19];
	double K = 1.0 / Cm + 140002.0 * Sd * Sd / Vab;
	double a3 = Le / (Bl * Bl) * Mm, a2 = Re / (Bl * Bl) * Mm + Le / (Bl * Bl) * Rm;
	double a1 = Le / (Bl * Bl) * K + Re / (Bl * Bl) * Rm + 1.0, a0 = Re / (Bl * Bl) * K;
	double f1 = 2 * fs * a1, f2 = 4 * fs * fs * a2, f3 = 8 * fs * fs * fs * a3;
	double D0 = a0 + f1 + f2 + f3, c1 = (3 * a0 + f1 - f2 - 3 * f3) / D0;
	double c2 = (3 * a0 - f1 - f2 + 3 * f3) / D0, c3 = (a0 - f1 + f2 - f3) / D0;
	double pp = c2 - c1 * c1 / 3.0, qq = c3 + 2.0 * c1 * c1 * c1 / 27.0 - c1 * c2 / 3.0;
	double sd = sqrt(fabs(pp * pp * pp / 27.0 + qq * qq / 4.0));
	double u = cbrt(-qq / 2.0 + sd), v = cbrt(-qq / 2.0 - sd);
	double r1 = -c1 / 3.0 + (u + v), re = -c1 / 3.0 - (u + v) / 2.0, im = (u - v) * sqrt(3.0) / 2.0;
	double b0, g, dcm, dcf, w, al;

	if (r1 > 0.9999) r1 = 0.9999;
	if (r1 < -0.9999) r1 = -0.9999;
	if (re > 0.999) re = 0.999;
	if (re < -0.9999) re = -0.9999;
	b0 = 8000.0 / (Bl * D0);
	dbq_coef(&mdl[0], b0, 0, 0, 1, -r1, 0);
	dbq_coef(&mdl[1], 1, 0, 0, 1, -2 * re, re * re + im * im);
	dcf = (1 - r1) * (1 - 2 * re + re * re + im * im);
	dcm = b0 / dcf;
	g = dcm / dcf * pow(10.0, gain_db / 20.0);
	if (g > 1e8) g = 1e8;
	if (g < 1.0) g = 1.0;
	dbq_coef(&inv[0], g, -g * r1, 0, 1, 0, 0);
	dbq_coef(&inv[1], 1, -2 * re, re * re + im * im, 1, 0, 0);
	/* Biquad::Design::integrator(2, cut, 45, fs): all-pole, unit gain at DC, (45/f)^2 far above `cut` */
	w = 2 * M_PI * cut / fs; al = sin(w) * 0.622751;
	dbq_coef(&inv[2], 2 * (1 - cos(w)) * (45.0 / cut) * (45.0 / cut), 0, 0, 1 + al, -2 * cos(w), 1 - al);
	*xdc = dcm;
}

/* xlim in mm, start in Hz (both move with the thermal "control effort"); vfs = volts at unit signal */
static void a3_bk_configure(struct a3_bk *b, double xlim, double start, double vfs, int limiter)
{
	const double *p = apple_bk;
	double fs = DSP_FS / A3_BK_DS, f = start, ratio, h[A3_BK_TAPS], s = 0, beta = 6.0, i0b, t;
	struct dbq mdl[2];
	int i, k;

	b->gain = pow(10.0, p[0] / 20.0) * (p[49] > 0.5 ? -1.0 : 1.0);
	b->start = start;
	a3_bk_model(p, fs, p[67], p[68], mdl, b->inv, &b->xdc);
	ratio = exp(log(p[5] / start) / (A3_BK_N - 1));
	for (i = 0; i < A3_BK_N; i++, f *= ratio) {
		a3_bq(&b->ch[i].hp, 1, f, p[15], fs);
		b->ch[i].m0.b0 = mdl[0].b0; b->ch[i].m0.b1 = mdl[0].b1; b->ch[i].m0.b2 = mdl[0].b2;
		b->ch[i].m0.a1 = mdl[0].a1; b->ch[i].m0.a2 = mdl[0].a2;
		b->ch[i].m1.b0 = mdl[1].b0; b->ch[i].m1.b1 = mdl[1].b1; b->ch[i].m1.b2 = mdl[1].b2;
		b->ch[i].m1.a1 = mdl[1].a1; b->ch[i].m1.a2 = mdl[1].a2;
	}
	for (i = 0; i < 2; i++) {
		b->mm[i].b0 = mdl[i].b0; b->mm[i].b1 = mdl[i].b1; b->mm[i].b2 = mdl[i].b2;
		b->mm[i].a1 = mdl[i].a1; b->mm[i].a2 = mdl[i].a2;
	}
	t = limiter ? xlim / vfs : 1e9;
	b->thr2 = t * t;
	b->att = 1.0 - exp(-1.0 / (fs * p[44] / 1000.0));
	if (b->att > 0.102) b->att = 0.102;
	b->rel = 1.0 - exp(-1.0 / (fs * p[45] / 1000.0));
	/*
	 * Up-sampler: 129 taps like Apple's kSRCcoeffs, but our own design
	 * (Kaiser-windowed sinc, -6 dB at 1350 Hz); same length, same delay.
	 * It never changes, and designing it takes over a millisecond on the A8
	 * (enough to underrun the feeder), so it is done once: a settings reload
	 * in the audio loop must stay cheap.
	 */
	if (b->designed)
		return;
	b->designed = 1;
	a3_window(b->win, A3_BK_LA);
	i0b = 0;
	for (k = 0; k < 25; k++) { double tt = pow(beta / 2.0, k) / tgamma(k + 1.0); i0b += tt * tt; }
	for (i = 0; i < A3_BK_TAPS; i++) {
		double n = i - 64.0, r = n / 64.0, wv = 0, arg = beta * sqrt(1.0 - r * r), fc = 1350.0 / DSP_FS;

		for (k = 0; k < 25; k++) { double tt = pow(arg / 2.0, k) / tgamma(k + 1.0); wv += tt * tt; }
		h[i] = (n == 0 ? 2 * fc : sin(2 * M_PI * fc * n) / (M_PI * n)) * wv / i0b;
		s += h[i];
	}
	for (i = 0; i < A3_BK_DS; i++)
		for (k = 0; k < 9; k++)
			b->ic[i][k] = i + 16 * k < A3_BK_TAPS ? (float)(h[i + 16 * k] * A3_BK_DS / s) : 0.0f;
}

static inline double a3_bk_run(struct a3_bk *b, double x)
{
	const float *c;
	double y = 0;
	int i, k;

	if (b->phase == 0) {
		double X = dbq_run(&b->inv[2], dbq_run(&b->inv[1], dbq_run(&b->inv[0], x * b->gain)));
		double out[A3_BK_N], cnt = 0, s = 0, fr;
		int p = b->pos, rd = (p + 64 - A3_BK_LA) & 63, j;

		for (i = 0; i < A3_BK_N; i++) {
			struct a3_bkch *c2 = &b->ch[i];
			double hp = dbq_run(&c2->hp, X);
			double e2 = a3_env2(&c2->h, dbq_run(&c2->m1, dbq_run(&c2->m0, hp)));

			if (i < A3_BK_N - 1 && e2 > b->thr2) cnt += 1.0;
			if (i == 0) {
				b->m_x2 = e2 > b->m_x2 ? e2 : b->m_x2 * 0.9995;
				if (e2 > b->m_x2p) b->m_x2p = e2;
			}
			out[i] = c2->dl[rd];
			c2->dl[p] = (float)hp;
		}
		if (cnt > b->state) b->state += (cnt - b->state) * b->att;
		else b->state += (cnt - b->state) * b->rel;
		b->idx[p] = (float)(b->state > b->minidx ? b->state : b->minidx);
		for (k = 0; k < A3_BK_LA; k++)
			s += b->win[k] * b->idx[(p - k) & 63];
		b->pos = (p + 1) & 63;
		b->m_idx = s;
		j = (int)s; if (j > A3_BK_N - 2) j = A3_BK_N - 2;
		fr = s - j; if (fr > 1.0) fr = 1.0;
		b->ipos = (b->ipos + 1) & 15;
		X = out[j] * (1.0 - fr) + out[j + 1] * fr;
		b->ih[b->ipos] = (float)X;
		X = fabs(dbq_run(&b->mm[1], dbq_run(&b->mm[0], X)));
		b->m_xo = X > b->m_xo ? X : b->m_xo * 0.9995;
		if (X > b->m_xop) b->m_xop = X;
	}
	c = b->ic[b->phase];
	for (k = 0; k < 9; k++)
		y += c[k] * b->ih[(b->ipos - k) & 15];
	b->phase = (b->phase + 1) & (A3_BK_DS - 1);
	return y;
}

/* ------------------------------------------------------------------ */
/* ControlFreak                                                       */
/* ------------------------------------------------------------------ */

struct a3_cf {
	double thr, gmf, ingain, win[A3_CF_L];
	double slow, relmin, relmax, relcur, msq, cms, ref, wnd;
	int W, active, hold, tick, idle;
	unsigned n;
	float dly[32], gh[32];
	float qv[A3_CF_RING]; unsigned qi[A3_CF_RING], qh, qt;      /* monotonic queue for the sliding maximum */
	int pos;
	long hits;
	double m_slow;
};

static void a3_cf_configure(struct a3_cf *c, const double *ap, double thr_db, double ingain_db)
{
	int rel = (int)floor(DSP_FS * ap[2] / 1000.0 + 0.5);

	c->thr = pow(10.0, (thr_db - 2e-5) / 20.0);
	c->gmf = pow(10.0, -ap[1] / 20.0);
	c->ingain = pow(10.0, ingain_db / 20.0);
	c->W = ((A3_CF_L + rel) & ~1) + 2;
	if (c->W > A3_CF_RING - 2) c->W = A3_CF_RING - 2;
	a3_window(c->win, A3_CF_L);
	c->relmin = 1.0 - exp(-1.0 / (DSP_FS * 0.270));         /* SlowGainReleaseTimeMinimum / Maximum (defaults) */
	c->relmax = 1.0 - exp(-1.0 / (DSP_FS * 10.0));
	c->cms = 1.0 - exp(-1.0 / (DSP_FS * 0.030));            /* EnvelopeAveragingTime */
	c->wnd = pow(10.0, 10.0 / 40.0);                        /* AudioActivityWindowSize 10 (dB), +-5 */
	if (c->relcur == 0.0) c->relcur = c->relmax;
}

static void a3_cf_clear(struct a3_cf *c)
{
	int i;

	memset(c, 0, sizeof(*c));
	c->slow = c->m_slow = 1.0; c->idle = 1 << 20;
	for (i = 0; i < 32; i++) c->gh[i] = 1.0f;
}

static inline double a3_cf_run(struct a3_cf *c, double x, int on)
{
	double pk, m, greq, t, g, y;
	int p = c->pos, k;

	x *= c->ingain;
	y = c->dly[(p + 32 - A3_CF_L) & 31];
	c->dly[p] = (float)x;
	c->pos = (p + 1) & 31;
	c->n++;
	pk = fabs(x);
	/* activity detector: 30 ms mean square, looked at every 40 samples (Apple: 4 x 10 decimation) */
	c->msq += (x * x - c->msq) * c->cms;
	if (++c->tick >= 40) {
		double lv = sqrt(c->msq);

		c->tick = 0;
		if (lv > c->ref * c->wnd) { c->ref = lv; c->hold += 10; }
		else if (lv < c->ref / c->wnd) c->ref = lv;
		if (c->hold > 0) { c->hold--; c->relcur = c->relmin; } else c->relcur = c->relmax;
	}
	/* sliding maximum over W samples; only peaks above the threshold can matter, so only those are queued */
	if (pk > c->thr) {
		while (c->qh != c->qt && c->qv[(c->qt - 1) & (A3_CF_RING - 1)] <= pk) c->qt--;
		c->qv[c->qt & (A3_CF_RING - 1)] = (float)pk; c->qi[c->qt & (A3_CF_RING - 1)] = c->n; c->qt++;
	}
	m = 0.0;
	if (c->qh != c->qt) {
		if (c->n - c->qi[c->qh & (A3_CF_RING - 1)] >= (unsigned)c->W) c->qh++;
		if (c->qh != c->qt) m = c->qv[c->qh & (A3_CF_RING - 1)];
	}
	if (!on) return y;
	if (m <= c->thr && !c->active) {
		if (c->idle > A3_CF_L) { c->gh[p & 31] = 1.0f; return y; }      /* nothing to do, nothing in the smoother */
		greq = 1.0;
	} else
		greq = c->thr / (m > c->thr ? m : c->thr);
	/* slow gain: whatever the fast stage is not allowed to take (MinFastGain) */
	t = greq / c->gmf; if (t > 1.0) t = 1.0;
	if (t < 0.99) c->active = 1; else if (c->slow > 0.99) c->active = 0;
	if (c->active) {
		if (t < c->slow) c->slow = t; else c->slow += (t - c->slow) * c->relcur;
		t = c->slow;
	} else
		c->slow = 1.0;
	g = (greq < c->gmf ? c->gmf : greq) * t;

	if (g < 1.0) { c->idle = 0; c->hits++; } else c->idle++;
	c->m_slow = c->active ? c->slow : 1.0;
	c->gh[p & 31] = (float)g;
	g = 0;
	for (k = 0; k < A3_CF_L; k++)
		g += c->win[k] * c->gh[(p - k) & 31];
	return y * g;
}

/* ------------------------------------------------------------------ */
/* PeakPowerGuard                                                     */
/* ------------------------------------------------------------------ */

struct a3_pg {
	double vw, kt, effw, conv, qw, qt, l48[4], l12[4], gminw, gmint, relw, relt;
	float vh[1024]; int vpos;       /* woofer volts at 4 kHz, doubled ring for the admittance FIR */
	float pw[256]; int ppos; double sw[4];
	float pt[4096]; int tpos; double st[4];
	float dl[8][512]; int dpos;
	int phase, on;
	double stw, stt, gw0, gw1, gt0, gt1, lpw[2], lpt[2], clp;
	double m_p48, m_p12, m_gw, m_gt;
	double m_p48p, m_p12p;          /* maxima of m_p48 / m_p12 since a3_peek() last read them (meter2) */
	double pavg, pavg_a;            /* 48 V supply power, one-pole average with a 10 s time constant */
};

/* vw, vt: volts at unit signal for woofer and tweeters; wltc: 48 V limit at the main time constant */
static void a3_pg_configure(struct a3_pg *g, double vw, double vt, double wltc, int on)
{
	const double *p = apple_pg;
	double fs = DSP_FS / A3_PG_DS;

	g->on = on && p[0] < 0.5;
	g->vw = vw;
	g->kt = vt * vt / p[6] * (100.0 / p[4]);                /* V^2 / R / efficiency, per tweeter */
	g->effw = 100.0 / p[18];
	g->conv = 100.0 / p[20];
	g->qw = p[19]; g->qt = p[5];
	g->l48[0] = wltc; g->l48[1] = p[27]; g->l48[2] = p[26]; g->l48[3] = p[25];
	g->l12[0] = p[14]; g->l12[1] = p[13]; g->l12[2] = p[12]; g->l12[3] = p[11];
	g->gminw = pow(10.0, p[29] / 20.0);
	g->gmint = pow(10.0, p[15] / 20.0);
	g->relw = 1.0 - exp(-1.0 / (p[30] * fs / 1000.0));
	g->relt = 1.0 - exp(-1.0 / (p[16] * fs / 1000.0));
	g->clp = 1.0 - exp(-2.0 * M_PI * 50.0 / DSP_FS);       /* "Modulator low pass frequency", default 50 Hz */
	g->pavg_a = 1.0 - exp(-1.0 / (10.0 * fs));
}

static void a3_pg_clear(struct a3_pg *g)
{
	memset(g, 0, sizeof(*g));
	g->stw = g->stt = g->gw0 = g->gw1 = g->gt0 = g->gt1 = 1.0;
	g->lpw[0] = g->lpw[1] = g->lpt[0] = g->lpt[1] = 1.0;
}

/* v[0] woofer, v[1..7] tweeters, in place */
static inline void a3_pg_run(struct a3_pg *g, double *v)
{
	static const int wl[4] = { 256, 128, 64, 32 };          /* 64 ms moving average and /2 /4 /8, at 4 kHz */
	double s2 = 0, gw, gt, fr;
	float f2;
	int k, i, p = g->dpos;

	for (k = 1; k < 8; k++) s2 += v[k] * v[k];
	f2 = (float)s2;
	/* tweeter rail: moving sums at 48 kHz */
	for (i = 0; i < 4; i++)
		g->st[i] += (double)f2 - g->pt[(g->tpos - wl[i] * A3_PG_DS) & 4095];
	g->pt[g->tpos] = f2;
	g->tpos = (g->tpos + 1) & 4095;

	if (g->phase == 0) {
		double vw = v[0] * g->vw, cur = 0, pwr, g2w = 1.0, g2t = 1.0;
		const float *h;

		g->vpos = (g->vpos + 511) & 511;                /* newest first, so the FIR runs forward */
		g->vh[g->vpos] = g->vh[g->vpos + 512] = (float)vw;
		h = &g->vh[g->vpos];
		cur = a2_fir(apple_adm_fir, h, 512);            /* the 513th tap is 3e-6 of the first: dropped */
		pwr = (float)(vw * cur);                        /* instantaneous electrical power into the woofer */
		for (i = 0; i < 4; i++)
			g->sw[i] += pwr - g->pw[(g->ppos - wl[i]) & 255];
		g->pw[g->ppos] = (float)pwr;
		g->ppos = (g->ppos + 1) & 255;
		for (i = 0; i < 4; i++) {
			double p12 = g->st[i] / (wl[i] * A3_PG_DS) * g->kt + g->qt;
			double p48 = g->sw[i] / wl[i] * g->effw + g->qw + p12 * g->conv, r;

			if (i == 0) {
				g->m_p48 = p48; g->m_p12 = p12; g->pavg += (p48 - g->pavg) * g->pavg_a;
				if (p48 > g->m_p48p) g->m_p48p = p48;
				if (p12 > g->m_p12p) g->m_p12p = p12;
			}
			r = p48 < g->l48[i] ? 1.0 : g->l48[i] / p48;
			if (r < g->gminw * g->gminw) r = g->gminw * g->gminw;
			if (r < g2w) g2w = r;
			r = p12 < g->l12[i] ? 1.0 : g->l12[i] / p12;
			if (r < g->gmint * g->gmint) r = g->gmint * g->gmint;
			if (r < g2t) g2t = r;
		}
		gw = sqrt(g2w); gt = sqrt(g2t);
		if (gw < g->stw) g->stw = gw; else g->stw += (1.0 - g->stw) * g->relw;
		if (gt < g->stt) g->stt = gt; else g->stt += (1.0 - g->stt) * g->relt;
		g->gw0 = g->gw1; g->gw1 = g->stw;
		g->gt0 = g->gt1; g->gt1 = g->stt;
	}
	fr = (g->phase + 1) / (double)A3_PG_DS;
	g->phase = (g->phase + 1) % A3_PG_DS;
	gw = g->gw0 + (g->gw1 - g->gw0) * fr;
	gt = g->gt0 + (g->gt1 - g->gt0) * fr;
	g->lpw[0] += (gw - g->lpw[0]) * g->clp; g->lpw[1] += (g->lpw[0] - g->lpw[1]) * g->clp;
	g->lpt[0] += (gt - g->lpt[0]) * g->clp; g->lpt[1] += (g->lpt[0] - g->lpt[1]) * g->clp;
	g->m_gw = g->lpw[1]; g->m_gt = g->lpt[1];
	if (!g->on) { g->lpw[1] = g->lpt[1] = 1.0; }
	for (k = 0; k < 8; k++) {
		double y = g->dl[k][(p - A3_PG_LA) & 511];

		g->dl[k][p] = (float)v[k];
		v[k] = y * (k ? g->lpt[1] : g->lpw[1]);
	}
	g->dpos = (p + 1) & 511;
}

/* ------------------------------------------------------------------ */
/* user EQ (dsp.conf eq= eq_pre= eq0..eq9=)                           */
/* ------------------------------------------------------------------ */
/*
 * Up to ten RBJ "Audio EQ Cookbook" sections in their Q form (peakingEQ,
 * lowShelf, highShelf; shelf slope through Q), fs = 48 kHz, the same
 * coefficients on mid and side. Direct form I, so that the state is plain
 * signal history and coefficients can move while the music plays.
 *
 * No clicks. A change of settings moves every band over A3_EQ_RAMP samples
 * (20 ms; 40 ms when a band changes type) through its parameters (gain in dB, frequency and Q on a log
 * scale); the band is redesigned every A3_EQ_SEG samples and its
 * coefficients move linearly in between (at most ten designs per 16
 * samples, a few microseconds, during those 20 ms only).
 *  - A band that appears starts as pass-through, moves its coefficients
 *    linearly to the 0 dB section of its type (a cookbook section at 0 dB
 *    has numerator = denominator, and so has every point on that line: the
 *    response stays exactly 1), then its gain goes up.
 *  - A band that goes away goes down to 0 dB; what is left in its output
 *    then is a small, smooth remainder of the change (y - x), which is
 *    cross-faded out (the output fades from y to x) before the section is
 *    dropped.
 *  - A band that changes type does the second, then (its output being x
 *    exactly, its history set to x) the first.
 * Interpolating coefficients from the old section to the new one directly
 * is not good enough: for a low shelf it moves the bass gain within the
 * first percent of the ramp, and pulling a 0 dB section's poles in to
 * pass-through dumps the remainder at once; both show as clicks in
 * tests/dsp4test.c ramp.
 * A section joins with an empty history and two samples of pass-through
 * before it moves. A change that arrives during a ramp waits for its end
 * (at most 20 ms). eq_pre ramps linearly in amplitude over the same time.
 * Switching the EQ off ends with every section at pass-through; only then
 * is the EQ taken out of the signal path, so with eq=0 the path is exactly
 * what it was before the EQ existed.
 *
 * Cost: only sections that are not pass-through are run (act[]), 5
 * multiply-adds per section and channel. a3_eq_set() returns at once when
 * nothing changed and designs nothing itself.
 */
#define A3_EQ_N    10
#define A3_EQ_RAMP 960                  /* 20 ms */
#define A3_EQ_SEG  16                   /* redesign interval during a ramp; divides A3_EQ_RAMP */
#define A3_EQ_WARM 2                    /* pass-through samples before a ramp moves (fills a new section's history) */

enum { A3_EQ_OFF, A3_EQ_PEAK, A3_EQ_LOWSHELF, A3_EQ_HIGHSHELF };
enum { A3_EQK_NONE, A3_EQK_JOIN, A3_EQK_LEAVE, A3_EQK_SWAP, A3_EQK_MORPH };

/* ramp phases, as fractions of the ramp (multiples of A3_EQ_SEG / A3_EQ_RAMP where a segment must start) */
#define A3_EQ_J1   0.25                 /* join: pass-through -> 0 dB section until here, then the gain goes up */
#define A3_EQ_L1   0.5                  /* leave: gain down until here, then the cross-fade to the input (10 ms) */
#define A3_EQ_S1   0.2                  /* swap: old gain down until S1, fade out until S2 (= 0.5, a segment start), */
#define A3_EQ_S2   0.5                  /*       new section 0 dB from pass-through until S3, gain up */
#define A3_EQ_S3   0.6

struct a3_eqband { int type; double f, g, q; };              /* Hz, dB, Q */
struct a3_eqset { int on; double pre_db; struct a3_eqband b[A3_EQ_N]; };

struct a3_eq {
	struct a3_eqset set;            /* the settings being applied */
	struct a3_eqset pset;           /* arrived during a ramp: applied when it ends */
	int pend;
	struct a3_eqband from[A3_EQ_N], to[A3_EQ_N];     /* the ramp, band by band (type OFF = pass-through) */
	int kind[A3_EQ_N];              /* A3_EQK_*: how band k gets from `from` to `to` */
	double byp[A3_EQ_N];            /* while ramping: how much of the section's input replaces its output */
	double c[A3_EQ_N][5];           /* current b0 b1 b2 a1 a2 (normalised, a0 = 1) */
	double dc[A3_EQ_N][5];          /* step per sample in the current segment */
	double s[A3_EQ_N][4][4];        /* state per section and channel: x1 x2 y1 y2 ([2], [3]: surround only) */
	double g, g0, gt;               /* linear gain in front (eq_pre): current, at ramp start, target */
	int act[A3_EQ_N], nact;         /* sections that are run, in band order */
	int ramp;                       /* samples left in the current ramp */
	int rlen;                       /* its length: A3_EQ_RAMP, twice that when a band changes type */
	int run;                        /* 0: not in the signal path at all */
	int init;
};

static inline int a3_eq_isoff(const struct a3_eqband *b) { return b->type == A3_EQ_OFF || b->g == 0.0; }

/* RBJ cookbook, Q form, normalised by a0. Type OFF gives pass-through; 0 dB gives numerator = denominator. */
static void a3_eq_design(const struct a3_eqband *b, double fs, double *c)
{
	double A, w, cs, al, sq, a0, b0, b1, b2, a1, a2;

	c[0] = 1.0; c[1] = c[2] = c[3] = c[4] = 0.0;
	if (b->type == A3_EQ_OFF)
		return;
	A = pow(10.0, b->g / 40.0);
	w = 2.0 * M_PI * b->f / fs; cs = cos(w); al = sin(w) / (2.0 * b->q); sq = 2.0 * sqrt(A) * al;
	switch (b->type) {
	case A3_EQ_PEAK:
		b0 = 1 + al * A; b1 = -2 * cs; b2 = 1 - al * A;
		a0 = 1 + al / A; a1 = -2 * cs; a2 = 1 - al / A;
		break;
	case A3_EQ_LOWSHELF:
		b0 = A * ((A + 1) - (A - 1) * cs + sq); b1 = 2 * A * ((A - 1) - (A + 1) * cs); b2 = A * ((A + 1) - (A - 1) * cs - sq);
		a0 = (A + 1) + (A - 1) * cs + sq; a1 = -2 * ((A - 1) + (A + 1) * cs); a2 = (A + 1) + (A - 1) * cs - sq;
		break;
	default:                        /* high shelf */
		b0 = A * ((A + 1) + (A - 1) * cs + sq); b1 = -2 * A * ((A - 1) + (A + 1) * cs); b2 = A * ((A + 1) + (A - 1) * cs - sq);
		a0 = (A + 1) - (A - 1) * cs + sq; a1 = 2 * ((A - 1) - (A + 1) * cs); a2 = (A + 1) - (A - 1) * cs - sq;
		break;
	}
	c[0] = b0 / a0; c[1] = b1 / a0; c[2] = b2 / a0; c[3] = a1 / a0; c[4] = a2 / a0;
}

static int a3_eq_same(const struct a3_eqset *a, const struct a3_eqset *b)
{
	int i;

	if (!a->on && !b->on)           /* off is off, whatever the bands say */
		return 1;
	if (a->on != b->on || a->pre_db != b->pre_db)
		return 0;
	for (i = 0; i < A3_EQ_N; i++)
		if (a->b[i].type != b->b[i].type || a->b[i].f != b->b[i].f || a->b[i].g != b->b[i].g || a->b[i].q != b->b[i].q)
			return 0;
	return 1;
}

/* design of band b with its gain scaled by k (k = 0: the 0 dB section of that type) */
static void a3_eq_dscale(const struct a3_eqband *b, double k, double *c)
{
	struct a3_eqband t = *b;

	t.g = b->g * k;
	a3_eq_design(&t, DSP_FS, c);
}

/* smoothstep: every partial ramp starts and ends with zero slope, so no ramp leaves a kink */
static inline double a3_eq_ss(double v) { return v <= 0.0 ? 0.0 : v >= 1.0 ? 1.0 : v * v * (3.0 - 2.0 * v); }

/* coefficients of band k at ramp position u (0 = from, 1 = to) */
static void a3_eq_coef(const struct a3_eq *e, int k, double u, double *c)
{
	const struct a3_eqband *a = &e->from[k], *b = &e->to[k];
	double p[5] = { 1, 0, 0, 0, 0 }, q[5], v = -1.0;
	int j;

	switch (e->kind[k]) {
	case A3_EQK_JOIN:
		if (u < A3_EQ_J1) { a3_eq_dscale(b, 0, q); v = a3_eq_ss(u / A3_EQ_J1); }
		else a3_eq_dscale(b, a3_eq_ss((u - A3_EQ_J1) / (1.0 - A3_EQ_J1)), c);
		break;
	case A3_EQK_LEAVE:
		a3_eq_dscale(a, 1.0 - a3_eq_ss(u / A3_EQ_L1), c);
		break;
	case A3_EQK_SWAP:
		if (u <= A3_EQ_S2) a3_eq_dscale(a, 1.0 - a3_eq_ss(u / A3_EQ_S1), c);    /* up to S2 itself: the old section runs until then */
		else if (u < A3_EQ_S3) { a3_eq_dscale(b, 0, q); v = a3_eq_ss((u - A3_EQ_S2) / (A3_EQ_S3 - A3_EQ_S2)); }
		else a3_eq_dscale(b, a3_eq_ss((u - A3_EQ_S3) / (1.0 - A3_EQ_S3)), c);
		break;
	case A3_EQK_MORPH: {                            /* same type: dB, log f, log Q */
		struct a3_eqband t = *a;

		u = a3_eq_ss(u);
		t.g = a->g + (b->g - a->g) * u;
		t.f = exp(log(a->f) + (log(b->f) - log(a->f)) * u);
		t.q = exp(log(a->q) + (log(b->q) - log(a->q)) * u);
		a3_eq_design(&t, DSP_FS, c);
		break;
	}
	default:
		memcpy(c, p, sizeof(p));
	}
	if (v >= 0)
		for (j = 0; j < 5; j++) c[j] = p[j] + (q[j] - p[j]) * v;
}

/*
 * Cross-fade to the input, band k at u. It must be complete (1) on the last sample the section
 * runs: for LEAVE the one before the end of the ramp (the section is dropped at the end), for SWAP
 * the one at u = S2 (the next sample starts the new section).
 */
static inline double a3_eq_byp(int kind, double u, int rlen)
{
	double v;

	if (kind == A3_EQK_LEAVE) v = (u - A3_EQ_L1) / ((rlen - 1.0) / rlen - A3_EQ_L1);
	else if (kind == A3_EQK_SWAP && u <= A3_EQ_S2) v = (u - A3_EQ_S1) / (A3_EQ_S2 - A3_EQ_S1);
	else return 0.0;
	return a3_eq_ss(v);
}

static inline double a3_eq_u(const struct a3_eq *e)
{
	return e->ramp >= e->rlen ? 0.0 : 1.0 - (double)e->ramp / e->rlen;
}

/* the list of sections to run: those not at pass-through now or during the ramp */
static void a3_eq_list(struct a3_eq *e)
{
	int i, was[A3_EQ_N] = { 0 };

	for (i = 0; i < e->nact; i++)
		was[e->act[i]] = 1;
	e->nact = 0;
	for (i = 0; i < A3_EQ_N; i++)
		if (!a3_eq_isoff(&e->to[i]) || (e->ramp && !a3_eq_isoff(&e->from[i]))) {
			if (!was[i])
				memset(e->s[i], 0, sizeof(e->s[i]));   /* joins at pass-through: the warm-up fills it */
			e->act[e->nact++] = i;
		}
}

/* start of a segment: each active band's coefficients where the segment ends, and the step there */
static void a3_eq_segment(struct a3_eq *e)
{
	double u0 = 1.0 - (double)e->ramp / e->rlen, u = 1.0 - (double)(e->ramp - A3_EQ_SEG) / e->rlen, t[5];
	int i, j, k;

	for (i = 0; i < e->nact; i++) {
		k = e->act[i];
		if (e->kind[k] == A3_EQK_SWAP && u0 == A3_EQ_S2) {
			/* the old section's output is its input now: start the new one from pass-through, history = input */
			e->c[k][0] = 1.0; e->c[k][1] = e->c[k][2] = e->c[k][3] = e->c[k][4] = 0.0;
			for (j = 0; j < 4; j++) { e->s[k][j][2] = e->s[k][j][0]; e->s[k][j][3] = e->s[k][j][1]; }
		}
		a3_eq_coef(e, k, u, t);
		for (j = 0; j < 5; j++)
			e->dc[k][j] = (t[j] - e->c[k][j]) / A3_EQ_SEG;
	}
}

/* a ramp from where every band is now (settled: from = to) to s */
static void a3_eq_start(struct a3_eq *e, const struct a3_eqset *s)
{
	int i;

	e->set = *s;
	for (i = 0; i < A3_EQ_N; i++) {
		e->from[i] = e->to[i];
		if (s->on && !a3_eq_isoff(&s->b[i]))
			e->to[i] = s->b[i];
		else { e->to[i].type = A3_EQ_OFF; e->to[i].f = e->to[i].g = 0; e->to[i].q = 1; }
		e->kind[i] = a3_eq_isoff(&e->from[i]) ? (a3_eq_isoff(&e->to[i]) ? A3_EQK_NONE : A3_EQK_JOIN) :
			a3_eq_isoff(&e->to[i]) ? A3_EQK_LEAVE : e->from[i].type != e->to[i].type ? A3_EQK_SWAP : A3_EQK_MORPH;
		e->byp[i] = 0.0;
	}
	e->g0 = e->g;
	e->gt = s->on ? pow(10.0, s->pre_db / 20.0) : 1.0;
	/* a change of type is two ramps in one (down as the old, up as the new): give it twice the time */
	e->rlen = A3_EQ_RAMP;
	for (i = 0; i < A3_EQ_N; i++)
		if (e->kind[i] == A3_EQK_SWAP) e->rlen = 2 * A3_EQ_RAMP;
	e->ramp = e->rlen + A3_EQ_WARM;
	memset(e->dc, 0, sizeof(e->dc));
	a3_eq_list(e);
	e->run = 1;
}

/*
 * New settings (from a settings reload). A compare when nothing changed;
 * otherwise it sets up the ramp (no filter design here). Returns 1 if the
 * settings differ from the last ones given.
 */
static int a3_eq_set(struct a3_eq *e, const struct a3_eqset *s)
{
	int i;

	if (!e->init) {                 /* a zeroed struct: every band off, gain 1 */
		for (i = 0; i < A3_EQ_N; i++) { e->c[i][0] = 1.0; e->from[i].q = e->to[i].q = 1.0; }
		e->g = e->gt = 1.0;
		e->init = 1;
	}
	if (a3_eq_same(e->pend ? &e->pset : &e->set, s))
		return 0;
	if (e->ramp) {                  /* finish this one first */
		e->pset = *s;
		e->pend = 1;
		return 1;
	}
	a3_eq_start(e, s);
	return 1;
}

/* one ramp step; at the end the exact targets, and out of the path if the EQ is off */
static void a3_eq_step(struct a3_eq *e)
{
	int i, j, k;

	if (e->ramp <= e->rlen && e->ramp % A3_EQ_SEG == 0)
		a3_eq_segment(e);
	e->ramp--;
	for (i = 0; i < e->nact; i++) {
		k = e->act[i];
		for (j = 0; j < 5; j++)
			e->c[k][j] += e->dc[k][j];
	}
	e->g = e->g0 + (e->gt - e->g0) * a3_eq_ss(a3_eq_u(e));
	if (e->ramp > 0) {
		double u = a3_eq_u(e);

		for (i = 0; i < e->nact; i++) {
			k = e->act[i];
			e->byp[k] = a3_eq_byp(e->kind[k], u, e->rlen);
		}
		return;
	}
	for (i = 0; i < A3_EQ_N; i++) {
		a3_eq_design(&e->to[i], DSP_FS, e->c[i]);
		e->from[i] = e->to[i];
	}
	memset(e->dc, 0, sizeof(e->dc));
	memset(e->byp, 0, sizeof(e->byp));
	e->g = e->gt;
	a3_eq_list(e);
	e->run = e->set.on;
	if (e->pend) {
		e->pend = 0;
		if (!a3_eq_same(&e->set, &e->pset))
			a3_eq_start(e, &e->pset);
	}
}

/* x[0] mid, x[1] side, in place; the two channels go through each section together (they are
 * independent, so the two dependency chains overlap) */
static inline void a3_eq_run(struct a3_eq *e, double *x)
{
	double m, s;
	int i;

	int ramp = e->ramp;

	if (ramp)
		a3_eq_step(e);
	m = x[0] * e->g;
	s = x[1] * e->g;
	for (i = 0; i < e->nact; i++) {
		const double *c = e->c[e->act[i]];
		double *zm = e->s[e->act[i]][0], *zs = e->s[e->act[i]][1];
		double ym = c[0] * m + c[1] * zm[0] + c[2] * zm[1] - c[3] * zm[2] - c[4] * zm[3];
		double ys = c[0] * s + c[1] * zs[0] + c[2] * zs[1] - c[3] * zs[2] - c[4] * zs[3];

		zm[1] = zm[0]; zm[0] = m; zm[3] = zm[2]; zm[2] = ym;
		zs[1] = zs[0]; zs[0] = s; zs[3] = zs[2]; zs[2] = ys;
		if (ramp && e->byp[e->act[i]] != 0.0) {     /* fading a leaving section out */
			double b = e->byp[e->act[i]];

			ym += (m - ym) * b;
			ys += (s - ys) * b;
		}
		m = ym; s = ys;
	}
	x[0] = m;
	x[1] = s;
}

/* the same for four channels */
static inline void a3_eq_run4(struct a3_eq *e, double *x)
{
	double v[4];
	int i, ch, ramp = e->ramp;

	if (ramp)
		a3_eq_step(e);
	for (ch = 0; ch < 4; ch++)
		v[ch] = x[ch] * e->g;
	for (i = 0; i < e->nact; i++) {
		const double *c = e->c[e->act[i]];
		double b = ramp ? e->byp[e->act[i]] : 0.0;

		for (ch = 0; ch < 4; ch++) {
			double *z = e->s[e->act[i]][ch];
			double y = c[0] * v[ch] + c[1] * z[0] + c[2] * z[1] - c[3] * z[2] - c[4] * z[3];

			z[1] = z[0]; z[0] = v[ch]; z[3] = z[2]; z[2] = y;
			if (b != 0.0)
				y += (v[ch] - y) * b;
			v[ch] = y;
		}
	}
	for (ch = 0; ch < 4; ch++)
		x[ch] = v[ch];
}

/* ------------------------------------------------------------------ */
/* the profile                                                        */
/* ------------------------------------------------------------------ */

struct hpdsp3 {
	struct hpdsp2 a;                /* configuration, front end, woofer EQ, beamformer */
	double aref_db;                 /* our full scale = Apple's full scale + aref_db, at master volume 0 dB */
	double xlim_mm;                 /* upper bound for the excursion limit (Apple: 8 mm) */
	int power;                      /* rail power limiter on/off */
	double pbudget_w;               /* long-term power budget (Apple: 40 W for the B238) */
	double p_int, p_eff;            /* power loop: integrator and its control effort */
	struct a3_ms ms;
	struct a3_bk bk;
	struct a3_cf cf[8];             /* [0] woofer ("bootyFreak"), [1..7] tweeter slots */
	struct a3_pg pg;
	float tdl[A2_NDRV][1024];
	int tpos, adly;
	double pre, postw, postt;
	double pre_cur;                 /* pre, smoothed (starts at 0: a fade-in) */
	/* meters */
	double m_gr[4], m_hp, m_xmm, m_xout, m_p48, m_p12, m_gw, m_gt, m_slow;
	long m_wlim, m_tlim;
	double m_xlim;                  /* excursion limit in force, mm (set by a3_configure) */
	struct a3_eq eq;                /* user EQ, after the input gain; also used by hpfeed for apple2 */
	/* surround (a2_cfg.surround, wall / shelf): a second front end with the same coefficients for the
	 * direct beam's own input ([0]) and the second ambient input ([1]); see a3_run_sur() */
	struct dbq xloud[2][2], xsys[2][16], xbadj[2][3], xap120, xhp120[2], xthp[2][2], xaeq[2][4], xamb[8];
};

static void a3_defaults(struct hpdsp3 *d)
{
	a2_defaults(&d->a.cfg);
	d->aref_db = A3_AREF_DEFAULT;
	d->xlim_mm = 5.0;                /* Apple: 8. Held back until the amplifier gain is verified, see NOTES-pass3.md */
	d->power = 1;
	d->pbudget_w = 40.0;
}

/* the second front end: coefficients follow the first one, the state is its own */
static void a3_xcopy(struct dbq *dst, const struct dbq *src, int n)
{
	int i;

	for (i = 0; i < n; i++) { dst[i].b0 = src[i].b0; dst[i].b1 = src[i].b1; dst[i].b2 = src[i].b2; dst[i].a1 = src[i].a1; dst[i].a2 = src[i].a2; }
}
static void a3_xzero(struct dbq *q, int n)
{
	int i;

	for (i = 0; i < n; i++) q[i].z1 = q[i].z2 = 0.0;
}

static void a3_clear(struct hpdsp3 *d)
{
	int k;

	a2_clear(&d->a);
	a3_ms_clear(&d->ms);
	/* keep the designed tables (win, ic): designing them again would stall the audio loop */
	memset(d->bk.inv, 0, sizeof(d->bk.inv)); memset(d->bk.mm, 0, sizeof(d->bk.mm));
	memset(d->bk.ch, 0, sizeof(d->bk.ch)); memset(d->bk.idx, 0, sizeof(d->bk.idx));
	memset(d->bk.ih, 0, sizeof(d->bk.ih));
	d->bk.state = d->bk.minidx = 0; d->bk.pos = d->bk.ipos = d->bk.phase = 0;
	d->bk.m_idx = d->bk.m_x2 = d->bk.m_xo = 0;
	d->bk.m_x2p = d->bk.m_xop = 0;
	for (k = 0; k < 8; k++) a3_cf_clear(&d->cf[k]);
	a3_pg_clear(&d->pg);
	memset(d->tdl, 0, sizeof(d->tdl));
	d->tpos = 0;
	a3_xzero(d->xloud[0], sizeof(d->xloud) / sizeof(struct dbq)); a3_xzero(d->xsys[0], sizeof(d->xsys) / sizeof(struct dbq));
	a3_xzero(d->xbadj[0], sizeof(d->xbadj) / sizeof(struct dbq)); a3_xzero(&d->xap120, 1); a3_xzero(d->xhp120, 2);
	a3_xzero(d->xthp[0], 4); a3_xzero(d->xaeq[0], 8); a3_xzero(d->xamb, 8);
}

static void a3_configure(struct hpdsp3 *d)
{
	static const double xl[4] = { 8.0, 6.7, 5.7, 5.0 }, whsf[4] = { 30.0, 50.5, 70.0, 80.0 };   /* PuffinPowerParameterMapping */
	static const double ex[5] = { 0.0, 0.7, 0.8, 0.9, 1.0 }, ev[5] = { 0.0, -0.25, -0.5, -1.5, -9.0 };
	static const double px[4] = { 0.0, 0.3, 0.7, 1.0 }, pv[4] = { 54.0, 38.0, 24.0, 12.0 };
	const struct a2_cfg *c = &d->a.cfg;
	double e0 = c->effort > d->p_eff ? c->effort : d->p_eff;
	double e = e0 < 0 ? 0 : e0 > 1 ? 1 : e0, ingn = ev[4], wltc = pv[3], xlim, tw, ww, ceil_w, ceil_t, vol;
	int i, k;

	a2_configure(&d->a);
	a3_xcopy(d->xloud[0], d->a.loud[0], 4); a3_xcopy(d->xsys[0], d->a.sys[0], 32); a3_xcopy(d->xbadj[0], d->a.badj[0], 6);
	a3_xcopy(&d->xap120, &d->a.ap120, 1); a3_xcopy(d->xhp120, d->a.hp120, 2);
	a3_xcopy(d->xthp[0], d->a.thp[0], 4); a3_xcopy(d->xaeq[0], d->a.aeq[0], 8); a3_xcopy(d->xamb, d->a.amb, 8);
	for (i = 0; i < 4; i++)
		if (e <= ex[i + 1]) { ingn = ev[i] + (ev[i + 1] - ev[i]) * (e - ex[i]) / (ex[i + 1] - ex[i]); break; }
	for (i = 0; i < 3; i++)
		if (e <= px[i + 1]) { wltc = pv[i] + (pv[i + 1] - pv[i]) * (e - px[i]) / (px[i + 1] - px[i]); break; }
	xlim = a2_interp(e, xl);
	if (xlim > d->xlim_mm) xlim = d->xlim_mm;
	d->m_xlim = xlim;
	vol = c->volume_db > 0 ? 0 : c->volume_db;
	ww = pow(10.0, c->woofer_db / 20.0);
	tw = pow(10.0, c->tweeter_db / 20.0);
	d->pre = pow(10.0, (vol + d->aref_db) / 20.0);
	d->postw = pow(10.0, -vol / 20.0) * ww;
	d->postt = pow(10.0, -vol / 20.0) * tw * (c->tw_invert ? -1.0 : 1.0);
	/* second ceiling: after the post gain nothing may exceed -0.3 dBFS at the DAC */
	ceil_w = vol - c->woofer_db - 0.3;
	ceil_t = vol - c->tweeter_db - 0.3;

	a3_ms_configure(&d->ms);
	a3_bk_configure(&d->bk, xlim, a2_interp(e, whsf), apple_bk[9] * ww, c->guard);
	a3_cf_configure(&d->cf[0], apple_cf_woofer, apple_cf_woofer[0] < ceil_w ? apple_cf_woofer[0] : ceil_w, 0.0);
	for (k = 1; k < 8; k++)
		a3_cf_configure(&d->cf[k], apple_cf_tweeter, apple_cf_tweeter[0] < ceil_t ? apple_cf_tweeter[0] : ceil_t, ingn);
	a3_pg_configure(&d->pg, apple_pg[17] * ww, apple_pg[3] * tw, wltc, d->power && c->limit);
	d->adly = A3_ARRAY_DLY + c->tw_delay - c->wf_delay;
	if (d->adly < 0) d->adly = 0;
	if (d->adly > 1023) d->adly = 1023;
}

/*
 * Apple's long-term power loop (PuffinPowerController updatePowerLoop, period 1 s):
 *   e = measured power - target (W);  I = clamp(I + Ki e, 0, 1);  effort = clamp(Kp e + I, 0, 1)
 * with Kp 0.1291, Ki 0.0172 and a target of 40 W. Apple measures the supply (PSU minus logic
 * board, 10 s average); we have no calibrated power telemetry, so the limiter's own estimate of
 * the 48 V supply power stands in, averaged the same way. Call once a second. Returns 1 when the
 * control effort changed and the chain was reconfigured (cheap: no filter design involved).
 */
static int a3_power_loop(struct hpdsp3 *d)
{
	double e = d->pg.pavg - d->pbudget_w, eff;

	d->p_int += 0.0172 * e;
	if (d->p_int < 0) d->p_int = 0;
	if (d->p_int > 1) d->p_int = 1;
	eff = 0.1291 * e + d->p_int;
	if (eff < 0) eff = 0;
	if (eff > 1) eff = 1;
	eff = floor(eff * 50.0 + 0.5) / 50.0;
	if (eff == d->p_eff)
		return 0;
	d->p_eff = eff;
	a3_configure(d);
	return 1;
}

/*
 * One sample. m = (L+R)/2, s = (L-R)/2, both -1..1.
 * *woofer and tw[0..6] (indexed by TDM slot - 1) come back in DAC full-scale units.
 */
static inline void a3_run(struct hpdsp3 *d3, double m, double s, double *woofer, double *tw)
{
	struct hpdsp2 *d = &d3->a;
	const struct a2_cfg *c = &d->cfg;
	double x[2], lo, hi, t, drv[A2_NDRV], v[8];
	int i, k, ch, p;

	/* the volume moves without a step: about 10 ms to follow a new input gain */
	d3->pre_cur += (d3->pre - d3->pre_cur) * 0.002;
	x[0] = 2.0 * m * d3->pre_cur;
	x[1] = 2.0 * s * d3->pre_cur;
	if (d3->eq.run)                 /* user EQ: not in the path at all while it is off */
		a3_eq_run(&d3->eq, x);
	for (ch = 0; ch < 2; ch++) {
		t = x[ch];
		if (d->loud_on)
			t = dbq_run(&d->loud[ch][1], dbq_run(&d->loud[ch][0], t));
		for (i = 0; i < NSYS; i++)
			t = dbq_run(&d->sys[ch][i], t);
		if (c->bass_reduce)
			for (i = 0; i < 3; i++)
				t = dbq_run(&d->badj[ch][i], t);
		x[ch] = t * d->g_pre;
	}
	x[0] = dbq_run(&d->ap120, x[0]);
	x[1] = dbq_run(&d->hp120[1], dbq_run(&d->hp120[0], x[1]));
	a3_ms_run(&d3->ms, x, c->drc, d3->m_gr);

	/* ---- woofer: crossover + EQ -> BassKoenig -> limiter ---- */
	lo = x[0];
	for (i = 0; i < d->nwf; i++)
		lo = dbq_run(&d->wf[i], lo);
	lo = a3_bk_run(&d3->bk, lo);
	v[0] = a3_cf_run(&d3->cf[0], lo, c->limit);

	/* ---- array: as in a2_run ---- */
	hi = dbq_run(&d->thp[0][1], dbq_run(&d->thp[0][0], x[0]));
	for (i = 0; i < NAEQ; i++)
		hi = dbq_run(&d->aeq[0][i], hi);
	t = x[1];
	for (i = 0; i < d->namb; i++)
		t = dbq_run(&d->amb[i], t);
	t = dbq_run(&d->thp[1][1], dbq_run(&d->thp[1][0], t * d->g_amb));
	for (i = 0; i < NAEQ; i++)
		t = dbq_run(&d->aeq[1][i], t);
	p = d->hpos = (d->hpos + A2_HIST - 1) & (A2_HIST - 1);
	d->hist[0][p] = d->hist[0][p + A2_HIST] = (float)hi;
	d->hist[1][p] = d->hist[1][p + A2_HIST] = (float)t;
	for (k = 0; k < A2_NDRV; k++)
		drv[k] = 0.0;
	for (i = 0; i < d->nf; i++) {
		const struct a2_filt *f = &d->f[i];
		float fv = a2_fir(f->c, &d->hist[f->in][(p + f->delay) & (A2_HIST - 1)], f->n);

		for (k = 0; k < A2_NDRV; k++)
			drv[k] += f->w[k] * fv;
	}
	d3->tpos = (d3->tpos + 1) & 1023;
	for (k = 0; k < A2_NDRV; k++) {
		double y = drv[c->order[k]];

		if (c->solo && c->solo != k + 1)
			y = 0.0;
		y = a3_cf_run(&d3->cf[k + 1], y, c->limit);
		d3->tdl[k][d3->tpos] = (float)y;
		v[k + 1] = d3->tdl[k][(d3->tpos - d3->adly) & 1023];
	}
	a3_pg_run(&d3->pg, v);
	*woofer = v[0] * d3->postw;
	for (k = 0; k < A2_NDRV; k++)
		tw[k] = v[k + 1] * d3->postt;
}

/*
 * The same with a multichannel source and the speaker near a wall or on a shelf, the way Apple's
 * beamMix feeds the array there: T = everything (woofer), dir = front + centre (direct beam),
 * a1 / a2 = left / right surround and height (the two ambient beams). With a stereo source
 * (dir == T, a2 == -a1) this gives what a3_run() gives. All four in a3_run()'s "2 m" scale.
 */
static inline void a3_run_sur(struct hpdsp3 *d3, double T, double dir, double a1, double a2, double *woofer, double *tw)
{
	struct hpdsp2 *d = &d3->a;
	const struct a2_cfg *c = &d->cfg;
	double x[4], lo, hi, t, u, drv[A2_NDRV], v[8];
	int i, k, ch, p;

	d3->pre_cur += (d3->pre - d3->pre_cur) * 0.002;
	x[0] = T * d3->pre_cur; x[1] = a1 * d3->pre_cur; x[2] = dir * d3->pre_cur; x[3] = a2 * d3->pre_cur;
	if (d3->eq.run)
		a3_eq_run4(&d3->eq, x);
	for (ch = 0; ch < 2; ch++) {
		t = x[ch]; u = x[2 + ch];
		if (d->loud_on) {
			t = dbq_run(&d->loud[ch][1], dbq_run(&d->loud[ch][0], t));
			u = dbq_run(&d3->xloud[ch][1], dbq_run(&d3->xloud[ch][0], u));
		}
		for (i = 0; i < NSYS; i++) {
			t = dbq_run(&d->sys[ch][i], t);
			u = dbq_run(&d3->xsys[ch][i], u);
		}
		if (c->bass_reduce)
			for (i = 0; i < 3; i++) {
				t = dbq_run(&d->badj[ch][i], t);
				u = dbq_run(&d3->xbadj[ch][i], u);
			}
		x[ch] = t * d->g_pre; x[2 + ch] = u * d->g_pre;
	}
	x[0] = dbq_run(&d->ap120, x[0]);
	x[1] = dbq_run(&d->hp120[1], dbq_run(&d->hp120[0], x[1]));
	x[2] = dbq_run(&d3->xap120, x[2]);
	x[3] = dbq_run(&d3->xhp120[1], dbq_run(&d3->xhp120[0], x[3]));
	a3_ms_run_n(&d3->ms, x, 4, c->drc, d3->m_gr);

	/* ---- woofer: everything ---- */
	lo = x[0];
	for (i = 0; i < d->nwf; i++)
		lo = dbq_run(&d->wf[i], lo);
	lo = a3_bk_run(&d3->bk, lo);
	v[0] = a3_cf_run(&d3->cf[0], lo, c->limit);

	/* ---- array: direct beam from x[2], ambient beams from x[1] and x[3] ---- */
	hi = dbq_run(&d3->xthp[0][1], dbq_run(&d3->xthp[0][0], x[2]));
	for (i = 0; i < NAEQ; i++)
		hi = dbq_run(&d3->xaeq[0][i], hi);
	t = x[1]; u = x[3];
	for (i = 0; i < d->namb; i++) {
		t = dbq_run(&d->amb[i], t);
		u = dbq_run(&d3->xamb[i], u);
	}
	t = dbq_run(&d->thp[1][1], dbq_run(&d->thp[1][0], t * d->g_amb));
	u = dbq_run(&d3->xthp[1][1], dbq_run(&d3->xthp[1][0], u * d->g_amb));
	for (i = 0; i < NAEQ; i++) {
		t = dbq_run(&d->aeq[1][i], t);
		u = dbq_run(&d3->xaeq[1][i], u);
	}
	p = d->hpos = (d->hpos + A2_HIST - 1) & (A2_HIST - 1);
	d->hist[0][p] = d->hist[0][p + A2_HIST] = (float)hi;
	d->hist[1][p] = d->hist[1][p + A2_HIST] = (float)t;
	d->hist[2][p] = d->hist[2][p + A2_HIST] = (float)u;
	for (k = 0; k < A2_NDRV; k++)
		drv[k] = 0.0;
	for (i = 0; i < d->nf; i++) {
		const struct a2_filt *f = &d->f[i];
		float fv = a2_fir(f->c, &d->hist[f->in][(p + f->delay) & (A2_HIST - 1)], f->n);

		for (k = 0; k < A2_NDRV; k++)
			drv[k] += f->w[k] * fv;
	}
	d3->tpos = (d3->tpos + 1) & 1023;
	for (k = 0; k < A2_NDRV; k++) {
		double y = drv[c->order[k]];

		if (c->solo && c->solo != k + 1)
			y = 0.0;
		y = a3_cf_run(&d3->cf[k + 1], y, c->limit);
		d3->tdl[k][d3->tpos] = (float)y;
		v[k + 1] = d3->tdl[k][(d3->tpos - d3->adly) & 1023];
	}
	a3_pg_run(&d3->pg, v);
	*woofer = v[0] * d3->postw;
	for (k = 0; k < A2_NDRV; k++)
		tw[k] = v[k + 1] * d3->postt;
}

/* gather the meters for a status line (cheap; call it now and then) */
static void a3_meters(struct hpdsp3 *d)
{
	double r = exp(log(apple_bk[5] / d->bk.start) / (A3_BK_N - 1));
	int k;

	d->m_hp = d->bk.start * pow(r, d->bk.m_idx);            /* where the sliding high-pass sits */
	d->m_xmm = sqrt(d->bk.m_x2) * apple_bk[9] * pow(10.0, d->a.cfg.woofer_db / 20.0);   /* excursion asked for, mm */
	d->m_xout = d->bk.m_xo * apple_bk[9] * pow(10.0, d->a.cfg.woofer_db / 20.0);           /* excursion after BassKoenig, mm peak */
	d->m_p48 = d->pg.m_p48; d->m_p12 = d->pg.m_p12;
	d->m_gw = d->pg.m_gw; d->m_gt = d->pg.m_gt;
	d->m_wlim = d->cf[0].hits; d->cf[0].hits = 0;
	d->m_tlim = 0; d->m_slow = d->cf[0].m_slow;
	for (k = 1; k < 8; k++) {
		d->m_tlim += d->cf[k].hits; d->cf[k].hits = 0;
		if (d->cf[k].m_slow < d->m_slow) d->m_slow = d->cf[k].m_slow;
	}
}

/*
 * The same figures for the 15 Hz meter file, without disturbing a3_meters()
 * and the 5 s status line: nothing here resets the limiter hit counters.
 * The peaks (x asked / out, P48, P12) are maxima since the previous call.
 */
struct a3_peekv { double gr[4], hp, xask, xout, xlim, p48, p12, pavg, budget, effort, gw, gt, slow; };

static void a3_peek(struct hpdsp3 *d, struct a3_peekv *v)
{
	double r = exp(log(apple_bk[5] / d->bk.start) / (A3_BK_N - 1)), mmv = apple_bk[9] * pow(10.0, d->a.cfg.woofer_db / 20.0);
	int k;

	for (k = 0; k < 4; k++) v->gr[k] = d->m_gr[k];
	v->hp = d->bk.start * pow(r, d->bk.m_idx);
	v->xask = sqrt(d->bk.m_x2p) * mmv; d->bk.m_x2p = 0;
	v->xout = d->bk.m_xop * mmv; d->bk.m_xop = 0;
	v->xlim = d->m_xlim;
	v->p48 = d->pg.m_p48p; d->pg.m_p48p = 0;
	v->p12 = d->pg.m_p12p; d->pg.m_p12p = 0;
	v->pavg = d->pg.pavg;
	v->budget = d->pbudget_w;
	v->effort = d->a.cfg.effort > d->p_eff ? d->a.cfg.effort : d->p_eff;
	v->gw = d->pg.m_gw; v->gt = d->pg.m_gt;
	v->slow = d->cf[0].m_slow;
	for (k = 1; k < 8; k++)
		if (d->cf[k].m_slow < v->slow) v->slow = d->cf[k].m_slow;
}

#endif
