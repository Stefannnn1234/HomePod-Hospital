#!/usr/bin/env python3
"""
find_clocks.py - Discover audio-related clock gates and power domains on A8.

The A8 SoC uses a Power Manager (PMGR) with clock gates that must be enabled
before peripherals can be accessed. If MCA3 or UART8 reads as 0xFFFFFFFF,
their clock gate is probably off.

This script:
  1. Scans PMGR register space for audio-related clock gates
  2. Checks the state of known peripherals
  3. Optionally enables clock gates (CAREFUL - wrong gates can hang the SoC)

Apple A8 (T7000) PMGR layout (approximate, from device tree):
  PMGR base: 0x20e080000
  Clock gates: 0x20e080200 - 0x20e080600 (stride 8 per gate)
  PS (power state) registers: 0x20e080000+

Each clock gate register (32-bit):
  Bits [3:0]: Target power state (0=off, 4=idle, 0xF=on)
  Bits [7:4]: Actual power state (read-only)
  Bit 31: Pending (transition in progress)
"""

import os
import sys
import time
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mmio

# ============================================================
# A8 (T7000) PMGR addresses (approximate)
# ============================================================

PMGR_BASE = 0x20e080000

# Clock gate area - each gate is 8 bytes (only first 4 used)
# Gate index * 8 + base gives the register address
CG_BASE = 0x20e080200
CG_STRIDE = 8

# Known peripheral addresses to check
PERIPHERALS = {
    'UART8':      0x20a0e0000,
    'MCA0':       0x20a0a0000,
    'MCA1':       0x20a0a4000,
    'MCA2':       0x20a0a8000,
    'MCA3':       0x20a0ac000,
    'I2S_SWITCH': 0x20a003000,
    'NCO':        0x20e011000,
    'GPIO':       0x20e300000,
}

# Power state values
PS_OFF   = 0x0
PS_IDLE  = 0x4
PS_ON    = 0xF

PS_NAMES = {
    0x0: "OFF",
    0x1: "on(1)",
    0x2: "on(2)",
    0x3: "on(3)",
    0x4: "IDLE",
    0x5: "on(5)",
    0x6: "on(6)",
    0x7: "on(7)",
    0x8: "on(8)",
    0x9: "on(9)",
    0xA: "on(A)",
    0xB: "on(B)",
    0xC: "on(C)",
    0xD: "on(D)",
    0xE: "on(E)",
    0xF: "ON",
}


def check_peripheral(name, addr):
    """Check if a peripheral is accessible (clocked)."""
    try:
        val = mmio.read32(addr)
        if val == 0xFFFFFFFF:
            return 'NOT_CLOCKED'
        elif val == 0xDEADBEEF:
            return 'DEAD'
        elif val == 0:
            # Read a few more to be sure
            v1 = mmio.read32(addr + 4)
            v2 = mmio.read32(addr + 8)
            if v1 == 0 and v2 == 0:
                return 'ZEROS'
            return 'PARTIAL'
        else:
            return 'ACTIVE'
    except Exception as e:
        return f'ERROR({e})'


def scan_peripherals():
    """Check accessibility of all known peripherals."""
    print("\n" + "=" * 60)
    print("  PERIPHERAL ACCESSIBILITY CHECK")
    print("=" * 60)

    for name, addr in sorted(PERIPHERALS.items(), key=lambda x: x[1]):
        status = check_peripheral(name, addr)
        val = mmio.read32(addr)
        indicator = "OK" if status == 'ACTIVE' else "**"
        print(f"  {indicator} {name:15s} @ 0x{addr:09x} : "
              f"0x{val:08x} [{status}]")


def scan_clock_gates(base=CG_BASE, count=128):
    """Scan clock gate registers."""
    print(f"\n{'=' * 60}")
    print(f"  CLOCK GATE SCAN (0x{base:09x}, {count} gates)")
    print(f"{'=' * 60}")

    active_gates = []
    for i in range(count):
        addr = base + i * CG_STRIDE
        try:
            val = mmio.read32(addr)
            target = val & 0xF
            actual = (val >> 4) & 0xF
            pending = bool(val & (1 << 31))

            if val == 0xFFFFFFFF:
                continue  # Unmapped

            target_name = PS_NAMES.get(target, f"?{target}")
            actual_name = PS_NAMES.get(actual, f"?{actual}")

            if actual != 0 or target != 0:  # Only show non-off gates
                active_gates.append(i)
                pend_str = " PENDING" if pending else ""
                print(f"  Gate {i:3d} [0x{addr:09x}] = 0x{val:08x}  "
                      f"target={target_name:5s} actual={actual_name:5s}{pend_str}")

        except Exception:
            break

    print(f"\n  {len(active_gates)} active gates found out of {count}")
    return active_gates


def scan_pmgr_region(base=PMGR_BASE, size=0x1000):
    """Broad scan of PMGR register space for non-zero values."""
    print(f"\n{'=' * 60}")
    print(f"  PMGR REGION SCAN (0x{base:09x}, {size} bytes)")
    print(f"{'=' * 60}")

    nonzero = 0
    for off in range(0, size, 4):
        try:
            val = mmio.read32(base + off)
            if val != 0 and val != 0xFFFFFFFF:
                nonzero += 1
                print(f"  [0x{off:04x}] = 0x{val:08x}")
        except Exception:
            break

    print(f"\n  {nonzero} non-zero/non-FF registers")


def try_enable_gate(gate_idx, base=CG_BASE):
    """Try to enable a clock gate. USE WITH EXTREME CAUTION.

    Writing the wrong value to the wrong gate can hang or crash the SoC.
    """
    addr = base + gate_idx * CG_STRIDE
    old_val = mmio.read32(addr)
    target = old_val & 0xF
    actual = (old_val >> 4) & 0xF

    print(f"\n  Gate {gate_idx} @ 0x{addr:09x}")
    print(f"  Current: 0x{old_val:08x} (target={target}, actual={actual})")

    if actual == 0xF:
        print("  Already ON - nothing to do")
        return True

    # Set target to ON (0xF)
    new_val = (old_val & ~0xF) | PS_ON
    print(f"  Writing: 0x{new_val:08x} (setting target=ON)")
    mmio.write32(addr, new_val)

    # Wait for transition
    for _ in range(100):
        val = mmio.read32(addr)
        actual = (val >> 4) & 0xF
        pending = bool(val & (1 << 31))
        if actual == 0xF and not pending:
            print(f"  Gate enabled! New value: 0x{val:08x}")
            return True
        time.sleep(0.001)

    val = mmio.read32(addr)
    print(f"  WARNING: Gate may not have enabled. Value: 0x{val:08x}")
    return False


def find_audio_gates():
    """Try to find clock gates related to audio peripherals.

    Strategy: scan all gates, toggle each OFF one from ON and see
    which peripheral disappears. Too dangerous for automated use,
    but we can try a more conservative approach:

    1. Find all gates that are currently OFF
    2. For each, try enabling it and check if a previously-inaccessible
       peripheral becomes accessible
    """
    print("\n" + "=" * 60)
    print("  AUDIO CLOCK GATE DISCOVERY")
    print("  This will try enabling OFF gates to find audio clocks.")
    print("  This is a probing operation - may not be safe on all configs.")
    print("=" * 60)

    # First, check which peripherals are currently inaccessible
    print("\n  Current peripheral state:")
    needs_clock = {}
    for name, addr in PERIPHERALS.items():
        status = check_peripheral(name, addr)
        print(f"    {name}: {status}")
        if status == 'NOT_CLOCKED':
            needs_clock[name] = addr

    if not needs_clock:
        print("\n  All peripherals appear clocked. Nothing to do.")
        return

    print(f"\n  Peripherals needing clocks: {list(needs_clock.keys())}")

    # Find OFF gates
    off_gates = []
    for i in range(128):
        addr = CG_BASE + i * CG_STRIDE
        try:
            val = mmio.read32(addr)
            if val == 0xFFFFFFFF:
                continue
            target = val & 0xF
            actual = (val >> 4) & 0xF
            if actual == 0 and target == 0:
                off_gates.append((i, val))
        except Exception:
            break

    print(f"\n  Found {len(off_gates)} OFF gates to try")
    print("  (Will try each one and check if any peripheral wakes up)")

    found = {}
    for gate_idx, old_val in off_gates:
        gate_addr = CG_BASE + gate_idx * CG_STRIDE

        # Enable this gate
        mmio.write32(gate_addr, (old_val & ~0xF) | PS_ON)
        time.sleep(0.005)

        # Check if any peripheral woke up
        for name, paddr in needs_clock.items():
            if name in found:
                continue
            status = check_peripheral(name, paddr)
            if status != 'NOT_CLOCKED':
                print(f"  *** Gate {gate_idx} enables {name}! "
                      f"(gate @ 0x{gate_addr:09x}) ***")
                found[name] = gate_idx
                break  # Don't disable this gate

        if not any(name not in found for name in needs_clock):
            break  # All peripherals found

        # If this gate didn't help anything, turn it back off
        if gate_idx not in found.values():
            mmio.write32(gate_addr, old_val)
            time.sleep(0.001)

    if found:
        print(f"\n  Discovered gate mappings:")
        for name, gate in found.items():
            print(f"    {name}: gate {gate} (0x{CG_BASE + gate * CG_STRIDE:09x})")
    else:
        print("\n  No gates found that enable our peripherals.")
        print("  The clock gates may be at different offsets, or the")
        print("  peripherals need a different power domain enabled first.")


def main():
    parser = argparse.ArgumentParser(description='Audio clock gate finder')
    parser.add_argument('action', nargs='?', default='check',
                        choices=['check', 'gates', 'pmgr', 'discover',
                                 'enable'],
                        help='Action to perform')
    parser.add_argument('--gate', '-g', type=int,
                        help='Gate index to enable (for "enable" action)')
    parser.add_argument('--cg-base', type=lambda x: int(x, 0),
                        default=CG_BASE,
                        help='Clock gate register base address')
    parser.add_argument('--count', '-n', type=int, default=128,
                        help='Number of gates to scan')
    args = parser.parse_args()

    try:
        if args.action == 'check':
            scan_peripherals()

        elif args.action == 'gates':
            scan_clock_gates(args.cg_base, args.count)

        elif args.action == 'pmgr':
            scan_pmgr_region()

        elif args.action == 'discover':
            find_audio_gates()

        elif args.action == 'enable':
            if args.gate is None:
                print("ERROR: --gate required for enable action")
                sys.exit(1)
            try_enable_gate(args.gate, args.cg_base)
            print("\nPeripheral state after gate change:")
            scan_peripherals()

    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()
    finally:
        mmio.cleanup()


if __name__ == '__main__':
    main()
