#!/usr/bin/env python3
"""
audio_powerup.py - Power up the HomePod audio chain via Nitrogen MCU.

Sequence (from Apple factory scripts and device tree):
  1. Verify MCU communication
  2. AMP standby -> active
  3. WFR (woofer) power on
  4. Verify telemetry / check for faults
  5. Optionally init SSM3515 tweeter registers
  6. Optionally init CS4350 woofer DAC

SAFETY:
  - This only powers up the analog chain. No audio data flows until
    MCA is configured and clocked.
  - The [AMP,X] fast-shutdown is always available as emergency stop.
  - Without the DSP crossover, NEVER send unfiltered audio to the woofer.
"""

import os
import sys
import time
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nitrogen import get_mcu, probe_mcu

# ============================================================
# SSM3515B register definitions (from MCU firmware disassembly)
# ============================================================

# Register addresses
SSM_REG_POWER    = 0x00  # Power control / mute
SSM_REG_CONFIG1  = 0x01  # Configuration 1 (format, etc.)
SSM_REG_CONFIG2  = 0x02  # Configuration 2 (volume/DAC mode)
SSM_REG_SLOT     = 0x05  # TDM slot assignment
SSM_REG_FAULT    = 0x06  # Fault status (read)
SSM_REG_STATUS   = 0x07  # Status (read)

# SSM3515 standby config (from MCU firmware)
SSM_STANDBY_POWER   = 0x01  # Bit 0 = software powerdown
SSM_STANDBY_CONFIG1 = 0x11  # TDM mode, 32-bit
SSM_STANDBY_CONFIG2 = 0x72  # DAC config with mute

# SSM3515 active/unmute config
SSM_ACTIVE_POWER   = 0x00  # Not in powerdown
SSM_ACTIVE_CONFIG2 = 0x32  # DAC config without hard mute

# ============================================================
# CS4350 (woofer DAC) register definitions
# ============================================================

CS4350_REG_MODE   = 0x02  # Mode control
CS4350_REG_MIXCTL = 0x04  # Mix control (mute bits)
CS4350_REG_VOLA   = 0x08  # Volume A

# CS4350 standby config
CS4350_STANDBY_MIXCTL = 0x98  # Muted
CS4350_STANDBY_MODE   = 0x40  # Standby mode

# CS4350 active config
CS4350_ACTIVE_MIXCTL = 0x00  # Unmuted
CS4350_ACTIVE_VOLA   = 0x00  # 0dB (we'll set lower for safety)


class AudioChain:
    """Manages the HomePod audio chain via Nitrogen MCU."""

    def __init__(self, mcu):
        self.mcu = mcu
        self.amp_state = 'unknown'
        self.wfr_state = 'unknown'
        self.tweeter_states = [None] * 8  # index 0 unused, 1-7 for tweeters

    def emergency_stop(self):
        """EMERGENCY: Immediately shut down all amplifiers."""
        print("\n!!! EMERGENCY STOP !!!")
        self.mcu.command("[AMP,X]")
        self.mcu.command("[WFR,N]")
        self.amp_state = 'off'
        self.wfr_state = 'off'
        print("All amplifiers shut down.")

    def verify_mcu(self):
        """Check MCU is responding."""
        print("\n=== Verifying MCU Communication ===")
        resp = self.mcu.command("[SV]")
        if not resp or '<' not in resp:
            print("ERROR: MCU not responding!")
            return False
        print("MCU responding OK")
        return True

    def check_faults(self):
        """Read fault status from all tweeters."""
        print("\n=== Checking Faults ===")
        faults = []
        for i in range(1, 8):
            resp = self.mcu.command(f"[TRI,{i},{SSM_REG_FAULT}]")
            if resp and '<' in resp:
                # Parse fault value from response
                try:
                    parts = resp.strip('<>').split(',')
                    if len(parts) >= 2:
                        val = int(parts[-1], 0)
                        if val != 0:
                            faults.append((i, val))
                            print(f"  FAULT on tweeter {i}: 0x{val:02x}")
                except (ValueError, IndexError):
                    pass

        if not faults:
            print("  No faults detected")
        return faults

    def get_telemetry(self, level=1):
        """Get telemetry data from MCU."""
        print(f"\n=== Telemetry (Level {level}) ===")
        self.mcu.command(f"[TELEM,{level}]", timeout_s=3.0)

    def get_temperature(self):
        """Get temperature reading."""
        print("\n=== Temperature ===")
        return self.mcu.command("[TEMP]")

    def amp_standby(self):
        """Put amplifier system in standby."""
        print("\n=== AMP -> Standby ===")
        resp = self.mcu.command("[AMP,S]")
        self.amp_state = 'standby'
        time.sleep(0.1)
        return resp

    def amp_active(self):
        """Activate amplifier system."""
        print("\n=== AMP -> Active ===")
        resp = self.mcu.command("[AMP,A]")
        self.amp_state = 'active'
        time.sleep(0.2)
        return resp

    def woofer_on(self):
        """Power on the woofer subsystem."""
        print("\n=== Woofer -> Power On ===")
        resp = self.mcu.command("[WFR,P]")
        self.wfr_state = 'on'
        time.sleep(0.5)  # Woofer needs time to stabilize (48V rail)
        return resp

    def woofer_standby(self):
        """Put woofer in standby."""
        print("\n=== Woofer -> Standby ===")
        resp = self.mcu.command("[WFR,M]")
        self.wfr_state = 'standby'
        return resp

    def woofer_off(self):
        """Shut down woofer."""
        print("\n=== Woofer -> Off ===")
        resp = self.mcu.command("[WFR,N]")
        self.wfr_state = 'off'
        return resp

    def init_tweeter(self, index, slot):
        """Initialize a single SSM3515 tweeter amp.

        index: 1-7 (tweeter number)
        slot: TDM slot number (1-7, matching index)
        """
        print(f"\n  --- Init Tweeter {index} (TDM slot {slot}) ---")

        # Standby sequence
        self.mcu.command(f"[TWI,{index},{SSM_REG_POWER},{SSM_STANDBY_POWER}]")
        self.mcu.command(f"[TWI,{index},{SSM_REG_CONFIG1},{SSM_STANDBY_CONFIG1}]")
        self.mcu.command(f"[TWI,{index},{SSM_REG_CONFIG2},{SSM_STANDBY_CONFIG2}]")
        self.mcu.command(f"[TWI,{index},{SSM_REG_SLOT},{slot}]")
        time.sleep(0.01)

        # Verify slot assignment
        resp = self.mcu.command(f"[TRI,{index},{SSM_REG_SLOT}]")
        print(f"    Slot readback: {resp}")

        self.tweeter_states[index] = 'standby'

    def unmute_tweeter(self, index):
        """Unmute a single tweeter (must be initialized first)."""
        print(f"\n  --- Unmute Tweeter {index} ---")
        self.mcu.command(f"[TWI,{index},{SSM_REG_POWER},{SSM_ACTIVE_POWER}]")
        self.mcu.command(f"[TWI,{index},{SSM_REG_CONFIG2},{SSM_ACTIVE_CONFIG2}]")
        self.tweeter_states[index] = 'active'

    def mute_tweeter(self, index):
        """Mute a single tweeter."""
        print(f"\n  --- Mute Tweeter {index} ---")
        self.mcu.command(f"[TWI,{index},{SSM_REG_POWER},{SSM_STANDBY_POWER}]")
        self.tweeter_states[index] = 'standby'

    def init_all_tweeters(self):
        """Initialize all 7 tweeters with their TDM slots."""
        print("\n=== Initializing All Tweeters ===")
        for i in range(1, 8):
            self.init_tweeter(i, i)
        print("\nAll tweeters initialized in standby")

    def unmute_all_tweeters(self):
        """Unmute all tweeters."""
        print("\n=== Unmuting All Tweeters ===")
        # Use broadcast write for efficiency
        self.mcu.command(f"[TWA,{SSM_REG_POWER},{SSM_ACTIVE_POWER}]")
        self.mcu.command(f"[TWA,{SSM_REG_CONFIG2},{SSM_ACTIVE_CONFIG2}]")
        for i in range(1, 8):
            self.tweeter_states[i] = 'active'

    def mute_all_tweeters(self):
        """Mute all tweeters."""
        print("\n=== Muting All Tweeters ===")
        self.mcu.command(f"[TWA,{SSM_REG_POWER},{SSM_STANDBY_POWER}]")
        for i in range(1, 8):
            self.tweeter_states[i] = 'standby'

    def full_powerup(self, include_woofer=False, unmute_tweeters=False):
        """Full power-up sequence.

        include_woofer: Also power up the woofer (DANGEROUS without crossover!)
        unmute_tweeters: Unmute tweeters after init (needs MCA clocks first)
        """
        print("\n" + "=" * 60)
        print("  AUDIO CHAIN POWER-UP SEQUENCE")
        print("=" * 60)

        # Step 1: Verify MCU
        if not self.verify_mcu():
            print("\nABORT: MCU not responding")
            return False

        # Step 2: Check initial state
        self.get_temperature()
        self.get_telemetry(1)

        # Step 3: AMP standby
        self.amp_standby()
        time.sleep(0.2)

        # Step 4: AMP active
        self.amp_active()
        time.sleep(0.3)

        # Step 5: Check for faults
        faults = self.check_faults()
        if faults:
            print("\nWARNING: Faults detected after amp activation!")
            print("Continuing anyway (faults may clear after full init)")

        # Step 6: Init tweeters
        self.init_all_tweeters()

        # Step 7: Woofer (optional)
        if include_woofer:
            print("\n*** WARNING: Powering woofer without DSP crossover! ***")
            print("*** NEVER send unfiltered audio to the woofer! ***")
            self.woofer_on()
        else:
            print("\n[Woofer left off - needs crossover protection]")

        # Step 8: Unmute (optional)
        if unmute_tweeters:
            print("\nUnmuting tweeters (audio will pass when MCA sends data)")
            self.unmute_all_tweeters()

        # Step 9: Final status
        self.get_temperature()
        self.get_telemetry(1)
        self.check_faults()

        print("\n" + "=" * 60)
        print("  POWER-UP COMPLETE")
        print(f"  Amp state: {self.amp_state}")
        print(f"  Woofer state: {self.wfr_state}")
        tweeter_summary = [f"T{i}:{self.tweeter_states[i]}"
                           for i in range(1, 8)]
        print(f"  Tweeters: {', '.join(tweeter_summary)}")
        print("=" * 60)
        return True

    def full_shutdown(self):
        """Orderly shutdown of the entire audio chain."""
        print("\n" + "=" * 60)
        print("  AUDIO CHAIN SHUTDOWN")
        print("=" * 60)

        self.mute_all_tweeters()
        time.sleep(0.1)
        self.woofer_off()
        time.sleep(0.1)
        self.mcu.command("[AMP,S]")  # Standby first
        time.sleep(0.1)
        self.mcu.command("[AMP,O]")  # Then off
        self.amp_state = 'off'

        # Disable telemetry
        self.mcu.command("[TELEM,0]")

        print("\nShutdown complete")


def main():
    parser = argparse.ArgumentParser(description='HomePod audio chain power control')
    parser.add_argument('action', nargs='?', default='status',
                        choices=['powerup', 'shutdown', 'estop', 'status',
                                 'tweeters-on', 'tweeters-off', 'woofer-on',
                                 'woofer-off', 'faults', 'temp'],
                        help='Action to perform')
    parser.add_argument('--woofer', action='store_true',
                        help='Include woofer in powerup (DANGEROUS)')
    parser.add_argument('--unmute', action='store_true',
                        help='Unmute tweeters after powerup')
    parser.add_argument('--port', '-p', help='Serial port path')
    parser.add_argument('--method', '-m', default='auto',
                        choices=['auto', 'serial', 'mmio'])
    args = parser.parse_args()

    mcu = get_mcu(method=args.method, port=args.port)
    if mcu is None:
        print("ERROR: Could not establish MCU communication")
        sys.exit(1)

    chain = AudioChain(mcu)

    try:
        if args.action == 'powerup':
            chain.full_powerup(include_woofer=args.woofer,
                               unmute_tweeters=args.unmute)

        elif args.action == 'shutdown':
            chain.full_shutdown()

        elif args.action == 'estop':
            chain.emergency_stop()

        elif args.action == 'status':
            chain.verify_mcu()
            chain.get_temperature()
            chain.get_telemetry(1)
            chain.check_faults()

        elif args.action == 'tweeters-on':
            chain.init_all_tweeters()
            chain.unmute_all_tweeters()

        elif args.action == 'tweeters-off':
            chain.mute_all_tweeters()

        elif args.action == 'woofer-on':
            print("*** WARNING: Woofer needs crossover protection! ***")
            chain.woofer_on()

        elif args.action == 'woofer-off':
            chain.woofer_off()

        elif args.action == 'faults':
            chain.check_faults()

        elif args.action == 'temp':
            chain.get_temperature()

    except KeyboardInterrupt:
        print("\n\nInterrupted! Running emergency stop...")
        chain.emergency_stop()


if __name__ == '__main__':
    main()
