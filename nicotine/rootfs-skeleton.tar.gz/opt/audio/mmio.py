#!/usr/bin/env python3
"""
mmio.py - Memory-mapped I/O helper for Nicotine audio bring-up.

Provides read32/write32 via /dev/mem for direct register access.
Used by all audio scripts for MCA, UART, NCO, and I2S switch access.
"""

import mmap
import os
import struct
import sys

# Page size for mmap alignment
PAGE_SIZE = 0x1000
PAGE_MASK = ~(PAGE_SIZE - 1)

_fd = None
_mappings = {}  # cache: page_base -> mmap object


def _get_fd():
    global _fd
    if _fd is None:
        try:
            _fd = os.open("/dev/mem", os.O_RDWR | os.O_SYNC)
        except PermissionError:
            print("ERROR: /dev/mem requires root. Run with sudo.", file=sys.stderr)
            sys.exit(1)
        except FileNotFoundError:
            print("ERROR: /dev/mem not found. Is devtmpfs mounted?", file=sys.stderr)
            sys.exit(1)
    return _fd


def _get_mapping(addr, size=PAGE_SIZE):
    """Get or create an mmap for the page containing addr."""
    page_base = addr & PAGE_MASK
    # Ensure we map enough pages to cover addr + size
    end = addr + size
    map_size = ((end - page_base + PAGE_SIZE - 1) & PAGE_MASK)
    if map_size < PAGE_SIZE:
        map_size = PAGE_SIZE

    key = (page_base, map_size)
    if key not in _mappings:
        fd = _get_fd()
        try:
            m = mmap.mmap(fd, map_size, mmap.MAP_SHARED,
                          mmap.PROT_READ | mmap.PROT_WRITE,
                          offset=page_base)
            _mappings[key] = m
        except Exception as e:
            print(f"ERROR: mmap failed for 0x{page_base:x} size 0x{map_size:x}: {e}",
                  file=sys.stderr)
            sys.exit(1)
    return _mappings[key], page_base


def read32(addr):
    """Read a 32-bit register at physical address."""
    m, page_base = _get_mapping(addr)
    offset = addr - page_base
    data = m[offset:offset + 4]
    return struct.unpack("<I", data)[0]


def write32(addr, val):
    """Write a 32-bit register at physical address."""
    m, page_base = _get_mapping(addr)
    offset = addr - page_base
    m[offset:offset + 4] = struct.pack("<I", val & 0xFFFFFFFF)


def read_block(addr, size):
    """Read a block of bytes from physical address."""
    m, page_base = _get_mapping(addr, size)
    offset = addr - page_base
    return m[offset:offset + size]


def dump_regs(base, count, name=""):
    """Dump count 32-bit registers starting at base."""
    if name:
        print(f"\n=== {name} (0x{base:09x}) ===")
    for i in range(0, count * 4, 4):
        val = read32(base + i)
        if val != 0:  # Only print non-zero for clarity
            print(f"  [0x{i:03x}] = 0x{val:08x}")


def dump_regs_all(base, count, name=""):
    """Dump all registers including zeros."""
    if name:
        print(f"\n=== {name} (0x{base:09x}) ===")
    for i in range(0, count * 4, 4):
        val = read32(base + i)
        print(f"  [0x{i:03x}] = 0x{val:08x}")


def cleanup():
    """Close all mappings."""
    global _fd, _mappings
    for m in _mappings.values():
        try:
            m.close()
        except Exception:
            pass
    _mappings.clear()
    if _fd is not None:
        os.close(_fd)
        _fd = None


if __name__ == "__main__":
    # Quick self-test: read first word of MCA3
    if len(sys.argv) > 1:
        addr = int(sys.argv[1], 0)
        val = read32(addr)
        print(f"[0x{addr:09x}] = 0x{val:08x}")
    else:
        print("Usage: mmio.py <address>")
        print("  Reads a 32-bit value from the given physical address via /dev/mem")
    cleanup()
