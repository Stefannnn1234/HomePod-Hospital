/*
 * hpdsp2.h - second-pass speaker processing for the HomePod (1st gen),
 * profile "apple2". Follows Apple's b238a_speaker.dspg more closely than
 * hpdsp.h (profile "apple", left untouched):
 *
 *   stereo in (mid m = (L+R)/2, side s = (L-R)/2), run at Apple's scale
 *   S = L+R, D = L-R
 *     -> loudness -> systemEQ (-6 dB) -> bassAdjust
 *     -> bassRedist 120 Hz: direct/woofer keep everything (LR4 all-pass),
 *        ambient is high-passed
 *     -> systemDRC: 4-band compressor (150 / 530 / 6011 Hz), linked
 *     +-> woofer:  LR4 low-pass 400 Hz + woofer EQ -> excursion guard
 *                  (sliding high-pass + excursion limiter) -> peak limiter
 *     +-> array:   direct beam = S, ambient beams = D (ambEQ)
 *                  -> LR4 high-pass 400 Hz -> array EQ
 *                  -> CircArray: beam FIR x circular-harmonic (modal) FIRs,
 *                     steered to 7 tweeters -> per-driver peak limiters
 *
 * What is Apple's data and what is assumed is spelled out in NOTES-pass2.md.
 * Biquads are double precision (scalar either way on ARMv8, and single
 * precision is noisy for the 30..150 Hz sections); the FIR bank, where the
 * time goes, is single precision (NEON on aarch64).
 */
#ifndef HPDSP2_H
#define HPDSP2_H

#include "hpdsp.h"
#include "apple_b238a_v2.h"
#ifdef __aarch64__
#include <arm_neon.h>
#endif

#define A2_NDRV    7
#define A2_HIST    1024                 /* FIR history per input (power of two) */
#define A2_MAXFILT 8
#define A2_LA_TW   64                   /* tweeter limiter look-ahead, samples */
#define A2_LA_WF   64                   /* woofer peak limiter look-ahead */
#define A2_LA_X    192                  /* excursion guard look-ahead (= modal FIR delay) */
#define A2_CTL     16                   /* control rate divider */
#define A2_DLY     2048

/* assumed electrical model of the woofer path, see NOTES-pass2.md */
#define A2_VFS     35.5                 /* volts peak at digital full scale, amplifier at 0 dB */
#define A2_BL      14.7                 /* force factor, N/A */
#define A2_XPOLE   4.5                  /* Hz, lower pole of the displacement response */

struct a2_lim { float buf[256]; int la, pos; double thr, held, g, att, rel; };

struct a2_cfg {
	int position;                   /* 0 free, 1 wall, 2 book */
	double loud_db;                 /* loudness anchor, > 100 = off */
	double subsonic_hz;
	double woofer_db, tweeter_db, out_db;
	int tw_delay, wf_delay;         /* extra delays, samples */
	double front_deg;               /* where "front" (beam angle 0) points, degrees from tweeter 1 */
	int order[A2_NDRV];             /* order[slot-1] = position of that slot's tweeter around the ring, 0..6 */
	int solo;                       /* 1..7: only that slot plays (the direct beam); 0 = normal */
	int drc, limit, guard;          /* enables */
	int bass_reduce;
	int tw_invert;
	double effort;                  /* 0..1, Apple's thermal "ControlEffort" */
	double volume_db;               /* master (amplifier) volume, for the excursion estimate */
	double xlim_mm;
	double ambient_db;              /* extra gain on the ambient beams */
};

struct a2_filt { int in, delay, n; const float *c; float w[A2_NDRV]; };

struct hpdsp2 {
	struct a2_cfg cfg;
	/* linear front end */
	int loud_on;
	struct dbq loud[2][2], sys[2][16], badj[2][3], ap120, hp120[2];
	double g_pre;
	/* DRC */
	struct dbq sp[2][14];
	double env[4], gdb[4], glin[4], gtgt[4];
	double a_att, a_rel, a_g;
	int ctl;
	/* woofer */
	struct dbq wf[12], xhp[2], xlp1, xlp2;
	int nwf;
	double fc, fc_cur, xpk, xk, xg, xg_tgt, x2pk;
	float xdl[A2_LA_X];
	int xdl_pos;
	struct a2_lim wlim;
	/* array */
	struct dbq amb[8], thp[2][2], aeq[2][4];
	int namb;
	double g_amb;
	float hist[2][A2_HIST * 2];
	int hpos;
	struct a2_filt f[A2_MAXFILT];
	int nf;
	struct a2_lim tlim[A2_NDRV];
	float tdl[A2_NDRV][A2_DLY], wdl[A2_DLY];
	int dpos;
	double g_w, g_t;
	/* meters (read by the caller for its status line) */
	double m_gr[4], m_fc, m_xmm, m_xgr;
	long m_tlim, m_wlim;
};

static double a2_interp(double e, const double *y)
{
	static const double x[4] = { 0.0, 0.4, 0.7, 1.0 };
	int i;

	if (e <= 0) return y[0];
	if (e >= 1) return y[3];
	for (i = 0; i < 3; i++)
		if (e <= x[i + 1])
			return y[i] + (y[i + 1] - y[i]) * (e - x[i]) / (x[i + 1] - x[i]);
	return y[3];
}

static void a2_lim_init(struct a2_lim *l, int la, double thr_db, double rel_ms)
{
	memset(l, 0, sizeof(*l));
	l->la = la;
	l->thr = pow(10.0, thr_db / 20.0);
	l->held = l->g = 1.0;
	l->att = 1.0 - exp(-5.0 / la);                  /* settles within the look-ahead */
	l->rel = 1.0 - exp(-1.0 / (rel_ms * 0.001 * DSP_FS));
}

/* look-ahead peak limiter: the gain is decided on the incoming sample and
 * applied to the sample that entered `la` samples ago */
static inline double a2_lim_run(struct a2_lim *l, double x, long *count)
{
	double a = fabs(x), tgt = a > l->thr ? l->thr / a : 1.0, y;

	l->held += (1.0 - l->held) * l->rel;
	if (tgt < l->held) l->held = tgt;
	if (l->held < l->g) l->g += (l->held - l->g) * l->att;
	else l->g = l->held;
	y = l->buf[l->pos];
	l->buf[l->pos] = (float)x;
	if (++l->pos >= l->la) l->pos = 0;
	y *= l->g;
	if (y > l->thr) { y = l->thr; (*count)++; }     /* residue of the attack ramp */
	else if (y < -l->thr) { y = -l->thr; (*count)++; }
	else if (l->g < 0.999) (*count)++;
	return y;
}

static void a2_allpass(struct dbq *q, double f)
{
	double w0 = 2.0 * M_PI * f / DSP_FS, cs = cos(w0), alpha = sin(w0) / (2.0 * M_SQRT1_2);

	dbq_coef(q, 1 - alpha, -2 * cs, 1 + alpha, 1 + alpha, -2 * cs, 1 - alpha);
}

static void a2_lphp(struct dbq *q, int hp, double f)
{
	struct nbeq_band b = { hp ? 2 : 1, f, 0, 0 };

	dbq_nbeq(q, &b);
}

static const struct a2_pattern *a2_pattern(int id)
{
	unsigned i;

	for (i = 0; i < sizeof(apple_patterns) / sizeof(apple_patterns[0]); i++)
		if (apple_patterns[i].id == id)
			return &apple_patterns[i];
	return &apple_patterns[0];
}

/* append one FIR: input `in`, beam FIR of pattern p convolved with the modal
 * FIR of order m (m = 0: pure delay), with per-driver weights w[] */
static void a2_add_filter(struct hpdsp2 *d, int in, const struct a2_pattern *p, int m, const double *w)
{
	struct a2_filt *f;
	double mx = 0;
	int i, k;

	for (k = 0; k < A2_NDRV; k++)
		if (fabs(w[k]) > mx) mx = fabs(w[k]);
	if (mx < 1e-9 || d->nf >= A2_MAXFILT)
		return;
	f = &d->f[d->nf++];
	memset(f, 0, sizeof(*f));
	f->in = in;
	for (k = 0; k < A2_NDRV; k++)
		f->w[k] = (float)w[k];
	if (m == 0) {
		f->delay = A2_MODAL_DELAY;
		f->n = (p->ntaps + 15) & ~15;
		f->c = p->fir;
		return;
	}
	for (i = 0; i < (int)(sizeof(apple_comb) / sizeof(apple_comb[0])); i++)
		if (apple_comb[i].pattern == p->id && apple_comb[i].order == m) {
			f->delay = 0;
			f->n = A2_COMB_TAPS;
			f->c = apple_comb[i].c;
			return;
		}
	d->nf--;                                         /* no table for this pair: drop it */
}

static void a2_set_guard_hp(struct hpdsp2 *d, double fc)
{
	a2_lphp(&d->xhp[0], 1, fc);
	a2_lphp(&d->xhp[1], 1, fc);
	d->fc_cur = fc;
}

static double a2_base_fc(const struct a2_cfg *c)
{
	static const double whsf[4] = { 30.0, 50.5, 70.0, 80.0 };   /* PuffinPowerParameterMapping */
	double f = a2_interp(c->effort, whsf);

	return f > c->subsonic_hz ? f : c->subsonic_hz;
}

static double a2_xlim(const struct a2_cfg *c)
{
	static const double xl[4] = { 8.0, 6.7, 5.7, 5.0 };          /* Apple's excursion limit, mm */

	return c->xlim_mm * a2_interp(c->effort, xl) / 8.0;
}

static void a2_defaults(struct a2_cfg *c)
{
	int i;

	memset(c, 0, sizeof(*c));
	c->loud_db = -9.0;
	c->subsonic_hz = 40.0;
	c->out_db = -6.0;               /* level match with profile "apple" */
	for (i = 0; i < A2_NDRV; i++) c->order[i] = i;
	c->drc = c->limit = c->guard = 1;
	c->volume_db = -10.0;
	c->xlim_mm = 5.0;
}

static void a2_clear(struct hpdsp2 *d)
{
	struct a2_cfg cfg = d->cfg;
	int i;

	memset(d, 0, sizeof(*d));
	d->cfg = cfg;
	for (i = 0; i < 4; i++) d->glin[i] = d->gtgt[i] = 1.0;
	d->xg = d->xg_tgt = 1.0;
}

/* (re)compute every coefficient from d->cfg; filter state is kept */
static void a2_configure(struct hpdsp2 *d)
{
	const struct a2_cfg *c = &d->cfg;
	int pos = c->position < 0 || c->position > 2 ? 0 : c->position;
	const struct nbeq_band *sys = pos == 1 ? apple_syseq_wall : pos == 2 ? apple_syseq_book : apple_syseq_free;
	double sysgain = pos == 1 ? APPLE_SYSEQ_WALL_GAIN : pos == 2 ? APPLE_SYSEQ_BOOK_GAIN : APPLE_SYSEQ_FREE_GAIN;
	const struct nbeq_band *amb = pos == 1 ? apple_ambeq_wall : pos == 2 ? apple_ambeq_book : apple_ambeq_free;
	int namb = pos == 1 ? (int)(sizeof(apple_ambeq_wall) / sizeof(amb[0])) :
		   pos == 2 ? (int)(sizeof(apple_ambeq_book) / sizeof(amb[0])) :
			      (int)(sizeof(apple_ambeq_free) / sizeof(amb[0]));
	double ambgain = pos == 1 ? APPLE_AMBEQ_WALL_GAIN : pos == 2 ? APPLE_AMBEQ_BOOK_GAIN : APPLE_AMBEQ_FREE_GAIN;
	const struct a2_place *pl = &apple_place[pos];
	struct nbeq_band b;
	double phi[A2_NDRV], w[A2_NDRV];
	int i, k, ch, m, best = -1;

	/* front end */
	d->loud_on = 0;
	if (c->loud_db <= 100.0) {
		double err = 1e9;
		for (i = 0; i < NLOUD; i++)
			if (fabs(apple_loud_anchor[i] - c->loud_db) < err) { err = fabs(apple_loud_anchor[i] - c->loud_db); best = i; }
		d->loud_on = 1;
	}
	for (ch = 0; ch < 2; ch++) {
		if (best >= 0) {
			dbq_raw(&d->loud[ch][0], apple_loud_bass[best]);
			dbq_raw(&d->loud[ch][1], apple_loud_treble[best]);
		}
		for (i = 0; i < NSYS; i++)
			dbq_nbeq(&d->sys[ch][i], &sys[i]);
		b = apple_bassadj[0]; b.gain = -3.0; dbq_nbeq(&d->badj[ch][0], &b);   /* PuffinBassParameterMapping "On" */
		b = apple_bassadj[1]; b.gain = -3.0; dbq_nbeq(&d->badj[ch][1], &b);
		dbq_nbeq(&d->badj[ch][2], &apple_bassadj[2]);
	}
	d->g_pre = pow(10.0, sysgain / 20.0);
	a2_allpass(&d->ap120, 120.0);
	a2_lphp(&d->hp120[0], 1, 120.0);
	a2_lphp(&d->hp120[1], 1, 120.0);

	/* DRC band split: [0..3] 530 LP,LP,HP,HP  [4] AP 6011 on the low half  [5..8] 150 LP,LP,HP,HP
	 *                 [9] AP 150 on the high half  [10..13] 6011 LP,LP,HP,HP */
	for (ch = 0; ch < 2; ch++) {
		struct dbq *s = d->sp[ch];

		a2_lphp(&s[0], 0, apple_drc_xover[1]); a2_lphp(&s[1], 0, apple_drc_xover[1]);
		a2_lphp(&s[2], 1, apple_drc_xover[1]); a2_lphp(&s[3], 1, apple_drc_xover[1]);
		a2_allpass(&s[4], apple_drc_xover[2]);
		a2_lphp(&s[5], 0, apple_drc_xover[0]); a2_lphp(&s[6], 0, apple_drc_xover[0]);
		a2_lphp(&s[7], 1, apple_drc_xover[0]); a2_lphp(&s[8], 1, apple_drc_xover[0]);
		a2_allpass(&s[9], apple_drc_xover[0]);
		a2_lphp(&s[10], 0, apple_drc_xover[2]); a2_lphp(&s[11], 0, apple_drc_xover[2]);
		a2_lphp(&s[12], 1, apple_drc_xover[2]); a2_lphp(&s[13], 1, apple_drc_xover[2]);
	}
	d->a_att = 1.0 - exp(-1.0 / (0.005 * DSP_FS));          /* assumed 5 ms / 50 ms */
	d->a_rel = 1.0 - exp(-1.0 / (0.050 * DSP_FS));
	d->a_g = 1.0 - exp(-1.0 / (0.002 * DSP_FS));

	/* woofer */
	d->nwf = 0;
	for (i = 0; i < NWEQ; i++)
		dbq_nbeq(&d->wf[d->nwf++], &apple_woofer_eq[i]);
	d->fc = a2_base_fc(c);
	if (d->fc_cur < d->fc || !c->guard)
		a2_set_guard_hp(d, d->fc);
	{       /* one-pole low-pass at A2_XPOLE: displacement estimate (see a2_run) */
		double k = exp(-2.0 * M_PI * A2_XPOLE / DSP_FS);
		dbq_coef(&d->xlp1, 1 - k, 0, 0, 1, -k, 0);
		dbq_coef(&d->xlp2, 1 - k, 0, 0, 1, -k, 0);
	}
	/* mm of cone travel per unit of woofer signal at Apple's scale */
	d->xk = 1000.0 * A2_VFS * pow(10.0, (c->volume_db + c->out_db + c->woofer_db) / 20.0) /
		(A2_BL * 2.0 * M_PI * A2_XPOLE);
	if (d->wlim.la != A2_LA_WF)
		a2_lim_init(&d->wlim, A2_LA_WF, -0.2, 100.0);

	/* array */
	d->namb = 0;
	for (i = 0; i < namb && i < 8; i++)
		dbq_nbeq(&d->amb[d->namb++], &amb[i]);
	d->g_amb = pow(10.0, (ambgain + c->ambient_db) / 20.0);
	for (ch = 0; ch < 2; ch++) {
		dbq_nbeq(&d->thp[ch][0], &apple_array_xover[0]);
		dbq_nbeq(&d->thp[ch][1], &apple_array_xover[1]);
		for (i = 0; i < NAEQ; i++)
			dbq_raw(&d->aeq[ch][i], apple_array_eq[i]);
	}
	for (k = 0; k < A2_NDRV; k++) {
		if (d->tlim[k].la != A2_LA_TW)
			a2_lim_init(&d->tlim[k], A2_LA_TW, -1.2, 50.0);
		phi[k] = 2.0 * M_PI * k / A2_NDRV;              /* FirstDriverAngles = 0 */
	}
	/*
	 * CircArray. A beam with pattern coefficients a[0..3] steered to angle t
	 * drives the tweeter at angle phi with
	 *     sum_m a[m] * (beamFIR * modalFIR_m) * cos(m * (phi - t))
	 * Direct beam (input 0): pattern/angle straight from Apple's 'ca' settings.
	 * Ambient (input 1 = D): free standing, both ambient beams carry D;
	 * wall/shelf, Apple feeds left and right ambience to the two beams and we
	 * substitute +D and -D (assumption).
	 */
	d->nf = 0;
	{
		const struct a2_pattern *p0 = a2_pattern(pl->pattern[0]);
		double t0 = (pl->angle[0] + c->front_deg) * M_PI / 180.0;

		for (m = 0; m < 4; m++) {
			for (k = 0; k < A2_NDRV; k++)
				w[k] = c->solo ? (m == 0) : p0->comp[m] * cos(m * (phi[k] - t0));
			a2_add_filter(d, 0, p0, m, w);
		}
		if (!c->solo) {
			const struct a2_pattern *p1 = a2_pattern(pl->pattern[1]), *p2 = a2_pattern(pl->pattern[2]);
			double t1 = (pl->angle[1] + c->front_deg) * M_PI / 180.0;
			double t2 = (pl->angle[2] + c->front_deg) * M_PI / 180.0;
			double s2 = pos == 0 ? 1.0 : -1.0;

			if (p1 == p2) {
				for (m = 0; m < 4; m++) {
					for (k = 0; k < A2_NDRV; k++)
						w[k] = p1->comp[m] * (cos(m * (phi[k] - t1)) + s2 * cos(m * (phi[k] - t2)));
					a2_add_filter(d, 1, p1, m, w);
				}
			} else {
				for (m = 0; m < 4; m++) {
					for (k = 0; k < A2_NDRV; k++) w[k] = p1->comp[m] * cos(m * (phi[k] - t1));
					a2_add_filter(d, 1, p1, m, w);
					for (k = 0; k < A2_NDRV; k++) w[k] = s2 * p2->comp[m] * cos(m * (phi[k] - t2));
					a2_add_filter(d, 1, p2, m, w);
				}
			}
		}
	}
	d->g_w = pow(10.0, (c->woofer_db + c->out_db) / 20.0);
	d->g_t = pow(10.0, (c->tweeter_db + c->out_db) / 20.0) * (c->tw_invert ? -1.0 : 1.0);
}

static inline float a2_fir(const float *c, const float *x, int n)
{
#ifdef __aarch64__
	float32x4_t a0 = vdupq_n_f32(0), a1 = a0, a2 = a0, a3 = a0;
	int i;

	for (i = 0; i < n; i += 16) {
		a0 = vfmaq_f32(a0, vld1q_f32(c + i), vld1q_f32(x + i));
		a1 = vfmaq_f32(a1, vld1q_f32(c + i + 4), vld1q_f32(x + i + 4));
		a2 = vfmaq_f32(a2, vld1q_f32(c + i + 8), vld1q_f32(x + i + 8));
		a3 = vfmaq_f32(a3, vld1q_f32(c + i + 12), vld1q_f32(x + i + 12));
	}
	return vaddvq_f32(vaddq_f32(vaddq_f32(a0, a1), vaddq_f32(a2, a3)));
#else
	float a[8] = { 0 };
	int i, j;

	for (i = 0; i < n; i += 8)
		for (j = 0; j < 8; j++)
			a[j] += c[i + j] * x[i + j];
	return ((a[0] + a[1]) + (a[2] + a[3])) + ((a[4] + a[5]) + (a[6] + a[7]));
#endif
}

/* compressor curve: level (dB) -> gain (dB), soft knee, limited range */
static inline double a2_curve(const struct drc_band *b, double lvl)
{
	double over = lvl - b->thr, slope = 1.0 / b->ratio - 1.0, gr;

	if (over <= -b->knee / 2) gr = 0;
	else if (over < b->knee / 2) gr = slope * (over + b->knee / 2) * (over + b->knee / 2) / (2 * b->knee);
	else gr = slope * over;
	if (gr < b->range) gr = b->range;
	return gr;
}

/*
 * One sample. m = (L+R)/2, s = (L-R)/2, both -1..1.
 * *woofer and tw[0..6] (indexed by TDM slot - 1) come back in DAC full-scale units.
 */
static inline void a2_run(struct hpdsp2 *d, double m, double s, double *woofer, double *tw)
{
	const struct a2_cfg *c = &d->cfg;
	double x[2], W, B, wb[4], bb[4], lo, hi, t, y, drv[A2_NDRV], e;
	struct dbq *q;
	int i, k, ch, p, tick;

	tick = ++d->ctl >= A2_CTL;
	if (tick) d->ctl = 0;
	x[0] = 2.0 * m;                                  /* Apple's beamMix: sum and difference, no 1/2 */
	x[1] = 2.0 * s;
	for (ch = 0; ch < 2; ch++) {
		t = x[ch];
		if (d->loud_on)
			t = dbq_run(&d->loud[ch][1], dbq_run(&d->loud[ch][0], t));
		for (i = 0; i < NSYS; i++)
			t = dbq_run(&d->sys[ch][i], t);
		if (c->bass_reduce)
			for (i = 0; i < 3; i++)
				t = dbq_run(&d->badj[ch][i], t);
		x[ch] = t * d->g_pre;
	}
	W = dbq_run(&d->ap120, x[0]);                    /* HPF120 + LPF120 of the sum = all-pass */
	B = dbq_run(&d->hp120[1], dbq_run(&d->hp120[0], x[1]));

	if (c->drc) {
		for (ch = 0; ch < 2; ch++) {
			double *o = ch ? bb : wb, in = ch ? B : W;

			q = d->sp[ch];
			lo = dbq_run(&q[1], dbq_run(&q[0], in));
			hi = dbq_run(&q[3], dbq_run(&q[2], in));
			lo = dbq_run(&q[4], lo);
			hi = dbq_run(&q[9], hi);
			o[0] = dbq_run(&q[6], dbq_run(&q[5], lo));
			o[1] = dbq_run(&q[8], dbq_run(&q[7], lo));
			o[2] = dbq_run(&q[11], dbq_run(&q[10], hi));
			o[3] = dbq_run(&q[13], dbq_run(&q[12], hi));
		}
		for (i = 0; i < 4; i++) {
			e = fabs(wb[i]);
			if (fabs(bb[i]) > e) e = fabs(bb[i]);
			d->env[i] += (e - d->env[i]) * (e > d->env[i] ? d->a_att : d->a_rel);
		}
		if (tick) {
			for (i = 0; i < 4; i++) {
				double gr = a2_curve(&apple_drc_band[i], 20.0 * log10(d->env[i] + 1e-9));

				d->m_gr[i] = gr;
				d->gtgt[i] = pow(10.0, (gr + apple_drc_band[i].makeup) / 20.0);
			}
		}
		W = B = 0.0;
		for (i = 0; i < 4; i++) {
			d->glin[i] += (d->gtgt[i] - d->glin[i]) * d->a_g;
			W += wb[i] * d->glin[i];
			B += bb[i] * d->glin[i];
		}
	}

	/* ---- woofer ---- */
	lo = W;
	for (i = 0; i < d->nwf; i++)
		lo = dbq_run(&d->wf[i], lo);
	if (c->guard) {
		double xl = a2_xlim(c), xe;

		/* cone travel if nothing is done: |x| = V / (Bl * w) between the two poles */
		xe = fabs(dbq_run(&d->xlp1, lo)) * d->xk;
		d->xpk = xe > d->xpk ? xe : d->xpk * 0.99995;               /* ~0.4 s decay */
		if (tick) {
			/* a 2nd-order high-pass at fc takes (f/fc)^2 off what lies below it */
			double want = d->fc * (d->xpk > xl ? sqrt(d->xpk / xl) : 1.0);

			if (want > 130.0) want = 130.0;
			if (want > d->fc_cur * 1.005 || want < d->fc_cur * 0.98) {
				double nf = want > d->fc_cur ? want : d->fc_cur * 0.98 > want ? d->fc_cur * 0.98 : want;
				a2_set_guard_hp(d, nf);
			}
			d->m_fc = d->fc_cur;
			d->m_xmm = d->xpk;
		}
		lo = dbq_run(&d->xhp[1], dbq_run(&d->xhp[0], lo));
		/* what is left is limited in the excursion domain, with look-ahead */
		xe = fabs(dbq_run(&d->xlp2, lo)) * d->xk;
		d->x2pk = xe > d->x2pk ? xe : d->x2pk * 0.9995;
		d->xg_tgt = d->x2pk > xl ? xl / d->x2pk : 1.0;
		d->xg += (d->xg_tgt - d->xg) * (d->xg_tgt < d->xg ? 0.02 : 0.0005);
		d->m_xgr = d->xg;
		y = d->xdl[d->xdl_pos];
		d->xdl[d->xdl_pos] = (float)lo;
		if (++d->xdl_pos >= A2_LA_X) d->xdl_pos = 0;
		lo = y * d->xg;
	} else {
		lo = dbq_run(&d->xhp[1], dbq_run(&d->xhp[0], lo));
		y = d->xdl[d->xdl_pos];
		d->xdl[d->xdl_pos] = (float)lo;
		if (++d->xdl_pos >= A2_LA_X) d->xdl_pos = 0;
		lo = y;
	}
	if (c->limit)
		lo = a2_lim_run(&d->wlim, lo, &d->m_wlim);
	else {
		y = d->wlim.buf[d->wlim.pos]; d->wlim.buf[d->wlim.pos] = (float)lo;
		if (++d->wlim.pos >= d->wlim.la) d->wlim.pos = 0;
		lo = y;
	}

	/* ---- array ---- */
	hi = dbq_run(&d->thp[0][1], dbq_run(&d->thp[0][0], W));
	for (i = 0; i < NAEQ; i++)
		hi = dbq_run(&d->aeq[0][i], hi);
	t = B;
	for (i = 0; i < d->namb; i++)
		t = dbq_run(&d->amb[i], t);
	t = dbq_run(&d->thp[1][1], dbq_run(&d->thp[1][0], t * d->g_amb));
	for (i = 0; i < NAEQ; i++)
		t = dbq_run(&d->aeq[1][i], t);

	p = d->hpos = (d->hpos + A2_HIST - 1) & (A2_HIST - 1);
	d->hist[0][p] = d->hist[0][p + A2_HIST] = (float)hi;
	d->hist[1][p] = d->hist[1][p + A2_HIST] = (float)t;
	for (k = 0; k < A2_NDRV; k++)
		drv[k] = 0.0;
	for (i = 0; i < d->nf; i++) {
		const struct a2_filt *f = &d->f[i];
		float v = a2_fir(f->c, &d->hist[f->in][(p + f->delay) & (A2_HIST - 1)], f->n);

		for (k = 0; k < A2_NDRV; k++)
			drv[k] += f->w[k] * v;
	}

	/* ---- limiters, alignment, slot order ---- */
	d->dpos = (d->dpos + 1) & (A2_DLY - 1);
	d->wdl[d->dpos] = (float)lo;
	*woofer = d->wdl[(d->dpos - c->wf_delay) & (A2_DLY - 1)] * d->g_w;
	for (k = 0; k < A2_NDRV; k++) {
		int pos_k = c->order[k];                 /* slot k+1 sits at ring position order[k] */

		y = drv[pos_k];
		if (c->solo && c->solo != k + 1)
			y = 0.0;
		if (c->limit)
			y = a2_lim_run(&d->tlim[k], y, &d->m_tlim);
		else {
			struct a2_lim *l = &d->tlim[k];
			double z = l->buf[l->pos];

			l->buf[l->pos] = (float)y;
			if (++l->pos >= l->la) l->pos = 0;
			y = z;
		}
		d->tdl[k][d->dpos] = (float)y;
		tw[k] = d->tdl[k][(d->dpos - c->tw_delay) & (A2_DLY - 1)] * d->g_t;
	}
}

#endif
