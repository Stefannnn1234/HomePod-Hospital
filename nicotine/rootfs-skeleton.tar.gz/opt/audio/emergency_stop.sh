#!/bin/sh
#
# emergency_stop.sh - IMMEDIATE shutdown of all HomePod audio amplifiers.
#
# Run this if anything goes wrong during audio testing!
#
# This uses the nitrogen.py script to send [AMP,X] (fast shutdown)
# and [WFR,N] (woofer off) commands to the Nitrogen MCU.
#
# Can also be run standalone with raw serial if Python isn't available.

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "!!! EMERGENCY AUDIO SHUTDOWN !!!"

# Method 1: Use nitrogen.py if available
if command -v python3 >/dev/null 2>&1 && [ -f "$SCRIPT_DIR/nitrogen.py" ]; then
    echo "Using nitrogen.py for shutdown..."
    python3 "$SCRIPT_DIR/nitrogen.py" cmd "[AMP,X]"
    python3 "$SCRIPT_DIR/nitrogen.py" cmd "[WFR,N]"
    echo "Shutdown commands sent via Python."
    exit 0
fi

# Method 2: Direct serial if we know the port
for PORT in /dev/ttyS8 /dev/ttySAC8 /dev/ttyAPPLE8; do
    if [ -c "$PORT" ]; then
        echo "Using raw serial: $PORT"
        # Configure baud rate (may fail if stty doesn't support 460800)
        stty -F "$PORT" 460800 cs8 -parenb -cstopb raw 2>/dev/null

        # Send emergency commands
        printf '[AMP,X]\n' > "$PORT"
        sleep 0.1
        printf '[WFR,N]\n' > "$PORT"
        echo "Shutdown commands sent via $PORT."
        exit 0
    fi
done

# Method 3: devmem if nothing else works
if command -v devmem >/dev/null 2>&1; then
    echo "WARNING: Attempting MMIO UART access via devmem..."
    echo "This may not work if UART8 baud rate isn't already set."

    UART_BASE=0x20a0e0000
    UTXH=$((UART_BASE + 0x20))

    # Write "[AMP,X]\n" byte by byte
    for BYTE in 0x5B 0x41 0x4D 0x50 0x2C 0x58 0x5D 0x0A; do
        devmem $UTXH 32 $BYTE 2>/dev/null
        usleep 100 2>/dev/null || sleep 0.001
    done

    sleep 0.1

    # Write "[WFR,N]\n" byte by byte
    for BYTE in 0x5B 0x57 0x46 0x52 0x2C 0x4E 0x5D 0x0A; do
        devmem $UTXH 32 $BYTE 2>/dev/null
        usleep 100 2>/dev/null || sleep 0.001
    done

    echo "Shutdown bytes sent via devmem (may not have worked)."
    exit 0
fi

echo "ERROR: No method available to communicate with MCU!"
echo "If speakers are making noise, physically disconnect power."
exit 1
