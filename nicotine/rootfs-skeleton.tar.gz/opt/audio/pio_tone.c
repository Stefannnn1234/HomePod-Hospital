/*
 * pio_tone.c - High-performance PIO test tone for HomePod MCA3.
 *
 * This is a C version of the test tone generator that can achieve
 * much closer to real-time 48kHz sample output compared to the
 * Python PIO version.
 *
 * Compile: gcc -O2 -o pio_tone pio_tone.c -lm
 * (On the HomePod initramfs, use the cross-compiler or a static build)
 *
 * Usage:
 *   pio_tone <freq_hz> <amplitude_db> <duration_s> <slot>
 *   pio_tone 1000 -30 2.0 1    # 1kHz at -30dB for 2s on tweeter 1
 *
 * SAFETY:
 *   - Maximum amplitude is clamped to -20dB
 *   - Slot 0 (woofer) is blocked (needs --woofer flag)
 *   - Ctrl+C immediately stops output
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <errno.h>
#include <stdint.h>

/* MCA3 hardware addresses */
#define MCA3_BASE           0x20a0ac000ULL
#define MCA3_SIZE           0x4000

/* MCA register offsets */
#define REG_STATUS          0x000
#define REG_TX_PORT_FIFO    0x408
#define REG_TX_PORT_DATA    0x40C

/* Audio parameters */
#define SAMPLE_RATE         48000
#define NUM_SLOTS           8
#define MAX_AMPLITUDE_DB    (-20.0)
#define DEFAULT_AMPLITUDE_DB (-30.0)

/* Page alignment */
#define PAGE_SIZE           4096
#define PAGE_MASK           (~(PAGE_SIZE - 1))

static volatile int g_running = 1;
static volatile uint32_t *g_mca_regs = NULL;
static int g_mem_fd = -1;

static void sigint_handler(int sig) {
    (void)sig;
    g_running = 0;
    fprintf(stderr, "\nStopping...\n");
}

static inline uint32_t reg_read(unsigned offset) {
    return g_mca_regs[offset / 4];
}

static inline void reg_write(unsigned offset, uint32_t val) {
    g_mca_regs[offset / 4] = val;
}

static int map_registers(void) {
    g_mem_fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (g_mem_fd < 0) {
        perror("open /dev/mem");
        return -1;
    }

    uint64_t page_base = MCA3_BASE & PAGE_MASK;
    unsigned page_offset = MCA3_BASE - page_base;

    void *mapped = mmap(NULL, MCA3_SIZE + page_offset,
                        PROT_READ | PROT_WRITE, MAP_SHARED,
                        g_mem_fd, page_base);
    if (mapped == MAP_FAILED) {
        perror("mmap MCA3");
        close(g_mem_fd);
        return -1;
    }

    g_mca_regs = (volatile uint32_t *)((char *)mapped + page_offset);

    /* Quick check */
    uint32_t status = reg_read(REG_STATUS);
    if (status == 0xFFFFFFFF) {
        fprintf(stderr, "WARNING: MCA3 reads 0xFFFFFFFF - may not be clocked!\n");
    }
    printf("MCA3 STATUS: 0x%08x\n", status);
    return 0;
}

static double db_to_linear(double db) {
    return pow(10.0, db / 20.0);
}

static void play_tone(int freq_hz, double amplitude_db, double duration_s,
                      int target_slot) {
    if (amplitude_db > MAX_AMPLITUDE_DB) {
        fprintf(stderr, "SAFETY: Clamping amplitude to %.0f dB\n",
                MAX_AMPLITUDE_DB);
        amplitude_db = MAX_AMPLITUDE_DB;
    }

    double amplitude = db_to_linear(amplitude_db);
    int32_t max_val = 0x7FFFFFFF;
    int num_samples = (int)(duration_s * SAMPLE_RATE);

    printf("Test tone: %d Hz, %.1f dB (%.6f linear), %.1fs, slot %d\n",
           freq_hz, amplitude_db, amplitude, duration_s, target_slot);
    printf("Generating %d samples at %d Hz sample rate\n",
           num_samples, SAMPLE_RATE);

    /* Pre-compute one cycle of the sine wave for speed */
    int cycle_len = SAMPLE_RATE / freq_hz;
    if (cycle_len < 1) cycle_len = 1;
    int32_t *cycle = malloc(cycle_len * sizeof(int32_t));
    if (!cycle) {
        perror("malloc");
        return;
    }

    for (int i = 0; i < cycle_len; i++) {
        double t = (double)i / SAMPLE_RATE;
        double val = amplitude * sin(2.0 * M_PI * freq_hz * t);
        cycle[i] = (int32_t)(val * (double)max_val);
    }

    printf("Starting PIO output... (Ctrl+C to stop)\n");

    struct timeval tv_start, tv_now;
    gettimeofday(&tv_start, NULL);

    int frames_written = 0;
    int cycle_idx = 0;

    /* Target ~20.83us per frame (48kHz) */
    /* Use a busy-wait loop for timing accuracy */

    while (g_running && frames_written < num_samples) {
        /* Write one TDM frame: 8 slots */
        for (int slot = 0; slot < NUM_SLOTS; slot++) {
            uint32_t sample;
            if (slot == target_slot) {
                /* Convert signed to unsigned for register write */
                int32_t s = cycle[cycle_idx];
                sample = (uint32_t)s;
            } else {
                sample = 0; /* Silence on other slots */
            }
            reg_write(REG_TX_PORT_DATA, sample);
        }

        cycle_idx++;
        if (cycle_idx >= cycle_len)
            cycle_idx = 0;

        frames_written++;

        /* Simple busy-wait timing
         * This burns CPU but gives the best timing accuracy.
         * A real driver would use DMA or interrupts.
         */
        /* Only do timing check every 100 frames to reduce overhead */
        if ((frames_written & 0xFF) == 0) {
            gettimeofday(&tv_now, NULL);
            double elapsed = (tv_now.tv_sec - tv_start.tv_sec)
                           + (tv_now.tv_usec - tv_start.tv_usec) / 1e6;
            double expected = (double)frames_written / SAMPLE_RATE;

            /* If we're ahead, spin-wait */
            while (elapsed < expected && g_running) {
                gettimeofday(&tv_now, NULL);
                elapsed = (tv_now.tv_sec - tv_start.tv_sec)
                        + (tv_now.tv_usec - tv_start.tv_usec) / 1e6;
            }
        }
    }

    gettimeofday(&tv_now, NULL);
    double elapsed = (tv_now.tv_sec - tv_start.tv_sec)
                   + (tv_now.tv_usec - tv_start.tv_usec) / 1e6;

    printf("Wrote %d frames in %.3f seconds\n", frames_written, elapsed);
    printf("Effective rate: %.0f Hz (target: %d Hz)\n",
           frames_written / elapsed, SAMPLE_RATE);

    free(cycle);
}

int main(int argc, char *argv[]) {
    int freq_hz = 1000;
    double amplitude_db = DEFAULT_AMPLITUDE_DB;
    double duration_s = 1.0;
    int target_slot = 1;
    int allow_woofer = 0;

    if (argc >= 2) freq_hz = atoi(argv[1]);
    if (argc >= 3) amplitude_db = atof(argv[2]);
    if (argc >= 4) duration_s = atof(argv[3]);
    if (argc >= 5) target_slot = atoi(argv[4]);
    if (argc >= 6 && strcmp(argv[5], "--woofer") == 0)
        allow_woofer = 1;

    if (freq_hz < 20 || freq_hz > 20000) {
        fprintf(stderr, "Frequency must be 20-20000 Hz\n");
        return 1;
    }

    if (target_slot < 0 || target_slot > 7) {
        fprintf(stderr, "Slot must be 0-7\n");
        return 1;
    }

    if (target_slot == 0 && !allow_woofer) {
        fprintf(stderr, "SAFETY: Slot 0 (woofer) blocked!\n");
        fprintf(stderr, "The woofer needs crossover protection.\n");
        fprintf(stderr, "Add --woofer flag to override (AT YOUR OWN RISK).\n");
        return 1;
    }

    signal(SIGINT, sigint_handler);
    signal(SIGTERM, sigint_handler);

    if (map_registers() != 0) {
        return 1;
    }

    play_tone(freq_hz, amplitude_db, duration_s, target_slot);

    /* Clean up */
    printf("Done.\n");
    if (g_mem_fd >= 0) close(g_mem_fd);
    return 0;
}
