#!/usr/bin/env python3
"""
homepod-audio.py -- audio service daemon for the HomePod (1st gen) under Linux.

Single file, Python 3 stdlib only.  No ALSA: every piece of hardware is driven
from userspace through /dev/mem, plus /dev/ttySAC8 for MCU transmit.

    PMGR power domains -> PWM 360 kHz -> GPIO -> UART8 -> Nitrogen MCU (AEAC)
    -> NCO ch3 -> MCA3 (8 x 32-bit TDM) -> I2S switch -> amps

Services
    TCP  :7002  raw PCM in.  Default 48 kHz / 24-bit signed LE / mono.
                Optional 16-byte header:
                    "HPOD" | u32le rate | u8 channels | u8 bits | 6 reserved
                Other formats (16/32 bit, multi-channel, other rates) are
                converted to 48 kHz mono in software.
    HTTP :7001  JSON control API
                GET  /status
                POST /volume    {"tweeter":0-255,"woofer":0-255}
                POST /slot      {"slot":0-7}        0 = woofer, 1-7 = tweeters
                POST /test      440 Hz, 3 s, quiet  (optional {"slot":n})
                POST /test-all  all 8 speakers, 1 s each, pop-free switching
                POST /stop      stop playback and mute the amps
                POST /amp       {"state":"standby"|"active"}
                POST /init      full hardware init
                Append ?cgi=1 to get errors as HTTP 200 + {"ok":false,...}
                (BusyBox wget drops the body of non-2xx replies).

Volume convention (API, 0-255, HIGHER = LOUDER, 0 = quietest):
    The amp registers count the other way round (SSM3515 DAC_VOL: 0x00 = +24 dB,
    0x40 = 0 dB, 0xFF = mute; CS4350: 0x00 = 0 dB, 0.5 dB attenuation per step),
    so the register value sent to the MCU is 255 - volume.
        tweeter dB = 0.375 * v - 71.625   (v = 0 is mute, v = 191 is 0 dB)
        woofer  dB = 0.5   * v - 127.5    (v = 255 is 0 dB)
    Tweeter volume is capped at --max-tweeter (default 191 = 0 dB) because
    nothing here does crossover, EQ or excursion limiting.

Run with --dry-run to exercise everything against fake registers and a
simulated MCU (no /dev/mem access at all).
"""

import argparse
import array
import json
import math
import mmap
import os
import select
import signal
import socket
import struct
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs

try:
    import termios
except ImportError:  # only matters off-target
    termios = None

# --------------------------------------------------------------------------
# Hardware constants
# --------------------------------------------------------------------------
PMGR_BASE = 0x20E000000
PMGR_SIZE = 0x30000
PS_SIO_P = 0x201F8
PS_MCA3 = 0x20148
PS_PWM0 = 0x20158
NCO3_OFF = 0x14000            # NCO channel 3, relative to PMGR base
NCO_PARENT_HZ = 342857142
NCO_RATE_HZ = 24576000        # 2 x BCLK (12.288 MHz)

PWM_BASE = 0x20A118000
GPIO_BASE = 0x20E300000       # one 32-bit register per pin
UART8_BASE = 0x20A0E0000
UART_TTY = "/dev/ttySAC8"
UTRSTAT = 0x10
URXH = 0x24
B115200 = 0x1002

MCA3_BASE = 0x20A0AC000
MCLK_BASE = 0x20A002000       # MCA3 MCLK control at +0x0C (0x20A00200C)
I2S_SW_BASE = 0x20A003000

MCA_CTRL = 0x0C
MCA_TX_CTRL = 0x18
MCA_TX_STAT = 0x1C
MCA_TX_MASK = 0x24
MCA_TX_DATA = 0x28
MCA_IRQ = 0x40

GPIO_UART_PINS = (58, 59)     # must have MODE=1 (bit 1) or the MCU never hears us
GPIO_BUF_EN = 67              # active LOW

# AEAC (Nitrogen MCU) protocol
CMD_GET_VERSION = 0x01
CMD_AMP_OFF = 0x10
CMD_AMP_STANDBY = 0x11
CMD_AMP_ACTIVE = 0x12
CMD_WOOFER_VOL = 0x18
CMD_TWEETER_VOL = 0x19
CMD_TELEMETRY = 0x51
RSP_TELEMETRY = 0xE3
AMP_STATE_BY_TYPE = {0xF0: "off", 0xF1: "standby", 0xF2: "active"}
EVENT_NAMES = {0xF4: "AudioUvlo", 0xF5: "PphvUvlo", 0xF6: "WooferAmpFault",
               0xF8: "Error"}

# Audio
RATE = 48000
SLOTS = 8
FIFO_HIGH = 120               # keep the 128-word TX FIFO filled up to here
BURST = 80                    # words per burst
MIN_ROOM = 16                 # do not bother topping up less than this
FULL_SCALE = 0x7FFFFF

DEFAULT_TWEETER = 159         # -12 dB
DEFAULT_WOOFER = 215          # -20 dB
TEST_DBFS = -20.0             # "quiet" test tone level
PLAYERS = ("stream", "test", "test-all")

# Shared with hpfeed (external feeder mode)
AMP_STATE_FILE = "/run/homepod/amp.state"     # written here: off / standby / active
FEED_STATE_FILE = "/run/homepod/feed.state"   # written by hpfeed: play / idle


def log(msg):
    sys.stdout.write("%s %s\n" % (time.strftime("%H:%M:%S"), msg))
    sys.stdout.flush()


class HardwareError(Exception):
    pass


class ApiError(Exception):
    def __init__(self, status, msg):
        Exception.__init__(self, msg)
        self.status = status


# --------------------------------------------------------------------------
# Volume helpers
# --------------------------------------------------------------------------
def tweeter_db(v):
    return None if v <= 0 else round(0.375 * v - 71.625, 3)


def woofer_db(v):
    return round(0.5 * v - 127.5, 1)


def vol_to_reg(v):
    return 255 - v


# --------------------------------------------------------------------------
# AEAC framing:  7E | len | cmd | seq | cksum | payload   (7E/7D stuffing)
# --------------------------------------------------------------------------
def aeac_frame(cmd, payload=b"", seq=0):
    body = bytes((len(payload), cmd & 0xFF, seq & 0xFF))
    ck = (-(0x7E + sum(body) + sum(payload))) & 0xFF
    out = bytearray((0x7E,))
    for b in body + bytes((ck,)) + bytes(payload):
        if b == 0x7E:
            out += b"\x7d\x5e"
        elif b == 0x7D:
            out += b"\x7d\x5d"
        else:
            out.append(b)
    return bytes(out)


class Deframer:
    """Incremental AEAC frame parser.  feed() returns [(type, seq, payload)]."""

    def __init__(self):
        self.buf = None
        self.esc = False
        self.bad = 0

    def feed(self, data):
        frames = []
        for b in data:
            if b == 0x7E:
                self.buf = bytearray()
                self.esc = False
                continue
            if self.buf is None:
                continue
            if self.esc:
                b ^= 0x20
                self.esc = False
            elif b == 0x7D:
                self.esc = True
                continue
            buf = self.buf
            buf.append(b)
            if len(buf) >= 4 and len(buf) == 4 + buf[0]:
                if (0x7E + sum(buf)) & 0xFF == 0:
                    frames.append((buf[1], buf[2], bytes(buf[4:])))
                else:
                    self.bad += 1
                self.buf = None
        return frames


# --------------------------------------------------------------------------
# Register access
# --------------------------------------------------------------------------
class DevMem:
    """/dev/mem mappings exposed as memoryview('I') (index = offset // 4)."""

    def __init__(self):
        self.fd = os.open("/dev/mem", os.O_RDWR | os.O_SYNC)
        self._keep = []

    def map(self, base, size=0x1000):
        size = max(size, 0x1000)
        mm = mmap.mmap(self.fd, size, mmap.MAP_SHARED,
                       mmap.PROT_READ | mmap.PROT_WRITE, offset=base)
        self._keep.append(mm)
        return memoryview(mm).cast("I")


class FakeMem:
    """Plain RAM instead of registers (--dry-run)."""

    def map(self, base, size=0x1000):
        return memoryview(bytearray(max(size, 0x1000))).cast("I")


class Uart:
    """UART8: TX through the tty driver, RX by polling the registers.

    The tty must stay open (the driver only runs the baud clock while the
    port is open), but its RX interrupt never fires on this SoC, so received
    bytes are taken straight from UTRSTAT/URXH.
    """

    def __init__(self, regs):
        self.regs = regs
        self.fd = -1
        self._open()

    def _open(self):
        if self.fd >= 0:
            try:
                os.close(self.fd)
            except OSError:
                pass
        self.fd = os.open(UART_TTY, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        a = termios.tcgetattr(self.fd)
        a[0] = 0
        a[1] = 0
        a[2] = termios.CS8 | termios.PARENB | termios.CLOCAL | termios.CREAD
        a[3] = 0
        a[4] = B115200
        a[5] = B115200
        a[6][termios.VMIN] = 0
        a[6][termios.VTIME] = 5
        termios.tcsetattr(self.fd, termios.TCSANOW, a)

    def tx(self, data):
        try:
            os.write(self.fd, data)
        except OSError as e:
            # A hangup on the tty (for instance a login shell that owned the
            # port exiting) leaves this descriptor dead for good: EIO on every
            # write. Losing the MCU link with the amplifiers powered is not
            # acceptable, so open the port again and send once more.
            log("UART write failed (%s): reopening %s" % (e, UART_TTY))
            self._open()
            os.write(self.fd, data)

    def rx(self, limit=256):
        r = self.regs
        out = bytearray()
        while len(out) < limit and r[UTRSTAT // 4] & 1:
            out.append(r[URXH // 4] & 0xFF)
        return out

    def close(self):
        try:
            os.close(self.fd)
        except OSError:
            pass


class FakeUart:
    """Simulated Nitrogen MCU for --dry-run."""

    def __init__(self):
        self.df = Deframer()
        self.q = bytearray()
        self.vol_t = bytes([0x40] * 7)
        self.vol_w = b"\x00"

    def tx(self, data):
        for cmd, seq, pl in self.df.feed(data):
            if cmd == CMD_GET_VERSION:
                self._r(0x81, bytes((0, 61)), seq)
            elif cmd in (CMD_AMP_OFF, CMD_AMP_STANDBY, CMD_AMP_ACTIVE):
                self._r(0xE0 + cmd, b"", seq)
            elif cmd == CMD_WOOFER_VOL:
                if pl:
                    self.vol_w = pl[:1]
                self._r(0x98, self.vol_w, seq)
            elif cmd == CMD_TWEETER_VOL:
                if len(pl) == 7:
                    self.vol_t = pl
                self._r(0x99, self.vol_t, seq)
            elif cmd == CMD_TELEMETRY:
                self._r(0xD1, b"", seq)
                if pl[:1] == b"\x02":
                    t = bytearray(42)
                    t[0] = 0x20
                    struct.pack_into("<h", t, 0x0C, 314)
                    self._r(RSP_TELEMETRY, bytes(t), seq)

    def _r(self, typ, pl, seq):
        self.q += aeac_frame(typ, pl, seq)

    def rx(self, limit=256):
        out = self.q[:limit]
        del self.q[:limit]
        return out

    def close(self):
        pass


# --------------------------------------------------------------------------
# Nitrogen MCU
# --------------------------------------------------------------------------
class Mcu:
    def __init__(self, uart, is_playing):
        self.uart = uart
        self.is_playing = is_playing
        self.lock = threading.RLock()
        self.df = Deframer()
        self.seq = 0
        self.amp_state = "unknown"
        self.version = None
        self.telemetry = None
        self.telemetry_time = 0.0
        self.last_event = None

    def _dispatch(self, typ, payload):
        if typ in AMP_STATE_BY_TYPE:
            self.amp_state = AMP_STATE_BY_TYPE[typ]
        elif typ == 0x81 and len(payload) >= 2:
            self.version = "%d.%d" % (payload[0], payload[1])
        elif typ == RSP_TELEMETRY:
            self._telemetry(payload)
        elif typ in EVENT_NAMES:
            self.last_event = "%s %s" % (EVENT_NAMES[typ], payload.hex())
            extra = ""
            if typ == 0xF8 and payload[:1] == b"\x02":
                extra = " (woofer clock not present: check the 360 kHz PWM)"
            log("MCU event 0x%02X %s payload=%s%s"
                % (typ, EVENT_NAMES[typ], payload.hex() or "-", extra))

    def _telemetry(self, p):
        t = {"status": p[0] if p else None}

        def s16(off):
            return struct.unpack_from("<h", p, off)[0] if len(p) >= off + 2 else None

        t["temp_mcu"] = s16(0x0C)
        t["temp_psu"] = s16(0x0E)
        t["temp_ntc1"] = s16(0x10)
        t["temp_ntc2"] = s16(0x12)
        self.telemetry = t
        self.telemetry_time = time.monotonic()   # not wall time: the clock is set from NTP after boot

    def pump(self):
        frames = self.df.feed(self.uart.rx())
        for typ, _seq, payload in frames:
            self._dispatch(typ, payload)
        return frames

    def wait_for(self, expect, timeout):
        """Process incoming frames until one of the `expect` types shows up."""
        end = time.monotonic() + timeout
        while True:
            frames = self.pump()
            for f in frames:
                if f[0] in expect:
                    return f
            if time.monotonic() >= end:
                return None
            if not frames and self.is_playing():
                # let the playback thread have the interpreter; the 16-byte
                # RX FIFO easily covers a ~0.3 ms nap at 115200 baud
                time.sleep(0.0002)

    def command(self, cmd, payload=b"", expect=None, timeout=1.0, retries=1):
        if expect is None:
            expect = (cmd | 0x80,)
        with self.lock:
            for _ in range(retries + 1):
                self.pump()
                self.seq = (self.seq + 1) & 0xFF
                self.uart.tx(aeac_frame(cmd, payload, self.seq))
                f = self.wait_for(expect, timeout)
                if f is not None:
                    return f
        return None

    def amp(self, cmd, timeout=1.5):
        """AmpOff / AmpStandby / AmpActive.  True when the MCU acknowledged."""
        want = {CMD_AMP_OFF: "off", CMD_AMP_STANDBY: "standby",
                CMD_AMP_ACTIVE: "active"}[cmd]
        f = self.command(cmd, expect=(0xE0 + cmd, cmd | 0x80), timeout=timeout)
        if f is None:
            log("MCU: no acknowledgement for amp-%s" % want)
            self.amp_state = want + "?"
            return False
        self.amp_state = want
        return True

    def stop_telemetry(self):
        self.command(CMD_TELEMETRY, b"\x00", expect=(0xD1,), timeout=0.3, retries=0)
        time.sleep(0.05)
        with self.lock:
            self.pump()

    def sample_telemetry(self):
        """Turn the telemetry stream on just long enough to catch one frame."""
        with self.lock:
            self.uart.tx(aeac_frame(CMD_TELEMETRY, b"\x02", self._next()))
            got = self.wait_for((RSP_TELEMETRY,), 1.0)
            self.stop_telemetry()
            return got is not None

    def _next(self):
        self.seq = (self.seq + 1) & 0xFF
        return self.seq


# --------------------------------------------------------------------------
# PCM conversion: anything -> 48 kHz mono, 24-bit left-justified in 32 bits
# --------------------------------------------------------------------------
class PcmConverter:
    def __init__(self, rate=RATE, channels=1, bits=24):
        if bits not in (16, 24, 32):
            raise ValueError("unsupported sample size: %d bits" % bits)
        if not 1 <= channels <= 8:
            raise ValueError("unsupported channel count: %d" % channels)
        if not 8000 <= rate <= 192000:
            raise ValueError("unsupported sample rate: %d" % rate)
        self.rate, self.channels, self.bits = rate, channels, bits
        self.bps = bits // 8
        self.frame = self.bps * channels
        self.fast = channels == 1 and rate == RATE
        # the slow path runs a Python loop per sample: keep its blocks short so
        # a conversion never takes longer than the FIFO can cover
        self.block_frames = 480 if self.fast else 64
        self.step = rate / RATE
        self.pos = 0.0
        self.prev = 0

    def _channel(self, data, n, c):
        """One channel as little-endian left-justified 32-bit words."""
        out = bytearray(4 * n)
        bps, frame = self.bps, self.frame
        for k in range(bps):
            dst = 4 - bps + k
            if dst:               # the low byte stays 0 (only 24 bits are used)
                out[dst::4] = data[c * bps + k::frame]
        return out

    def convert(self, data):
        """data: whole frames.  Returns a sequence of unsigned 32-bit words."""
        n = len(data) // self.frame
        if self.fast:
            return memoryview(self._channel(data, n, 0)).cast("I")
        ch = [memoryview(self._channel(data, n, c)).cast("i")
              for c in range(self.channels)]
        if len(ch) == 1:
            s = ch[0]
        elif len(ch) == 2:
            s = [(a + b) >> 1 for a, b in zip(ch[0], ch[1])]
        else:
            k = len(ch)
            s = [sum(t) // k for t in zip(*ch)]
        if self.rate != RATE:
            s = self._resample(s)
        return memoryview(array.array("i", s)).cast("B").cast("I")

    def _resample(self, s):
        """Linear interpolation; position and last sample carry across calls."""
        out = []
        pos, prev, step, n = self.pos, self.prev, self.step, len(s)
        while pos < n:
            i = int(pos)
            a = s[i - 1] if i else prev
            out.append(int(a + (s[i] - a) * (pos - i)))
            pos += step
        self.pos = pos - n
        if n:
            self.prev = s[n - 1]
        return out


def nco_div_code(div):
    """Apple NCO divider coding: Galois-LFSR coarse part, 2-bit fine part."""
    fwd = [0] * 2048
    state = 0x7FF
    for i in range(2047, 0, -1):
        state = ((state >> 1) ^ (0xA01 >> 1)) if state & 1 else (state >> 1)
        fwd[i] = state
    return (fwd[div // 4 - 2] << 2) | (div % 4)


def tone_table(freq, dbfs):
    """Whole number of cycles of a sine, as signed left-justified samples."""
    n = RATE // math.gcd(RATE, int(freq))
    amp = FULL_SCALE * (10 ** (dbfs / 20.0))
    w = 2 * math.pi * freq / RATE
    return [int(amp * math.sin(w * i)) << 8 for i in range(n)]


# --------------------------------------------------------------------------
# The service
# --------------------------------------------------------------------------
class AudioService:
    def __init__(self, args):
        self.args = args
        self.dry = args.dry_run
        self.auto_init = not args.no_init
        self.vol_t = min(args.tweeter, args.max_tweeter)
        self.vol_w = args.woofer
        self.slot = args.slot
        self.initialized = False
        self.last_error = None
        self.started = time.monotonic()

        self.hw_lock = threading.RLock()     # init / shutdown / amp sequencing
        self.play_lock = threading.Lock()    # owner = whoever feeds the FIFO
        self.abort = threading.Event()
        self.source = None                   # "stream" | "test" | "test-all"
        self.stream = None
        self.pending_slot = None
        self.underruns = 0

        self.mem = None
        self.pmgr = self.gpio = self.pwm = self.uart_regs = None
        self.mca = self.mclk = self.i2s = None
        self.uart = None
        self.mcu = None

        self.pace_rate = RATE * (1.0 + args.rate_trim * 1e-6)
        self._t0 = time.perf_counter()
        self._written = 0
        self._fresh = True
        self._last = 0

    # ---------------------------------------------------------------- status
    def playing(self):
        return self.source in PLAYERS

    def status(self):
        mcu = self.mcu
        tel = mcu.telemetry if mcu else None
        st = {
            "playing": self.playing(),
            "volume_tweeter": self.vol_t,
            "volume_woofer": self.vol_w,
            "slot": self.slot,
            "amp_state": mcu.amp_state if mcu else "unknown",
            "temperature": tel.get("temp_mcu") if tel else None,
            # extras
            "initialized": self.initialized,
            "source": self.source,
            "stream": self.stream,
            "volume_tweeter_db": tweeter_db(self.vol_t),
            "volume_woofer_db": woofer_db(self.vol_w),
            "volume_tweeter_max": self.args.max_tweeter,
            "mcu_version": mcu.version if mcu else None,
            "mcu_event": mcu.last_event if mcu else None,
            "telemetry": tel,
            "telemetry_age": (round(time.monotonic() - mcu.telemetry_time, 1)
                              if tel else None),
            "underruns": self.underruns,
            "error": self.last_error,
            "uptime": int(time.monotonic() - self.started),
            "dry_run": self.dry,
        }
        return st

    # ------------------------------------------------------- player ownership
    def _acquire(self, name, preempt=False, timeout=4.0):
        if not self.play_lock.acquire(blocking=False):
            if not preempt:
                return False
            self.abort.set()
            if not self.play_lock.acquire(timeout=timeout):
                return False
        self.abort.clear()
        self.source = name
        self._fresh = True
        return True

    def _release(self):
        self.source = None
        self.stream = None
        self.play_lock.release()

    # ------------------------------------------------------------ FIFO feeder
    def _feed(self, words):
        """Write words to the MCA TX FIFO at 48 kHz.

        The FIFO level is tracked against the clock: words written minus words
        the hardware must have consumed.  Top-ups happen in bursts of up to
        BURST words whenever there is room; in between this busy-waits.
        """
        n = len(words)
        if not n:
            return
        reg = self.mca
        idx = MCA_TX_DATA // 4
        perf = time.perf_counter
        rate = self.pace_rate
        t0, written = self._t0, self._written
        i = 0
        while i < n:
            level = written - int((perf() - t0) * rate)
            if level < 0:                 # FIFO ran dry: restart the timebase
                if not self._fresh:
                    self.underruns += 1
                t0, written, level = perf(), 0, 0
            room = FIFO_HIGH - level
            left = n - i
            if room < MIN_ROOM and room < left:
                continue                  # busy-wait
            c = min(room, BURST, left)
            for w in words[i:i + c]:
                reg[idx] = w
            i += c
            written += c
            self._fresh = False
        self._t0, self._written = t0, written
        w = words[n - 1]
        self._last = w - 0x100000000 if w & 0x80000000 else w

    def _silence(self, ms):
        self._feed(array.array("I", bytes(4 * (RATE * ms // 1000))))

    def _ramp_down(self):
        """Glide from the last sample written to zero, then leave zeros."""
        last = self._last
        if last:
            n = 96
            self._feed(array.array(
                "I", [((last * (n - 1 - j)) // n) & 0xFFFFFFFF for j in range(n)]))
        self._silence(5)

    def _switch_slot(self, slot):
        """Pop-free: TX keeps running, zeros flow, only TX_MASK changes."""
        self._ramp_down()
        self._silence(15)
        self.mca[MCA_TX_MASK // 4] = 1 << slot
        self.slot = slot
        self._silence(15)

    def _service_pending(self):
        slot = self.pending_slot
        if slot is not None:
            self.pending_slot = None
            if slot != self.slot:
                self._switch_slot(slot)
                log("slot -> %d" % slot)

    def _tone(self, freq, seconds, dbfs=TEST_DBFS):
        table = tone_table(freq, dbfs)
        size = len(table)
        # steady-state blocks are plain slices of this (no per-sample work)
        loop = array.array("I", [x & 0xFFFFFFFF for x in table]) * (480 // size + 2)
        total = int(seconds * RATE)
        fade = 480                        # 10 ms in and out
        pos = 0
        while pos < total and not self.abort.is_set():
            c = min(480, total - pos)
            off = pos % size
            if pos >= fade and total - (pos + c) >= fade:
                self._feed(loop[off:off + c])
            else:
                blk = []
                for j in range(c):
                    x = table[(off + j) % size]
                    k = min(pos + j, total - pos - j)
                    blk.append((x * k // fade if k < fade else x) & 0xFFFFFFFF)
                self._feed(array.array("I", blk))
            pos += c
        self._ramp_down()

    # ------------------------------------------------------------ hardware
    def _check_platform(self):
        if self.dry or self.args.force:
            return
        try:
            with open("/proc/device-tree/compatible", "rb") as f:
                compat = f.read()
        except OSError:
            compat = b""
        if b"apple,t7000" not in compat and b"b238" not in compat:
            raise HardwareError("this does not look like a HomePod (device tree "
                                "compatible: %r); refusing to poke /dev/mem "
                                "(--force overrides)" % compat[:80])

    def _power_on(self, off, name):
        """PMGR power state: target = [3:0], actual = [7:4].

        Touching a block whose domain is off takes the whole SoC down
        (L2C SError), so a failed verify aborts the init.
        """
        v = self.pmgr
        cur = v[off // 4]
        if (cur >> 4) & 0xF != 0xF or cur & 0xF != 0xF:
            v[off // 4] = (cur & ~0xF) | 0xF
        ok = False
        for _ in range(50):
            if self.dry or (v[off // 4] >> 4) & 0xF == 0xF:
                ok = True
                break
            time.sleep(0.01)
        log("  %-9s PS=0x%08x %s" % (name, v[off // 4], "on" if ok else "FAILED"))
        if not ok:
            raise HardwareError("power domain %s did not come up" % name)

    def _fix_uart_pins(self):
        g = self.gpio
        for pin in GPIO_UART_PINS:
            v = g[pin]
            if not (v >> 1) & 7:          # MODE field still 0: set MODE=1
                g[pin] = v | 2

    def _apply_volumes(self):
        """Send both volume commands.  True when the MCU confirmed both."""
        mcu = self.mcu
        rt, rw = vol_to_reg(self.vol_t), vol_to_reg(self.vol_w)
        ok = self._write_volume(CMD_TWEETER_VOL, bytes([rt] * 7), "tweeter")
        ok = self._write_volume(CMD_WOOFER_VOL, bytes([rw]), "woofer") and ok
        log("  volumes: tweeter %d (reg 0x%02x, %s dB)  woofer %d (reg 0x%02x, %s dB)%s"
            % (self.vol_t, rt, tweeter_db(self.vol_t), self.vol_w, rw,
               woofer_db(self.vol_w), "" if ok else "  UNCONFIRMED"))
        return ok

    def _write_volume(self, cmd, want, name):
        """Write a volume register and confirm it from the MCU's read-back."""
        mcu = self.mcu
        f = mcu.command(cmd, want, timeout=0.6)
        if f is None or f[2][:len(want)] != want:
            f = mcu.command(cmd, b"", timeout=0.6)       # explicit read
        if f is None:
            log("MCU: %s volume not acknowledged" % name)
            return False
        if f[2][:len(want)] != want:
            log("MCU: %s volume reads back %s, wanted %s"
                % (name, f[2].hex() or "-", want.hex()))
            return False
        return True

    def _amp_bringup(self):
        """AmpStandby -> wait -> volumes -> AmpActive (caller holds hw_lock).

        The MCU powers up at 0 dB on every channel and volume writes only
        land in Standby/Active, so Active is refused unless the volumes were
        confirmed (--no-verify overrides).
        """
        mcu = self.mcu
        ok = mcu.amp(CMD_AMP_STANDBY)
        time.sleep(1.5)
        with mcu.lock:
            mcu.pump()                    # collect any error event from standby
        vols = self._apply_volumes()
        if not (ok and vols) and not self.args.no_verify:
            mcu.amp(CMD_AMP_OFF)
            raise HardwareError("MCU did not confirm standby/volumes; amps left "
                                "off (--no-verify overrides)")
        mcu.amp(CMD_AMP_ACTIVE)
        log("  amp state: %s" % mcu.amp_state)

    def _mca_stop(self):
        m = self.mca
        m[MCA_TX_CTRL // 4] = 0
        m[0x44 // 4] = 1
        m[MCA_CTRL // 4] = m[MCA_CTRL // 4] & ~2

    def init_hardware(self, have_play_lock=False):
        if not have_play_lock and not self._acquire("init", preempt=True):
            raise ApiError(409, "playback did not stop")
        try:
            with self.hw_lock:
                try:
                    self._init_locked()
                    self.last_error = None
                except Exception as e:
                    self.last_error = "init: %s" % e
                    self.initialized = False
                    raise
        finally:
            if not have_play_lock:
                self._release()

    def _init_locked(self):
        log("hardware init%s" % (" (dry run)" if self.dry else ""))
        self._check_platform()

        if self.initialized:
            # re-init: amps off before the MCA is touched
            self._quiesce()

        if self.mem is None:
            self.mem = FakeMem() if self.dry else DevMem()
            self.pmgr = self.mem.map(PMGR_BASE, PMGR_SIZE)
            self.gpio = self.mem.map(GPIO_BASE)

        # 1. power domains
        self._power_on(PS_SIO_P, "ps_sio_p")
        self._power_on(PS_MCA3, "ps_mca3")
        self._power_on(PS_PWM0, "ps_pwm0")

        # the blocks behind those domains are only mapped/touched from here on
        if self.pwm is None:
            self.pwm = self.mem.map(PWM_BASE)
            self.uart_regs = self.mem.map(UART8_BASE, 0x4000)
            self.mca = self.mem.map(MCA3_BASE)
            self.mclk = self.mem.map(MCLK_BASE)
            self.i2s = self.mem.map(I2S_SW_BASE)

        # 2. PWM: 360 kHz woofer clock (the MCU checks for it in standby)
        self.pwm[0x08 // 4] = 34
        self.pwm[0x0C // 4] = 33
        self.pwm[0x1C // 4] = 0x4003
        log("  PWM 360 kHz on")

        # 3. GPIO: UART8 pins MODE=1, buffer enable (active low) asserted
        self._fix_uart_pins()
        self.gpio[GPIO_BUF_EN] = self.gpio[GPIO_BUF_EN] & ~1

        # 4. UART8 (the open tty keeps the baud clock running)
        if self.uart is None:
            self.uart = FakeUart() if self.dry else Uart(self.uart_regs)
            self.mcu = Mcu(self.uart, self.playing)
            time.sleep(0.05)
        self._fix_uart_pins()
        log("  UART8 115200 8E1 open")

        # 5. MCU: telemetry off, amps off, standby, volumes, active
        mcu = self.mcu
        mcu.stop_telemetry()
        mcu.amp(CMD_AMP_OFF)
        if mcu.command(CMD_GET_VERSION) is None:
            log("  MCU: no version reply")
        else:
            log("  MCU firmware %s" % mcu.version)
        self._amp_bringup()

        # 6. NCO channel 3 -> 24.576 MHz
        p = self.pmgr
        nco = NCO3_OFF // 4
        parent, rate = NCO_PARENT_HZ, NCO_RATE_HZ
        div = (2 * parent) // rate
        inc1 = 2 * parent - div * rate
        inc2 = inc1 - rate
        accinit = (inc1 ^ 0x80000000) - rate
        p[nco] = 0
        for _ in range(100):
            if not p[nco] & (1 << 30):
                break
            time.sleep(0.001)
        # The divider register is (LFSR-coded coarse divider << 2) | fine.
        # Writing only "div & 3" left the coarse field at 0 and the MCA ran
        # at 112 kHz instead of 48 kHz (measured from the FIFO drain rate).
        p[nco + 1] = nco_div_code(div)
        p[nco + 2] = inc1 & 0xFFFFFFFF
        p[nco + 3] = inc2 & 0xFFFFFFFF
        p[nco + 4] = 0x80000000
        p[nco] = 0x80001000
        time.sleep(0.01)
        log("  NCO3 div=%d inc1=%d inc2=%d ctrl=0x%08x" % (div, inc1, inc2, p[nco]))

        # 7. MCA3: reset, MCLK off, 8 x 32-bit TDM TX master
        m = self.mca
        m[0x44 // 4] = 3
        m[0x48 // 4] = 1
        for _ in range(100):
            if not m[0x48 // 4] & 1 or self.dry:
                break
            time.sleep(0.001)
        self.mclk[0x0C // 4] = 0
        m[0x10 // 4] = 0
        m[0x1C // 4] = 0xD
        m[0x30 // 4] = 0xD
        m[0x08 // 4] = 0
        m[0x20 // 4] = 0x006C007C
        m[0x34 // 4] = 0x00030004
        m[0x14 // 4] = 0
        m[MCA_TX_MASK // 4] = 1 << self.slot
        m[0x38 // 4] = 0
        m[MCA_TX_CTRL // 4] = 0x0000010A
        m[0x2C // 4] = 0x0000020A
        m[0x10 // 4] = 1
        m[MCA_IRQ // 4] = 0xB0003000
        m[MCA_CTRL // 4] = 0x00407005

        # 8. I2S switch: AUD3 <-> PIN3, clocks out
        self.i2s[3] = 0x00030303
        self.i2s[8] = 0x000B0B0B
        self.i2s[18] = 0x11

        # 9. start TX and put some zeros in the FIFO
        m[MCA_TX_CTRL // 4] = 0x0000010B
        m[MCA_CTRL // 4] = m[MCA_CTRL // 4] | 2
        self._fresh = True
        self._silence(20)
        self.initialized = True
        if mcu.sample_telemetry():
            log("  MCU telemetry: %s" % mcu.telemetry)
        log("  MCA3 running: ctrl=0x%08x tx_ctrl=0x%08x mask=0x%02x (slot %d)"
            % (m[MCA_CTRL // 4], m[MCA_TX_CTRL // 4], m[MCA_TX_MASK // 4], self.slot))
        self._publish_amp()
        log("hardware init done")

    def _quiesce(self):
        """AmpOff FIRST, 300 ms, then stop the MCA (caller holds hw_lock)."""
        amps_off = self.mcu is None
        if self.mcu is not None:
            for attempt in (1, 2, 3):
                try:
                    self.mcu.amp(CMD_AMP_OFF, timeout=1.0)
                    amps_off = True
                    break
                except Exception as e:
                    log("amp-off failed (attempt %d): %s" % (attempt, e))
                    time.sleep(0.2)
            time.sleep(0.3)
        if self.mca is not None and self.initialized:
            if amps_off:
                self._mca_stop()
            else:
                # 2026-11-20: stopping the MCA with the amplifiers still in
                # standby (amp-off could not be sent) was followed by a hard
                # reset of the whole pod. Leave the clock running instead.
                log("WARNING: amplifiers NOT confirmed off; leaving the MCA and its clock running")
        self.initialized = False

    def _ensure_ready(self):
        """Called by a player (holding play_lock) before it makes noise."""
        with self.hw_lock:
            if not self.initialized:
                if not self.auto_init:
                    raise ApiError(409, "hardware not initialised (POST /init)")
                self.init_hardware(have_play_lock=True)
            elif not self.mcu.amp_state.startswith("active"):
                log("amps are %s: waking them up" % self.mcu.amp_state)
                self._amp_bringup()

    def shutdown(self):
        """Mute the amps, then stop the MCA.  Used on exit."""
        self.abort.set()
        got = self.play_lock.acquire(timeout=3.0)
        try:
            with self.hw_lock:
                self._quiesce()
                self._publish_amp("off")
                if self.uart is not None:
                    self.uart.close()
        finally:
            if got:
                self.play_lock.release()

    # ------------------------------------------------------------ API actions
    def _publish_amp(self, state=None):
        """Tell hpfeed what the amplifiers are doing."""
        if state is None:
            state = self.mcu.amp_state if self.mcu is not None else "off"
        try:
            os.makedirs(os.path.dirname(AMP_STATE_FILE), exist_ok=True)
            tmp = AMP_STATE_FILE + ".tmp"
            with open(tmp, "w") as f:
                f.write(state + "\n")
            os.replace(tmp, AMP_STATE_FILE)
        except OSError:
            pass

    def set_amp(self, state):
        """Move the amplifiers to standby or active.  Volumes are re-sent and
        confirmed before going active (the MCU resets them to 0 dB when off)."""
        if state not in ("standby", "active"):
            raise ApiError(400, "state must be 'standby' or 'active'")
        with self.hw_lock:
            if not self.initialized or self.mcu is None:
                raise ApiError(409, "hardware is not initialised")
            mcu = self.mcu
            if state == "standby":
                mcu.amp(CMD_AMP_STANDBY)
            else:
                if not mcu.amp_state.startswith(("standby", "active")):
                    mcu.amp(CMD_AMP_STANDBY)
                    time.sleep(1.5)
                if not self._apply_volumes() and not self.args.no_verify:
                    self._publish_amp()
                    raise ApiError(500, "MCU did not confirm the volumes; not going active")
                mcu.amp(CMD_AMP_ACTIVE)
            self._publish_amp()
            return {"amp_state": mcu.amp_state}

    def idle_manager(self, stop_event):
        """External-feeder mode: standby after --idle-standby seconds without
        audio, active again as soon as hpfeed reports audio arriving.  An
        explicit /stop (amps off) is left alone until /amp or /init."""
        idle_since = None
        while not stop_event.wait(0.1):
            if not self.initialized or self.mcu is None:
                continue
            try:
                with open(FEED_STATE_FILE) as f:
                    want = f.read().strip()
            except OSError:
                want = "idle"
            st = self.mcu.amp_state
            try:
                if want == "play":
                    idle_since = None
                    if st == "standby":
                        self.set_amp("active")
                        log("amps active (audio arriving)")
                elif st == "active":
                    now = time.monotonic()
                    if idle_since is None:
                        idle_since = now
                    elif now - idle_since >= self.args.idle_standby:
                        self.set_amp("standby")
                        log("amps standby (no audio for %d s)" % self.args.idle_standby)
                        idle_since = None
            except Exception as e:
                log("idle manager: %s" % e)
                stop_event.wait(2.0)

    def set_volume(self, tweeter=None, woofer=None):
        note = None
        if tweeter is not None:
            if tweeter > self.args.max_tweeter:
                note = ("tweeter volume capped at %d (%s dB)"
                        % (self.args.max_tweeter, tweeter_db(self.args.max_tweeter)))
                tweeter = self.args.max_tweeter
            self.vol_t = tweeter
        if woofer is not None:
            self.vol_w = woofer
        applied = False
        with self.hw_lock:
            if self.mcu is not None and self.mcu.amp_state.startswith(("standby", "active")):
                applied = self._apply_volumes()
        return {"applied": applied, "note": note}

    def set_slot(self, slot):
        got = self._acquire("slot")
        if not got and self.source not in PLAYERS:
            # init/stop in progress: wait for it rather than queueing
            got = self.play_lock.acquire(timeout=8.0)
            if got:
                self.abort.clear()
                self.source = "slot"
        if got:
            try:
                if self.initialized and slot != self.slot:
                    self._switch_slot(slot)
                self.slot = slot
            finally:
                self._release()
        else:
            self.pending_slot = slot      # the active player switches for us
        log("slot -> %d%s" % (slot, "" if self.pending_slot is None else " (queued)"))

    def stop(self):
        """Stop whatever is playing and mute (AmpOff).  TX keeps running."""
        if not self._acquire("stop", preempt=True):
            raise ApiError(409, "playback did not stop")
        try:
            with self.hw_lock:
                if self.mcu is not None:
                    self.mcu.amp(CMD_AMP_OFF)
                self._publish_amp()
            log("stopped and muted")
        finally:
            self._release()

    def start_test(self, slot=None, all_speakers=False):
        name = "test-all" if all_speakers else "test"
        if not self._acquire(name):
            raise ApiError(409, "busy: %s is playing" % (self.source or "something"))
        threading.Thread(target=self._run_test, args=(slot, all_speakers),
                         name=name, daemon=True).start()

    def _run_test(self, slot, all_speakers):
        try:
            self._ensure_ready()
            home = self.slot
            if all_speakers:
                log("test-all: 8 speakers, 1 s each")
                for s in range(SLOTS):
                    if self.abort.is_set():
                        break
                    self._switch_slot(s)
                    self._tone(150 if s == 0 else 600 + 100 * s, 1.0)
                    self._silence(150)
            else:
                if slot is not None and slot != self.slot:
                    self._switch_slot(slot)
                log("test tone: 440 Hz, 3 s, slot %d" % self.slot)
                self._tone(440, 3.0)
            if self.slot != home and self.pending_slot is None:
                self._switch_slot(home)
            self._service_pending()
        except Exception as e:
            self.last_error = "test: %s" % e
            log("test failed: %s" % e)
        finally:
            self._release()

    # ------------------------------------------------------------ PCM stream
    def handle_stream(self, conn, addr):
        peer = "%s:%d" % addr[:2]
        if not self._acquire("stream", preempt=True, timeout=10.0):
            log("stream %s: rejected, previous player did not stop" % peer)
            conn.close()
            return
        nbytes = 0
        t_start = time.time()
        try:
            self._ensure_ready()
            buf = bytearray()
            # optional header
            eof = False
            deadline = time.monotonic() + 5.0
            while (len(buf) < 16 and not eof and not self.abort.is_set()
                   and time.monotonic() < deadline):
                if len(buf) >= 4 and buf[:4] != b"HPOD":
                    break
                eof = not _recv_some(conn, buf, 65536, 0.25)
            if buf[:4] == b"HPOD" and len(buf) >= 16:
                rate, ch, bits = struct.unpack_from("<IBB", buf, 4)
                del buf[:16]
            else:
                rate, ch, bits = RATE, 1, 24
            conv = PcmConverter(rate, ch, bits)
            self.stream = {"client": peer, "rate": rate, "channels": ch,
                           "bits": bits, "bytes": 0, "seconds": 0.0,
                           "buffering": True, "rebuffers": 0,
                           "started": int(t_start)}
            log("stream %s: %d Hz, %d-bit, %d ch%s"
                % (peer, rate, bits, ch, "" if conv.fast else " (software converted)"))
            frame = conv.frame
            block = conv.block_frames * frame
            per_sec = frame * rate
            pre = max(frame, per_sec * self.args.prebuffer_ms // 1000 // frame * frame)
            cap = max(per_sec // 2, 2 * pre)
            # A small software buffer sits in front of the 2.7 ms hardware
            # FIFO: playback starts once `pre` bytes are queued and drops back
            # to buffering when the queue runs dry.  Reading stops at `cap`,
            # which is what throttles a sender that is faster than real time.
            buffering = True
            t_buf = time.monotonic()
            while not self.abort.is_set():
                self._service_pending()
                if not eof:
                    eof = not _recv_some(conn, buf, cap, 0.25 if buffering else 0)
                if buffering:
                    if (len(buf) >= pre or (len(buf) >= frame and
                                            (eof or time.monotonic() - t_buf > 1.0))):
                        buffering = False
                        self.stream["buffering"] = False
                    elif eof:
                        break
                    else:
                        continue
                if len(buf) < frame:
                    if eof:
                        break
                    self._ramp_down()
                    buffering = True
                    t_buf = time.monotonic()
                    self.stream["buffering"] = True
                    self.stream["rebuffers"] += 1
                    self._fresh = True    # a deliberate gap, not a FIFO underrun
                    continue
                take = min(len(buf) // frame * frame, block)
                chunk = bytes(buf[:take])
                del buf[:take]
                self._feed(conv.convert(chunk))
                nbytes += take
                self.stream["bytes"] = nbytes
                self.stream["seconds"] = round(nbytes / per_sec, 1)
        except (OSError, ValueError, ApiError, HardwareError) as e:
            self.last_error = "stream: %s" % e
            log("stream %s: %s" % (peer, e))
        finally:
            try:
                if self.initialized:
                    self._ramp_down()
                    self._service_pending()
                    m = self.mca
                    log("stream %s: closed, %d bytes in %.1f s, underruns=%d, "
                        "tx_stat=0x%08x irq=0x%08x"
                        % (peer, nbytes, time.time() - t_start, self.underruns,
                           m[MCA_TX_STAT // 4], m[MCA_IRQ // 4]))
            finally:
                self._release()
                try:
                    conn.close()
                except OSError:
                    pass

    # ------------------------------------------------------------ housekeeping
    def housekeeping(self, stop_event):
        """Refresh MCU telemetry (temperature) while nothing is playing."""
        while not stop_event.wait(10.0):
            if not self.initialized or self.playing():
                continue
            if not self.hw_lock.acquire(blocking=False):
                continue
            try:
                if self.mcu is not None and not self.playing():
                    self.mcu.sample_telemetry()
            except Exception as e:
                log("telemetry: %s" % e)
            finally:
                self.hw_lock.release()


# --------------------------------------------------------------------------
# Servers
# --------------------------------------------------------------------------
def _recv_some(conn, buf, cap, timeout):
    """Append whatever the socket has (up to `cap` buffered).  False on EOF."""
    if len(buf) >= cap:
        if timeout:
            time.sleep(0.01)
        return True
    readable, _, _ = select.select([conn], [], [], timeout)
    if not readable:
        return True
    d = conn.recv(min(65536, cap - len(buf)))
    if not d:
        return False
    buf += d
    return True


def pcm_server(svc, sock):
    while True:
        try:
            conn, addr = sock.accept()
        except OSError:
            return
        try:
            conn.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        except OSError:
            pass
        threading.Thread(target=svc.handle_stream, args=(conn, addr),
                         name="stream", daemon=True).start()


def _int_field(body, key, lo, hi, required=False):
    v = body.get(key)
    if v is None:
        if required:
            raise ApiError(400, "missing '%s'" % key)
        return None
    if isinstance(v, bool) or not isinstance(v, (int, float, str)):
        raise ApiError(400, "'%s' must be a number" % key)
    try:
        v = int(v)
    except ValueError:
        raise ApiError(400, "'%s' must be a number" % key)
    if not lo <= v <= hi:
        raise ApiError(400, "'%s' must be %d-%d" % (key, lo, hi))
    return v


def make_handler(svc):
    class Handler(BaseHTTPRequestHandler):
        server_version = "homepod-audio/1.0"

        def log_message(self, fmt, *a):
            if self.command != "GET":
                log("http %s %s" % (self.client_address[0], fmt % a))

        def _send(self, status, obj):
            data = (json.dumps(obj) + "\n").encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def _route(self, method):
            url = urlsplit(self.path)
            soft = parse_qs(url.query).get("cgi") == ["1"]
            path = url.path.rstrip("/") or "/"
            try:
                body = {}
                if method == "POST":
                    n = int(self.headers.get("Content-Length") or 0)
                    raw = self.rfile.read(n) if 0 < n <= 65536 else b""
                    if raw.strip():
                        try:
                            body = json.loads(raw)
                        except ValueError:
                            raise ApiError(400, "body is not valid JSON")
                        if not isinstance(body, dict):
                            raise ApiError(400, "body must be a JSON object")
                result = self._dispatch(method, path, body)
                self._send(200, result)
            except ApiError as e:
                self._send(200 if soft else e.status, {"ok": False, "error": str(e)})
            except HardwareError as e:
                self._send(200 if soft else 500, {"ok": False, "error": str(e)})
            except Exception as e:  # keep the daemon alive whatever happens
                log("http error: %r" % e)
                self._send(200 if soft else 500, {"ok": False, "error": repr(e)})

        def _dispatch(self, method, path, body):
            if method == "GET":
                if path == "/status":
                    return svc.status()
                if path == "/":
                    return {"service": "homepod-audio", "pcm_port": svc.args.port,
                            "endpoints": ["GET /status", "POST /volume", "POST /slot",
                                          "POST /test", "POST /test-all",
                                          "POST /stop", "POST /init"]}
                raise ApiError(404, "not found")
            if path == "/volume":
                t = _int_field(body, "tweeter", 0, 255)
                w = _int_field(body, "woofer", 0, 255)
                if t is None and w is None:
                    raise ApiError(400, "need 'tweeter' and/or 'woofer'")
                r = svc.set_volume(t, w)
            elif path in ("/slot", "/test", "/test-all") and svc.args.external_feeder:
                raise ApiError(409, "hpfeed owns the audio FIFO; this call is disabled")
            elif path == "/slot":
                svc.set_slot(_int_field(body, "slot", 0, SLOTS - 1, required=True))
                r = {}
            elif path == "/test":
                svc.start_test(slot=_int_field(body, "slot", 0, SLOTS - 1))
                r = {"started": "test"}
            elif path == "/test-all":
                svc.start_test(all_speakers=True)
                r = {"started": "test-all"}
            elif path == "/stop":
                svc.stop()
                r = {}
            elif path == "/amp":
                st = body.get("state") if isinstance(body, dict) else None
                r = svc.set_amp(st)
            elif path == "/init":
                svc.init_hardware()
                r = {}
            else:
                raise ApiError(404, "not found")
            out = {"ok": True}
            out.update(r)
            out["status"] = svc.status()
            return out

        def do_GET(self):
            self._route("GET")

        def do_POST(self):
            self._route("POST")

    return Handler


class ReuseHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    ap = argparse.ArgumentParser(description="HomePod audio service daemon")
    ap.add_argument("--bind", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=7002, help="PCM TCP port")
    ap.add_argument("--http-port", type=int, default=7001, help="control API port")
    ap.add_argument("--slot", type=int, default=1, choices=range(SLOTS),
                    help="initial TDM slot (0 = woofer, 1-7 = tweeters)")
    ap.add_argument("--tweeter", type=int, default=DEFAULT_TWEETER,
                    help="initial tweeter volume 0-255 (higher = louder)")
    ap.add_argument("--woofer", type=int, default=DEFAULT_WOOFER,
                    help="initial woofer volume 0-255 (higher = louder)")
    ap.add_argument("--max-tweeter", type=int, default=191,
                    help="tweeter volume ceiling (191 = 0 dB, 255 = +24 dB)")
    ap.add_argument("--rate-trim", type=float, default=0.0,
                    help="pacing correction in ppm if the NCO runs fast/slow")
    ap.add_argument("--prebuffer-ms", type=int, default=150,
                    help="audio queued before a stream starts playing")
    ap.add_argument("--external-feeder", action="store_true",
                    help="another process (hpfeed) owns the MCA FIFO: no PCM port, "
                         "no test tones, no slot switching from this daemon")
    ap.add_argument("--idle-standby", type=int, default=60,
                    help="external-feeder mode: seconds without audio before the "
                         "amplifiers go to standby (0 = never)")
    ap.add_argument("--no-init", action="store_true",
                    help="do not touch hardware until POST /init")
    ap.add_argument("--no-verify", action="store_true",
                    help="go to AmpActive even if the MCU did not confirm volumes")
    ap.add_argument("--force", action="store_true",
                    help="skip the is-this-a-HomePod check")
    ap.add_argument("--dry-run", action="store_true",
                    help="fake registers and a simulated MCU; no /dev/mem")
    args = ap.parse_args()
    for name in ("tweeter", "woofer", "max_tweeter"):
        if not 0 <= getattr(args, name) <= 255:
            ap.error("--%s must be 0-255" % name.replace("_", "-"))

    # the playback thread busy-waits; hand the interpreter over quickly
    sys.setswitchinterval(0.0005)
    try:
        os.nice(-10)                      # be ahead of httpd/CGI work
    except OSError:
        pass

    svc = AudioService(args)
    stop_event = threading.Event()

    def on_signal(signum, _frame):
        log("signal %d: shutting down" % signum)
        stop_event.set()

    signal.signal(signal.SIGTERM, on_signal)
    signal.signal(signal.SIGINT, on_signal)
    signal.signal(signal.SIGHUP, on_signal)      # never die with the amps on

    pcm = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    pcm.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    pcm.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 32768)
    if not args.external_feeder:
        pcm.bind((args.bind, args.port))
        pcm.listen(4)
    httpd = ReuseHTTPServer((args.bind, args.http_port), make_handler(svc))

    threading.Thread(target=httpd.serve_forever, name="http", daemon=True).start()
    if not args.external_feeder:
        threading.Thread(target=pcm_server, args=(svc, pcm), name="pcm", daemon=True).start()
    threading.Thread(target=svc.housekeeping, args=(stop_event,), name="housekeeping",
                     daemon=True).start()
    if args.external_feeder and args.idle_standby > 0:
        threading.Thread(target=svc.idle_manager, args=(stop_event,), name="idle",
                         daemon=True).start()
    log("homepod-audio up: PCM %s, control http/%d, pid %d"
        % ("off (external feeder)" if args.external_feeder else "tcp/%d" % args.port,
           args.http_port, os.getpid()))

    exit_code = 0
    try:
        if svc.auto_init and not stop_event.is_set():
            try:
                svc.init_hardware()
            except Exception as e:
                log("hardware init FAILED: %s" % e)
                log("still serving; fix the cause and POST /init")
        while not stop_event.wait(1.0):
            pass
    except BaseException as e:
        log("fatal: %r" % e)
        exit_code = 1
    finally:
        # amps are muted before anything else is torn down
        try:
            had_hw = svc.mcu is not None
            svc.shutdown()
            log("amps off, MCA stopped" if had_hw else "hardware was never touched")
        except Exception as e:
            log("shutdown error: %r" % e)
        try:
            pcm.close()
        except OSError:
            pass
    log("bye")
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
