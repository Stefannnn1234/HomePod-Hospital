#!/usr/bin/env python3
"""
telemetry_monitor.py - Continuous telemetry monitoring during audio testing.

Run this in a separate shell while running test_tone.py or other audio tests.
It continuously reads temperature and telemetry from the Nitrogen MCU and
will trigger an emergency stop if thresholds are exceeded.

Safety thresholds:
  Temperature: > 70C = warning, > 85C = emergency stop
  Fault bits: any fault = emergency stop
"""

import os
import sys
import time
import signal
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nitrogen import get_mcu

# Safety thresholds
TEMP_WARN_C = 70
TEMP_STOP_C = 85

# Global for signal handler
_mcu_global = None


def parse_temp(response):
    """Try to parse temperature from MCU response.

    Response format is likely <TEMP,value> or similar.
    Returns temperature in Celsius or None.
    """
    if not response:
        return None
    try:
        # Strip angle brackets and split
        clean = response.strip('<>').strip()
        parts = clean.split(',')
        if len(parts) >= 2:
            # Try to parse the numeric value
            val_str = parts[-1].strip()
            # Could be integer (raw ADC) or float (Celsius)
            val = float(val_str)
            # If it's a raw ADC value (e.g., 0-4095), we can't convert
            # without knowing the sensor characteristics
            if val > 200:
                print(f"    (Raw ADC value: {val} - conversion unknown)")
                return None
            return val
    except (ValueError, IndexError):
        pass
    return None


def emergency_stop(mcu, reason=""):
    """Emergency shutdown."""
    print(f"\n{'!' * 60}")
    print(f"  EMERGENCY STOP: {reason}")
    print(f"{'!' * 60}")
    mcu.command("[AMP,X]")
    mcu.command("[WFR,N]")
    print("  All amplifiers shut down.")
    sys.exit(1)


def _sigint_handler(signum, frame):
    print("\n\nInterrupted - shutting down monitoring.")
    sys.exit(0)


def monitor(mcu, interval=2.0, telem_level=1, auto_stop=True):
    """Continuous monitoring loop.

    interval: seconds between readings
    telem_level: telemetry detail level (0-5)
    auto_stop: automatically stop on fault/over-temp
    """
    print(f"\n{'=' * 60}")
    print(f"  TELEMETRY MONITOR")
    print(f"  Interval: {interval}s | Telem level: {telem_level}")
    print(f"  Auto-stop: {'ON' if auto_stop else 'OFF'}")
    print(f"  Temp warning: {TEMP_WARN_C}C | Temp stop: {TEMP_STOP_C}C")
    print(f"  Press Ctrl+C to stop monitoring")
    print(f"{'=' * 60}\n")

    reading_num = 0
    while True:
        reading_num += 1
        timestamp = time.strftime("%H:%M:%S")

        print(f"\n--- Reading #{reading_num} @ {timestamp} ---")

        # Temperature
        temp_resp = mcu.command("[TEMP]")
        temp_c = parse_temp(temp_resp)
        if temp_c is not None:
            if temp_c > TEMP_STOP_C and auto_stop:
                emergency_stop(mcu, f"Temperature {temp_c}C > {TEMP_STOP_C}C limit!")
            elif temp_c > TEMP_WARN_C:
                print(f"  *** WARNING: Temperature {temp_c}C > {TEMP_WARN_C}C! ***")

        # Telemetry
        if telem_level > 0:
            mcu.command(f"[TELEM,{telem_level}]", timeout_s=3.0)

        # Check faults on all tweeters
        fault_found = False
        for i in range(1, 8):
            resp = mcu.command(f"[TRI,{i},6]")  # Register 6 = fault status
            if resp and '<' in resp:
                try:
                    parts = resp.strip('<>').split(',')
                    if len(parts) >= 2:
                        val = int(parts[-1].strip(), 0)
                        if val != 0:
                            print(f"  *** FAULT on tweeter {i}: 0x{val:02x} ***")
                            fault_found = True
                except (ValueError, IndexError):
                    pass

        if fault_found and auto_stop:
            emergency_stop(mcu, "Amplifier fault detected!")

        time.sleep(interval)


def main():
    parser = argparse.ArgumentParser(description='Audio telemetry monitor')
    parser.add_argument('--interval', '-i', type=float, default=2.0,
                        help='Reading interval in seconds (default 2)')
    parser.add_argument('--level', '-l', type=int, default=1,
                        choices=[0, 1, 2, 3, 4, 5],
                        help='Telemetry level (default 1)')
    parser.add_argument('--no-auto-stop', action='store_true',
                        help='Disable automatic emergency stop')
    parser.add_argument('--port', '-p', help='Serial port path')
    parser.add_argument('--method', '-m', default='auto',
                        choices=['auto', 'serial', 'mmio'])
    args = parser.parse_args()

    signal.signal(signal.SIGINT, _sigint_handler)

    mcu = get_mcu(method=args.method, port=args.port)
    if mcu is None:
        print("ERROR: Could not establish MCU communication")
        sys.exit(1)

    _mcu_global = mcu

    # Initial status
    print("Initial MCU check:")
    mcu.command("[SV]")
    mcu.command("[TEMP]")

    # Start monitoring
    monitor(mcu, interval=args.interval, telem_level=args.level,
            auto_stop=not args.no_auto_stop)


if __name__ == '__main__':
    main()
