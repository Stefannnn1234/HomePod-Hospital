/*
 * hpdsp.h - speaker processing for the HomePod (1st gen), modelled on the
 * static, linear part of Apple's own speaker graph (b238a_speaker.dspg):
 *
 *   mono in -> loudness (volume dependent bass/treble lift)
 *           -> systemEQ (15 bands, -6 dB)
 *           +-> woofer:   LR4 low-pass 400 Hz, woofer EQ, subsonic high-pass
 *           +-> tweeters: LR4 high-pass 400 Hz, omni-beam FIR, array EQ, delay
 *
 * Not modelled (yet): the beamformer's directional beams (all seven tweeters
 * get the omni beam), the multiband compressor (systemDRC), BassKoenig's
 * excursion-limited bass extension, the per-driver limiters, PeakPowerGuard
 * and the room-dependent lfEQ. Levels are therefore kept conservative by
 * the caller.
 *
 * 48 kHz only. Everything is double precision; cost is about 25 biquads and
 * a 128-tap FIR per sample.
 */
#ifndef HPDSP_H
#define HPDSP_H

#include <math.h>
#include <string.h>
#include "apple_b238a.h"

#define DSP_FS 48000.0
#define DSP_MAXDELAY 2048

struct dbq { double b0, b1, b2, a1, a2, z1, z2; };

static inline double dbq_run(struct dbq *q, double x)
{
	double y = q->b0 * x + q->z1;

	q->z1 = q->b1 * x - q->a1 * y + q->z2;
	q->z2 = q->b2 * x - q->a2 * y;
	return y;
}

static void dbq_coef(struct dbq *q, double b0, double b1, double b2, double a0, double a1, double a2)
{
	q->b0 = b0 / a0; q->b1 = b1 / a0; q->b2 = b2 / a0;
	q->a1 = a1 / a0; q->a2 = a2 / a0;
}

static void dbq_raw(struct dbq *q, const double *c)   /* b0 b1 b2 a1 a2 */
{
	q->b0 = c[0]; q->b1 = c[1]; q->b2 = c[2]; q->a1 = c[3]; q->a2 = c[4];
}

/* One AUNBandEQ band -> biquad (RBJ forms; bandwidth is in octaves). */
static void dbq_nbeq(struct dbq *q, const struct nbeq_band *b)
{
	double A = pow(10.0, b->gain / 40.0), w0 = 2.0 * M_PI * b->freq / DSP_FS;
	double cs = cos(w0), sn = sin(w0), alpha, bwq, sq;

	bwq = sn * sinh(M_LN2 / 2.0 * b->bw * w0 / sn);     /* alpha from an octave bandwidth */
	switch (b->type) {
	case 1:                                             /* 2nd order Butterworth low-pass */
		alpha = sn / (2.0 * M_SQRT1_2);
		dbq_coef(q, (1 - cs) / 2, 1 - cs, (1 - cs) / 2, 1 + alpha, -2 * cs, 1 - alpha);
		break;
	case 2:                                             /* 2nd order Butterworth high-pass */
		alpha = sn / (2.0 * M_SQRT1_2);
		dbq_coef(q, (1 + cs) / 2, -(1 + cs), (1 + cs) / 2, 1 + alpha, -2 * cs, 1 - alpha);
		break;
	case 7: case 9:                                     /* low shelf (9: resonant, uses the bandwidth) */
		alpha = b->type == 9 ? bwq : sn / 2.0 * M_SQRT2;
		sq = 2.0 * sqrt(A) * alpha;
		dbq_coef(q, A * ((A + 1) - (A - 1) * cs + sq), 2 * A * ((A - 1) - (A + 1) * cs),
			 A * ((A + 1) - (A - 1) * cs - sq),
			 (A + 1) + (A - 1) * cs + sq, -2 * ((A - 1) + (A + 1) * cs), (A + 1) + (A - 1) * cs - sq);
		break;
	case 8: case 10:                                    /* high shelf */
		alpha = b->type == 10 ? bwq : sn / 2.0 * M_SQRT2;
		sq = 2.0 * sqrt(A) * alpha;
		dbq_coef(q, A * ((A + 1) + (A - 1) * cs + sq), -2 * A * ((A - 1) + (A + 1) * cs),
			 A * ((A + 1) + (A - 1) * cs - sq),
			 (A + 1) - (A - 1) * cs + sq, 2 * ((A - 1) - (A + 1) * cs), (A + 1) - (A - 1) * cs - sq);
		break;
	default:                                            /* parametric (peak/dip) */
		alpha = bwq;
		dbq_coef(q, 1 + alpha * A, -2 * cs, 1 - alpha * A, 1 + alpha / A, -2 * cs, 1 - alpha / A);
		break;
	}
}

#define NSYS  (int)(sizeof(apple_syseq_free) / sizeof(apple_syseq_free[0]))
#define NWEQ  (int)(sizeof(apple_woofer_eq) / sizeof(apple_woofer_eq[0]))
#define NAEQ  (int)(sizeof(apple_array_eq) / sizeof(apple_array_eq[0]))
#define NLOUD (int)(sizeof(apple_loud_anchor) / sizeof(apple_loud_anchor[0]))

struct hpdsp {
	/* settings (see dsp_configure) */
	int position;                 /* 0 free, 1 wall, 2 book(shelf) */
	int loud_idx;                 /* index into the loudness anchors, -1 = off */
	double subsonic_hz;
	double g_pre, g_woofer, g_tweeter;
	int tw_delay;                 /* extra tweeter delay, samples */
	/* state */
	struct dbq loud_b, loud_t, sys[16], wf[12], hpf[2], tw_hp[2], aeq[4];
	int nwf;
	double fir[APPLE_BEAM_TAPS * 2];
	int fir_pos;
	double dly[DSP_MAXDELAY];
	int dly_pos;
};

static void dsp_clear(struct hpdsp *d)
{
	int i;

	d->loud_b.z1 = d->loud_b.z2 = d->loud_t.z1 = d->loud_t.z2 = 0;
	for (i = 0; i < 16; i++) d->sys[i].z1 = d->sys[i].z2 = 0;
	for (i = 0; i < 12; i++) d->wf[i].z1 = d->wf[i].z2 = 0;
	for (i = 0; i < 2; i++) d->hpf[i].z1 = d->hpf[i].z2 = d->tw_hp[i].z1 = d->tw_hp[i].z2 = 0;
	for (i = 0; i < 4; i++) d->aeq[i].z1 = d->aeq[i].z2 = 0;
	memset(d->fir, 0, sizeof(d->fir));
	memset(d->dly, 0, sizeof(d->dly));
}

/*
 * position: 0 free standing, 1 against a wall, 2 on a bookshelf
 * loud_db:  playback level relative to the reference level, picks the
 *           loudness curve (-27..+9, nearest 3 dB step); > 100 = off
 */
static void dsp_configure(struct hpdsp *d, int position, double loud_db, double subsonic_hz,
			  double woofer_db, double tweeter_db, int tw_delay)
{
	const struct nbeq_band *sys = position == 1 ? apple_syseq_wall :
				      position == 2 ? apple_syseq_book : apple_syseq_free;
	double sysgain = position == 1 ? APPLE_SYSEQ_WALL_GAIN :
			 position == 2 ? APPLE_SYSEQ_BOOK_GAIN : APPLE_SYSEQ_FREE_GAIN;
	struct nbeq_band hp = { 2, subsonic_hz, 0, 0 };
	int i, n = 0, best = -1;

	d->position = position;
	for (i = 0; i < NSYS; i++)
		dbq_nbeq(&d->sys[i], &sys[i]);
	for (i = 0; i < NWEQ; i++)                   /* includes the two 400 Hz low-pass sections */
		dbq_nbeq(&d->wf[n++], &apple_woofer_eq[i]);
	d->nwf = n;
	d->subsonic_hz = subsonic_hz;
	dbq_nbeq(&d->hpf[0], &hp);
	dbq_nbeq(&d->hpf[1], &hp);
	dbq_nbeq(&d->tw_hp[0], &apple_array_xover[0]);
	dbq_nbeq(&d->tw_hp[1], &apple_array_xover[1]);
	for (i = 0; i < NAEQ; i++)
		dbq_raw(&d->aeq[i], apple_array_eq[i]);
	if (loud_db <= 100.0) {
		double err = 1e9;
		for (i = 0; i < NLOUD; i++)
			if (fabs(apple_loud_anchor[i] - loud_db) < err) {
				err = fabs(apple_loud_anchor[i] - loud_db);
				best = i;
			}
	}
	d->loud_idx = best;
	if (best >= 0) {
		dbq_raw(&d->loud_b, apple_loud_bass[best]);
		dbq_raw(&d->loud_t, apple_loud_treble[best]);
	}
	d->g_pre = pow(10.0, sysgain / 20.0);
	d->g_woofer = pow(10.0, woofer_db / 20.0);
	d->g_tweeter = pow(10.0, tweeter_db / 20.0);
	d->tw_delay = tw_delay < 0 ? 0 : tw_delay >= DSP_MAXDELAY ? DSP_MAXDELAY - 1 : tw_delay;
}

/* one mono sample in, woofer and tweeter samples out */
static inline void dsp_run(struct hpdsp *d, double x, double *woofer, double *tweeter)
{
	double lo, hi, acc;
	int i, p;

	if (d->loud_idx >= 0)
		x = dbq_run(&d->loud_t, dbq_run(&d->loud_b, x));
	for (i = 0; i < NSYS; i++)
		x = dbq_run(&d->sys[i], x);
	x *= d->g_pre;

	lo = x;
	for (i = 0; i < d->nwf; i++)
		lo = dbq_run(&d->wf[i], lo);
	lo = dbq_run(&d->hpf[1], dbq_run(&d->hpf[0], lo));
	*woofer = lo * d->g_woofer;

	hi = dbq_run(&d->tw_hp[1], dbq_run(&d->tw_hp[0], x));
	/* omni beam FIR (first APPLE_BEAM_TAPS taps of Apple's 2048; it is minimum phase) */
	p = d->fir_pos = (d->fir_pos + APPLE_BEAM_TAPS - 1) % APPLE_BEAM_TAPS;
	d->fir[p] = d->fir[p + APPLE_BEAM_TAPS] = hi;
	acc = 0.0;
	for (i = 0; i < APPLE_BEAM_TAPS; i++)
		acc += apple_beam0[i] * d->fir[p + i];
	hi = acc;
	for (i = 0; i < NAEQ; i++)
		hi = dbq_run(&d->aeq[i], hi);
	if (d->tw_delay) {
		d->dly[d->dly_pos] = hi;
		hi = d->dly[(d->dly_pos + DSP_MAXDELAY - d->tw_delay) % DSP_MAXDELAY];
		d->dly_pos = (d->dly_pos + 1) % DSP_MAXDELAY;
	}
	*tweeter = hi * d->g_tweeter;
}

#endif
