/* hpmix -- the room's audio for AirPlay speakers that are not Nicotine HomePods.
 *
 * homepod-roomsend runs one of these. It is handed every block of the room's 8-channel audio together with the
 * moment the block is due (the room leader's CLOCK_MONOTONIC_RAW, as the relay stamps it), and is asked, packet by
 * packet, for the stereo samples a destination has to play at a given moment on the same clock. So the question
 * "which sample belongs to which instant" is answered here and nowhere else:
 *
 *   - blocks give noisy (arrival-time) stamps; the stamp of sample i is smoothed to  a + i / 48000
 *   - each destination has a read position that moves on continuously; a slow loop steers its speed so that the
 *     position stays on (t - a) * 48000. Speed changes are limited to 0.3 %, so there is never a step in the
 *     sound, and a difference between the sender's and the leader's clock (tens of ppm) is followed for ever.
 *
 * Commands on stdin (little endian), answers on stdout:
 *   'B' u64 due_ns, u32 bytes, data     a block: 8 channels, 16 bit, 48 kHz           (no answer)
 *   'G' u8 dest, 16 x f32               gains: left from the 8 channels, then right    (no answer)
 *   'g' u8 dest, u8 class, 16 x f32     the same for blocks of one class only: 1 a stereo stream (sound in FL and
 *                                       FR only), 2 surround without heights. 'G' sets all classes.   (no answer)
 *   'C' u8 class                        the class of the blocks that follow (0 full bed)   (no answer)
 *   'L' u8 dest, u8 class, f32 hz       low-pass both outputs of that class at hz (4th-order Linkwitz-Riley;
 *                                       0 = none): the fake LFE of a subwoofer with stereo music  (no answer)
 *   'T' u8 dest, i32 trim_us            this destination plays that much later (+) or earlier (-)   (no answer)
 *   'O' u32 rate                        output sample rate, default 44100               (no answer)
 *   'R' u8 dest, i64 t_ns, u16 frames   -> frames x 2 x 16 bit BIG endian (what RAOP wants), silence where there
 *                                          is no audio for that time
 *   'S'                                 -> one text line of counters
 * Build: aarch64-linux-gnu-gcc -O2 -static -Wall -Wextra -o hpmix hpmix.c -lm
 */
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define IN_RATE 48000.0
#define NCH 8
#define MAXDEST 8
#define RING (1u << 19)              /* frames kept per destination: 10.9 s */
#define TAPS 32
#define PHASES 256
#define JUMP_FRAMES 2400.0           /* 50 ms off: do not chase, jump */
#define MAX_ADJ 0.003
#define LOOP_TAU 1.0                 /* seconds */


/* 4th-order Linkwitz-Riley low-pass (two 2nd-order Butterworth sections), for the fake LFE */
struct lr4 { float b0, b1, b2, a1, a2; float z[2][2]; float hz; };
static void lr4_set(struct lr4 *f, float hz, float fs)
{
    double w = 2.0 * M_PI * hz / fs, c = cos(w), al = sin(w) / (2.0 * 0.7071067811865476), a0 = 1.0 + al;
    f->b0 = (float)((1.0 - c) / 2.0 / a0); f->b1 = (float)((1.0 - c) / a0); f->b2 = f->b0;
    f->a1 = (float)(-2.0 * c / a0); f->a2 = (float)((1.0 - al) / a0);
    memset(f->z, 0, sizeof(f->z)); f->hz = hz;
}
static inline float lr4_run(struct lr4 *f, float x)
{
    int k;

    for (k = 0; k < 2; k++) {               /* transposed direct form II, twice */
        float y = f->b0 * x + f->z[k][0];
        f->z[k][0] = f->b1 * x - f->a1 * y + f->z[k][1];
        f->z[k][1] = f->b2 * x - f->a2 * y;
        x = y;
    }
    return x;
}

typedef struct {
    int used, anchored;
    struct lr4 lp[3][2];             /* per class, left and right; hz 0 = not used */
    float gl[3][NCH], gr[3][NCH];    /* per class of stream: 0 full bed, 1 stereo, 2 surround without heights */
    float *ring;                     /* RING x 2 floats, premixed */
    double pos;                      /* absolute input frame index, fractional */
    double trim_ns;
    unsigned epoch;
    unsigned long jumps, silent, frames;
    double err_last;
} dest_t;

static dest_t g_dest[MAXDEST];
static double g_out_rate = 44100.0;
static uint64_t g_wi;                /* absolute index of the next input frame */
static int64_t g_base_ns;            /* times are kept relative to this, as doubles */
static double g_a;                   /* smoothed: time of input frame 0, ns relative to g_base_ns */
static unsigned g_nblk_since, g_epoch, g_cls;
static int64_t g_last_due;
static float g_kernel[PHASES + 1][TAPS];
static double g_kernel_ratio;

static void read_all(void *p, size_t n)
{
    unsigned char *b = p;
    while (n) {
        ssize_t r = read(0, b, n);
        if (r <= 0)
            exit(0);
        b += r; n -= (size_t)r;
    }
}

static void write_all(const void *p, size_t n)
{
    const unsigned char *b = p;
    while (n) {
        ssize_t r = write(1, b, n);
        if (r <= 0)
            exit(0);
        b += r; n -= (size_t)r;
    }
}

static double bessel_i0(double x)
{
    double s = 1, t = 1;
    for (int k = 1; k < 40; k++) {
        t *= (x / (2 * k)) * (x / (2 * k));
        s += t;
    }
    return s;
}

static void make_kernel(void)
{
    /* windowed sinc; the cutoff sits below the lower of the two Nyquist frequencies */
    double ratio = g_out_rate / IN_RATE, fc = (ratio < 1 ? ratio : 1) * 0.93, beta = 8.0;
    for (int p = 0; p <= PHASES; p++) {
        double frac = (double)p / PHASES, sum = 0;
        for (int k = 0; k < TAPS; k++) {
            double x = (k - (TAPS / 2 - 1)) - frac;          /* distance from the wanted point, in input frames */
            double w = 1 - (x / (TAPS / 2)) * (x / (TAPS / 2));
            double win = w > 0 ? bessel_i0(beta * sqrt(w)) / bessel_i0(beta) : 0;
            double s = fabs(x) < 1e-9 ? fc : sin(M_PI * fc * x) / (M_PI * x);
            g_kernel[p][k] = (float)(s * win);
            sum += s * win;
        }
        for (int k = 0; k < TAPS; k++)
            g_kernel[p][k] = (float)(g_kernel[p][k] / sum);
    }
    g_kernel_ratio = ratio;
}

static void cmd_block(void)
{
    static int16_t buf[65536 / 2];
    uint64_t due; uint32_t n;
    read_all(&due, 8); read_all(&n, 4);
    if (n > sizeof buf || n % (NCH * 2)) {
        fprintf(stderr, "hpmix: bad block of %u bytes\n", n);
        exit(1);
    }
    read_all(buf, n);
    unsigned frames = n / (NCH * 2);
    if (!g_base_ns)
        g_base_ns = (int64_t)due;
    double ak = (double)((int64_t)due - g_base_ns) - (double)g_wi * (1e9 / IN_RATE);
    if (g_nblk_since == 0 || (int64_t)due - g_last_due > 500000000LL || fabs(ak - g_a) > 60e6) {
        g_a = ak; g_nblk_since = 1; g_epoch++;                /* a stream starts: forget the old timing */
    } else {
        g_nblk_since++;
        double alpha = 1.0 / (g_nblk_since < 128 ? g_nblk_since : 128);
        g_a += (ak - g_a) * alpha;
    }
    g_last_due = (int64_t)due;
    for (int d = 0; d < MAXDEST; d++) {
        dest_t *D = &g_dest[d];
        if (!D->used)
            continue;
        const float *gl = D->gl[g_cls], *gr = D->gr[g_cls];
        struct lr4 *lp = D->lp[g_cls][0].hz > 0 ? D->lp[g_cls] : NULL;
        for (unsigned f = 0; f < frames; f++) {
            const int16_t *s = buf + f * NCH;
            float l = 0, r = 0;
            for (int c = 0; c < NCH; c++) {
                l += gl[c] * s[c]; r += gr[c] * s[c];
            }
            if (lp) {
                l = lr4_run(&lp[0], l); r = lr4_run(&lp[1], r);
            }
            unsigned at = (unsigned)((g_wi + f) & (RING - 1));
            D->ring[2 * at] = l; D->ring[2 * at + 1] = r;
        }
    }
    g_wi += frames;
}

static dest_t *dest_get(void)
{
    uint8_t d;
    read_all(&d, 1);
    if (d >= MAXDEST) {
        fprintf(stderr, "hpmix: bad destination %u\n", d);
        exit(1);
    }
    dest_t *D = &g_dest[d];
    if (!D->used) {
        D->ring = calloc(RING, 2 * sizeof(float));
        if (!D->ring)
            exit(1);
        D->used = 1;
    }
    return D;
}

static void cmd_request(void)
{
    static unsigned char out[4096 * 4];
    dest_t *D = dest_get();
    int64_t t; uint16_t n;
    read_all(&t, 8); read_all(&n, 2);
    if (n > 4096)
        n = 4096;
    if (fabs(g_kernel_ratio - g_out_rate / IN_RATE) > 1e-12)
        make_kernel();
    double step0 = IN_RATE / g_out_rate, step = step0;
    int have = g_nblk_since > 0;
    if (have) {
        double want = ((double)(t - g_base_ns) - D->trim_ns - g_a) * (IN_RATE / 1e9);
        double err = want - D->pos;
        if (!D->anchored || D->epoch != g_epoch || fabs(err) > JUMP_FRAMES) {
            if (D->anchored)
                D->jumps++;
            D->pos = want; D->anchored = 1; D->epoch = g_epoch; err = 0;
        }
        double adj = err / (LOOP_TAU * IN_RATE);
        if (adj > MAX_ADJ) adj = MAX_ADJ;
        if (adj < -MAX_ADJ) adj = -MAX_ADJ;
        step = step0 * (1 + adj);
        D->err_last = err;
    }
    for (unsigned j = 0; j < n; j++) {
        double l = 0, r = 0;
        if (have) {
            double fl = floor(D->pos);
            int64_t i = (int64_t)fl;
            int64_t first = i - (TAPS / 2 - 1), last = first + TAPS - 1;
            if (first >= 0 && (uint64_t)last < g_wi && g_wi - (uint64_t)first < RING) {
                double ph = (D->pos - fl) * PHASES;
                int p = (int)ph; float w = (float)(ph - p);
                const float *k0 = g_kernel[p], *k1 = g_kernel[p + 1];
                for (int k = 0; k < TAPS; k++) {
                    float c = k0[k] + (k1[k] - k0[k]) * w;
                    unsigned at = (unsigned)((uint64_t)(first + k) & (RING - 1));
                    l += c * D->ring[2 * at]; r += c * D->ring[2 * at + 1];
                }
            } else {
                D->silent++;
            }
            D->pos += step;
        } else {
            D->silent++;
        }
        long li = lrint(l), ri = lrint(r);
        if (li > 32767) li = 32767;
        if (li < -32768) li = -32768;
        if (ri > 32767) ri = 32767;
        if (ri < -32768) ri = -32768;
        out[4 * j] = (unsigned char)(li >> 8); out[4 * j + 1] = (unsigned char)li;
        out[4 * j + 2] = (unsigned char)(ri >> 8); out[4 * j + 3] = (unsigned char)ri;
    }
    D->frames += n;
    write_all(out, (size_t)n * 4);
}

int main(void)
{
    make_kernel();
    for (;;) {
        unsigned char c;
        read_all(&c, 1);
        if (c == 'B') {
            cmd_block();
        } else if (c == 'R') {
            cmd_request();
        } else if (c == 'G' || c == 'g') {
            dest_t *D = dest_get();
            float g[2 * NCH];
            uint8_t cls = 0;
            if (c == 'g')
                read_all(&cls, 1);
            read_all(g, sizeof g);
            for (int k = (c == 'g' ? cls % 3 : 0); k < (c == 'g' ? cls % 3 + 1 : 3); k++) {
                memcpy(D->gl[k], g, sizeof D->gl[k]); memcpy(D->gr[k], g + NCH, sizeof D->gr[k]);
            }
        } else if (c == 'L') {
            dest_t *D = dest_get();
            uint8_t cls;
            float hz;
            read_all(&cls, 1); read_all(&hz, 4);
            cls %= 3;
            if (!(hz >= 20.0f && hz <= 2000.0f))
                hz = 0.0f;
            if (hz != D->lp[cls][0].hz)
                for (int k = 0; k < 2; k++) {
                    if (hz > 0.0f)
                        lr4_set(&D->lp[cls][k], hz, (float)IN_RATE);
                    else
                        D->lp[cls][k].hz = 0.0f;
                }
        } else if (c == 'C') {
            uint8_t cls;
            read_all(&cls, 1);
            g_cls = cls % 3;
        } else if (c == 'T') {
            dest_t *D = dest_get();
            int32_t us;
            read_all(&us, 4);
            D->trim_ns = us * 1000.0;
        } else if (c == 'O') {
            uint32_t r;
            read_all(&r, 4);
            if (r >= 8000 && r <= 192000)
                g_out_rate = r;
        } else if (c == 'S') {
            char line[1024]; int o = 0;
            o += snprintf(line + o, sizeof line - o, "in=%llu epoch=%u", (unsigned long long)g_wi, g_epoch);
            for (int d = 0; d < MAXDEST; d++)
                if (g_dest[d].used)
                    o += snprintf(line + o, sizeof line - o, " d%d:frames=%lu,silent=%lu,jumps=%lu,err_us=%.0f", d, g_dest[d].frames,
                                  g_dest[d].silent, g_dest[d].jumps, g_dest[d].err_last * 1e6 / IN_RATE);
            o += snprintf(line + o, sizeof line - o, "\n");
            write_all(line, (size_t)o);
        } else {
            fprintf(stderr, "hpmix: unknown command %d\n", c);
            return 1;
        }
    }
}
