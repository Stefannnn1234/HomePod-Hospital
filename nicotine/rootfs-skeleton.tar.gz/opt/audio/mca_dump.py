#!/usr/bin/env python3
"""
mca_dump.py - Dump and analyze MCA (Multi-Channel Audio) registers on HomePod A8.

Hardware addresses (from device tree):
  MCA3:       0x20a0ac000  (audio cluster 3, used for speaker output)
  I2S switch: 0x20a003000  (routes I2S between MCA ports and pins)
  NCO:        0x20e011000  (numerically controlled oscillator for MCLK)

Register map based on Asahi Linux's apple-mca driver (M1) - the A8 likely
has an earlier revision of the same IP, so offsets may differ. This tool
dumps raw values for comparison.

Asahi MCA register map (per cluster, relative to cluster base):
  0x000  STATUS / cluster control
  0x004  MCLK configuration
  0x100  SYNCGEN (sync generator config)
  0x200  TX SERDES configuration
  0x204  TX SERDES bit start
  0x208  TX SERDES slot mask
  0x20C  TX SERDES active slots
  0x300  RX SERDES configuration
  0x304  RX SERDES bit start
  0x308  RX SERDES slot mask
  0x30C  RX SERDES active slots
  0x400  TX port configuration
  0x404  TX port control
  0x500  RX port configuration
  0x504  RX port control
  0x600  Port enables
  0x604  Port clock select
  0x608  Port data select
"""

import os
import sys
import struct
import time
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mmio

# ============================================================
# Hardware addresses
# ============================================================

MCA3_BASE       = 0x20a0ac000   # MCA cluster 3 (speaker output)
MCA_CLUSTER_SIZE = 0x4000       # Size of each MCA cluster
I2S_SWITCH_BASE = 0x20a003000   # I2S signal routing switch
NCO_BASE        = 0x20e011000   # NCO for MCLK generation

# Also check other MCA clusters for comparison
MCA0_BASE       = 0x20a0a0000   # MCA cluster 0
MCA1_BASE       = 0x20a0a4000   # MCA cluster 1
MCA2_BASE       = 0x20a0a8000   # MCA cluster 2

# Audio power/clock gates (from device tree - approximate)
AUD_PMGR_BASE   = 0x20e080000   # Power manager base (approximate)

# ============================================================
# MCA register offsets (from Asahi M1 driver - may differ on A8)
# ============================================================

# Cluster-level registers
REG_STATUS          = 0x000
REG_MCLK_CONF       = 0x004

# Sync generator
REG_SYNCGEN_STATUS  = 0x100
REG_SYNCGEN_MCLK    = 0x104
REG_SYNCGEN_HI      = 0x108
REG_SYNCGEN_LO      = 0x10C

# TX SERDES (serializer)
REG_TX_SERDES_CONF     = 0x200
REG_TX_SERDES_BITSTART = 0x204
REG_TX_SERDES_SLOTMASK = 0x208
REG_TX_SERDES_SLOTS    = 0x20C
REG_TX_SERDES_CLKSEL   = 0x210

# RX SERDES (deserializer)
REG_RX_SERDES_CONF     = 0x300
REG_RX_SERDES_BITSTART = 0x304
REG_RX_SERDES_SLOTMASK = 0x308
REG_RX_SERDES_SLOTS    = 0x30C

# TX port
REG_TX_PORT_CONF    = 0x400
REG_TX_PORT_CTL     = 0x404
REG_TX_PORT_FIFO    = 0x408  # FIFO control/status
REG_TX_PORT_DATA    = 0x40C  # TX data write (PIO mode)

# RX port
REG_RX_PORT_CONF    = 0x500
REG_RX_PORT_CTL     = 0x504
REG_RX_PORT_FIFO    = 0x508
REG_RX_PORT_DATA    = 0x50C

# Port routing
REG_PORT_ENABLES    = 0x600
REG_PORT_CLK_SEL    = 0x604
REG_PORT_DATA_SEL   = 0x608

# Known register list for structured dump
MCA_REGS = [
    ("STATUS",              REG_STATUS),
    ("MCLK_CONF",           REG_MCLK_CONF),
    ("SYNCGEN_STATUS",      REG_SYNCGEN_STATUS),
    ("SYNCGEN_MCLK",        REG_SYNCGEN_MCLK),
    ("SYNCGEN_HI",          REG_SYNCGEN_HI),
    ("SYNCGEN_LO",          REG_SYNCGEN_LO),
    ("TX_SERDES_CONF",      REG_TX_SERDES_CONF),
    ("TX_SERDES_BITSTART",  REG_TX_SERDES_BITSTART),
    ("TX_SERDES_SLOTMASK",  REG_TX_SERDES_SLOTMASK),
    ("TX_SERDES_SLOTS",     REG_TX_SERDES_SLOTS),
    ("TX_SERDES_CLKSEL",    REG_TX_SERDES_CLKSEL),
    ("RX_SERDES_CONF",      REG_RX_SERDES_CONF),
    ("RX_SERDES_BITSTART",  REG_RX_SERDES_BITSTART),
    ("RX_SERDES_SLOTMASK",  REG_RX_SERDES_SLOTMASK),
    ("RX_SERDES_SLOTS",     REG_RX_SERDES_SLOTS),
    ("TX_PORT_CONF",        REG_TX_PORT_CONF),
    ("TX_PORT_CTL",         REG_TX_PORT_CTL),
    ("TX_PORT_FIFO",        REG_TX_PORT_FIFO),
    ("RX_PORT_CONF",        REG_RX_PORT_CONF),
    ("RX_PORT_CTL",         REG_RX_PORT_CTL),
    ("RX_PORT_FIFO",        REG_RX_PORT_FIFO),
    ("PORT_ENABLES",        REG_PORT_ENABLES),
    ("PORT_CLK_SEL",        REG_PORT_CLK_SEL),
    ("PORT_DATA_SEL",       REG_PORT_DATA_SEL),
]


def dump_mca_cluster(base, name="MCA"):
    """Dump known MCA registers for a cluster."""
    print(f"\n{'=' * 60}")
    print(f"  {name} @ 0x{base:09x}")
    print(f"{'=' * 60}")

    # First, check if the cluster is accessible
    test = mmio.read32(base + REG_STATUS)
    if test == 0xFFFFFFFF:
        print(f"  WARNING: Reads as 0xFFFFFFFF - cluster may not be clocked!")
        return False

    # Dump known registers
    for name_str, offset in MCA_REGS:
        try:
            val = mmio.read32(base + offset)
            marker = " ***" if val != 0 else ""
            print(f"  {name_str:25s} [0x{offset:03x}] = 0x{val:08x}{marker}")
        except Exception as e:
            print(f"  {name_str:25s} [0x{offset:03x}] = ERROR: {e}")

    return True


def dump_mca_full(base, name="MCA", word_count=256):
    """Full raw register dump of an MCA cluster."""
    print(f"\n{'=' * 60}")
    print(f"  {name} FULL DUMP @ 0x{base:09x} ({word_count} words)")
    print(f"{'=' * 60}")

    nonzero = 0
    for i in range(word_count):
        addr = base + i * 4
        try:
            val = mmio.read32(addr)
            if val != 0:
                nonzero += 1
                print(f"  [0x{i*4:04x}] = 0x{val:08x}")
        except Exception as e:
            print(f"  [0x{i*4:04x}] = ERROR: {e}")
            break

    print(f"\n  ({nonzero} non-zero registers out of {word_count})")


def dump_i2s_switch(base=I2S_SWITCH_BASE):
    """Dump the I2S signal routing switch."""
    print(f"\n{'=' * 60}")
    print(f"  I2S SWITCH @ 0x{base:09x}")
    print(f"{'=' * 60}")

    # Dump first 64 registers
    for i in range(64):
        addr = base + i * 4
        try:
            val = mmio.read32(addr)
            if val != 0:
                print(f"  [0x{i*4:03x}] = 0x{val:08x}")
        except Exception:
            break


def dump_nco(base=NCO_BASE):
    """Dump the NCO (Numerically Controlled Oscillator) registers."""
    print(f"\n{'=' * 60}")
    print(f"  NCO @ 0x{base:09x}")
    print(f"{'=' * 60}")

    # NCO register layout (from Asahi linux - apple,nco):
    # Per-channel (4 channels typically):
    #   0x00: Control
    #   0x04: Increment (frequency tuning word)
    #   0x08: Accumulator (read-only current phase)
    # Channels at stride 0x4000 on M1, but may differ on A8

    # Try a smaller stride first (A8 may be simpler)
    strides = [0x4000, 0x1000, 0x100, 0x10]

    print("  Trying to identify NCO register layout...")

    # First, dump the first 256 bytes to see what's there
    for i in range(64):
        addr = base + i * 4
        try:
            val = mmio.read32(addr)
            if val != 0 or i < 16:
                print(f"  [0x{i*4:03x}] = 0x{val:08x}")
        except Exception:
            break

    # Also check at larger offsets in case channels are spread out
    for stride in strides:
        for ch in range(1, 4):
            addr = base + ch * stride
            try:
                val = mmio.read32(addr)
                if val != 0:
                    print(f"  [ch{ch}@+0x{ch*stride:x}] [0x000] = 0x{val:08x}")
            except Exception:
                pass


def interpret_mca(base):
    """Try to interpret MCA register values."""
    print(f"\n{'=' * 60}")
    print(f"  MCA INTERPRETATION @ 0x{base:09x}")
    print(f"{'=' * 60}")

    status = mmio.read32(base + REG_STATUS)
    print(f"\n  Status: 0x{status:08x}")
    if status & 1:
        print("    Bit 0: Cluster enabled")
    if status & 2:
        print("    Bit 1: Clock running")

    mclk = mmio.read32(base + REG_MCLK_CONF)
    print(f"\n  MCLK config: 0x{mclk:08x}")

    syncgen = mmio.read32(base + REG_SYNCGEN_STATUS)
    print(f"\n  Syncgen status: 0x{syncgen:08x}")

    sg_mclk = mmio.read32(base + REG_SYNCGEN_MCLK)
    sg_hi = mmio.read32(base + REG_SYNCGEN_HI)
    sg_lo = mmio.read32(base + REG_SYNCGEN_LO)
    print(f"  Syncgen MCLK: 0x{sg_mclk:08x}")
    print(f"  Syncgen HI/LO: 0x{sg_hi:08x} / 0x{sg_lo:08x}")
    if sg_hi + sg_lo > 0:
        period = sg_hi + sg_lo
        print(f"  Frame period: {period} MCLK cycles")
        # With 256fs MCLK at 48kHz: period = 256
        if period == 256:
            print("    -> 256fs (standard for 48kHz)")
        elif period == 512:
            print("    -> 512fs")

    tx_conf = mmio.read32(base + REG_TX_SERDES_CONF)
    tx_mask = mmio.read32(base + REG_TX_SERDES_SLOTMASK)
    tx_slots = mmio.read32(base + REG_TX_SERDES_SLOTS)
    print(f"\n  TX SERDES config: 0x{tx_conf:08x}")
    print(f"  TX slot mask: 0x{tx_mask:08x} ({bin(tx_mask)})")
    print(f"  TX active slots: 0x{tx_slots:08x}")
    if tx_mask:
        active_slots = []
        for bit in range(32):
            if tx_mask & (1 << bit):
                active_slots.append(bit)
        print(f"  Active TX slots: {active_slots}")

    port_en = mmio.read32(base + REG_PORT_ENABLES)
    clk_sel = mmio.read32(base + REG_PORT_CLK_SEL)
    data_sel = mmio.read32(base + REG_PORT_DATA_SEL)
    print(f"\n  Port enables: 0x{port_en:08x}")
    print(f"  Port clock select: 0x{clk_sel:08x}")
    print(f"  Port data select: 0x{data_sel:08x}")


def scan_audio_block():
    """Scan the audio register block for active/clocked peripherals."""
    print("\n" + "=" * 60)
    print("  AUDIO BLOCK SCAN")
    print("  Scanning for non-0/non-FF regions in the audio address space")
    print("=" * 60)

    # Scan key regions
    regions = [
        (0x20a0a0000, "MCA0"),
        (0x20a0a4000, "MCA1"),
        (0x20a0a8000, "MCA2"),
        (0x20a0ac000, "MCA3 (speakers)"),
        (0x20a003000, "I2S Switch"),
        (0x20e011000, "NCO"),
    ]

    for base, name in regions:
        try:
            val = mmio.read32(base)
            if val == 0xFFFFFFFF:
                status = "NOT CLOCKED (0xFFFFFFFF)"
            elif val == 0:
                # Read a few more to be sure
                v1 = mmio.read32(base + 4)
                v2 = mmio.read32(base + 8)
                if v1 == 0 and v2 == 0:
                    status = "all zeros (powered but inactive?)"
                else:
                    status = f"0x{val:08x} (partially active)"
            else:
                status = f"0x{val:08x} (ACTIVE)"
            print(f"  {name:25s} @ 0x{base:09x} : {status}")
        except Exception as e:
            print(f"  {name:25s} @ 0x{base:09x} : ERROR: {e}")


def main():
    parser = argparse.ArgumentParser(description='MCA register dump tool')
    parser.add_argument('action', nargs='?', default='scan',
                        choices=['scan', 'mca3', 'all-mca', 'i2s', 'nco',
                                 'full', 'interpret'],
                        help='What to dump')
    parser.add_argument('--words', '-w', type=int, default=256,
                        help='Number of 32-bit words for full dump')
    parser.add_argument('--base', '-b', type=lambda x: int(x, 0),
                        help='Custom base address')
    args = parser.parse_args()

    try:
        if args.action == 'scan':
            scan_audio_block()

        elif args.action == 'mca3':
            dump_mca_cluster(MCA3_BASE, "MCA3 (Speakers)")
            interpret_mca(MCA3_BASE)

        elif args.action == 'all-mca':
            for i, base in enumerate([MCA0_BASE, MCA1_BASE, MCA2_BASE, MCA3_BASE]):
                dump_mca_cluster(base, f"MCA{i}")

        elif args.action == 'i2s':
            dump_i2s_switch()

        elif args.action == 'nco':
            dump_nco()

        elif args.action == 'full':
            base = args.base or MCA3_BASE
            dump_mca_full(base, "FULL DUMP", args.words)

        elif args.action == 'interpret':
            dump_mca_cluster(MCA3_BASE, "MCA3 (Speakers)")
            interpret_mca(MCA3_BASE)
            dump_i2s_switch()
            dump_nco()

    except Exception as e:
        print(f"\nERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
    finally:
        mmio.cleanup()


if __name__ == '__main__':
    main()
