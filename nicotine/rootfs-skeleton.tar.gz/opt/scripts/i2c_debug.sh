#!/bin/sh
# i2c_debug.sh -- RUN ON THE HOMEPOD (not on the Mac).
#
# Diagnoses why the Apple I2C controllers report errors such as
#   i2c-apple 20a112000.i2c: NACK, status 0x08210100
#   i2c-apple 20a113000.i2c: Bus stuck, status 0x10210100
#
# Usage:
#   sh i2c_debug.sh            normal run (read-only, safe)
#   sh i2c_debug.sh --full     also do a full address scan on buses that
#                              look stuck (slow: every address times out)
#   sh i2c_debug.sh --regs     also read the I2C controller status registers
#                              through /dev/mem (only for controllers whose
#                              driver is bound; see warning below)
#
# From the Mac, in one step:
#   ./run_on_pod.sh scripts/i2c_debug.sh
#
# Nothing here writes to hardware registers. The bus scans do send I2C
# address probes, exactly like "i2cdetect -y BUS".

SYS="${SYS:-/sys}"                       # overridable for testing
DT="${DT:-/proc/device-tree}"
FULL=0
REGS=0
for a in "$@"; do
    case "$a" in
        --full) FULL=1 ;;
        --regs) REGS=1 ;;
        -h|--help) sed -n '2,20p' "$0"; exit 0 ;;
    esac
done

have() { command -v "$1" >/dev/null 2>&1; }
hr()   { echo ""; echo "==================== $* ===================="; }

if [ "$(uname -s)" != "Linux" ]; then
    echo "ERROR: this script must run ON the HomePod, not on $(uname -s)."
    echo "From the Mac use:  ./run_on_pod.sh scripts/i2c_debug.sh"
    exit 1
fi

# busybox "timeout" changed syntax between versions; find the one that works.
TMO=""
if have timeout; then
    if timeout 1 true 2>/dev/null; then TMO="timeout"
    elif timeout -t 1 true 2>/dev/null; then TMO="timeout -t"
    fi
fi
run_tmo() {   # run_tmo SECS CMD...
    secs="$1"; shift
    if [ -n "$TMO" ]; then $TMO "$secs" "$@"; else "$@"; fi
}

# Map an MMIO unit address to the SoC's name for the controller.
soc_name() {
    case "$1" in
        20a110000) echo "I2C0" ;;
        20a111000) echo "I2C1" ;;
        20a112000) echo "I2C2" ;;
        20a113000) echo "I2C3 (peppy MCU 0x55, ALS 0x29)" ;;
        *)         echo "?" ;;
    esac
}

dmesg_lines() { dmesg 2>/dev/null | wc -l; }
dmesg_since() { dmesg 2>/dev/null | tail -n +"$(( $1 + 1 ))"; }

SUMMARY=""
add_summary() { SUMMARY="$SUMMARY
$*"; }

# ---------------------------------------------------------------------------
hr "1. Kernel messages about I2C so far"
dmesg 2>/dev/null | grep -i "i2c" | tail -25
[ -z "$(dmesg 2>/dev/null | grep -i i2c)" ] && echo "(none)"

# ---------------------------------------------------------------------------
hr "2. I2C buses (i2cdetect -l)"
if have i2cdetect; then
    i2cdetect -l 2>&1
else
    echo "i2cdetect is not installed."
fi

echo ""
echo "Bus number -> controller mapping (from sysfs):"
BUSES=""
for dev in /dev/i2c-*; do
    [ -c "$dev" ] || continue
    n="${dev#/dev/i2c-}"
    BUSES="$BUSES $n"
    path=$(readlink -f "$SYS/class/i2c-adapter/i2c-$n" 2>/dev/null)
    mmio=$(echo "$path" | sed -n 's/.*\/\([0-9a-fA-F]*\)\.i2c\/.*/\1/p')
    echo "  bus $n = /dev/i2c-$n = ${mmio:+0x$mmio }$(soc_name "$mmio")"
    eval "MMIO_$n=\"$mmio\""
done
if [ -z "$BUSES" ]; then
    echo "  No /dev/i2c-* devices exist."
    echo "  -> Either no I2C controller driver probed, or the kernel lacks"
    echo "     CONFIG_I2C_CHARDEV. Check section 1 and section 4."
    add_summary "No I2C adapters in /dev: nothing can be scanned."
fi

# ---------------------------------------------------------------------------
hr "3. Bus scans"
for n in $BUSES; do
    eval "mmio=\$MMIO_$n"
    echo ""
    echo "--- bus $n (${mmio:+0x$mmio, }$(soc_name "$mmio")) ---"
    if ! have i2cdetect; then
        echo "i2cdetect missing, skipping"
        continue
    fi

    # Quick health check first: one read probe at 0x55, then see what the
    # kernel said about it.
    before=$(dmesg_lines)
    run_tmo 10 i2cdetect -y -r "$n" 0x55 0x55 >/dev/null 2>&1
    new=$(dmesg_since "$before" | grep -i "i2c")
    stuck=0
    if echo "$new" | grep -qi "stuck\|timeout\|timed out"; then
        stuck=1
    fi

    if [ "$stuck" = 1 ] && [ "$FULL" = 0 ]; then
        echo "A single probe already made the kernel report:"
        echo "$new" | sed 's/^/    /'
        echo "Skipping the full scan (every address would time out)."
        echo "Use --full to scan anyway."
        add_summary "bus $n ($(soc_name "$mmio")): BUS STUCK / TIMEOUT - controller cannot complete a transfer."
        continue
    fi

    before=$(dmesg_lines)
    out=$(run_tmo 120 i2cdetect -y "$n" 2>&1)
    rc=$?
    if [ $rc -ne 0 ] || [ -z "$out" ]; then
        # Quick-write probing may be unsupported; retry with read probing.
        out=$(run_tmo 120 i2cdetect -y -r "$n" 2>&1)
        rc=$?
    fi
    echo "$out"
    [ $rc -ne 0 ] && echo "(i2cdetect exit status $rc)"

    found=$(echo "$out" | sed -n 's/^[0-7]0: //p' | tr ' ' '\n' | grep -c '^[0-9a-fU][0-9a-fU]$')
    new=$(dmesg_since "$before" | grep -i "i2c")
    nstuck=$(echo "$new" | grep -ci "stuck\|timeout\|timed out")
    nnack=$(echo "$new" | grep -ci "nack")
    echo "Result: $found device address(es) answered;" \
         "kernel logged $nnack NACK and $nstuck stuck/timeout message(s) during the scan."

    if [ "$nstuck" -gt 0 ]; then
        add_summary "bus $n ($(soc_name "$mmio")): BUS STUCK / TIMEOUT during scan, $found address(es) answered."
    elif [ "$found" -gt 0 ]; then
        add_summary "bus $n ($(soc_name "$mmio")): OK, $found address(es) answered."
    else
        add_summary "bus $n ($(soc_name "$mmio")): controller works but NO device answered (all NACK)."
    fi
done

# ---------------------------------------------------------------------------
hr "4. Device tree: I2C controllers and the devices expected on them"
if [ -d "$DT" ]; then
    nodes=$(find "$DT" -maxdepth 3 -type d -name 'i2c@*' 2>/dev/null | sort)
    [ -z "$nodes" ] && echo "No i2c@... nodes in the device tree."
    for node in $nodes; do
        unit="${node##*@}"
        status="okay (default)"
        [ -f "$node/status" ] && status=$(tr -d '\0' < "$node/status")
        echo ""
        echo "${node#$DT}  [$(soc_name "$unit")]"
        echo "  status:        $status"
        echo "  pinctrl-0:     $([ -f "$node/pinctrl-0" ] && echo present || echo "MISSING (pins may not be muxed to I2C)")"
        echo "  power-domains: $([ -f "$node/power-domains" ] && echo present || echo "MISSING (kernel will not power the block)")"
        echo "  clocks:        $([ -f "$node/clocks" ] && echo present || echo missing)"
        if [ -e "$SYS/bus/platform/devices/$unit.i2c/driver" ]; then
            echo "  driver:        bound ($(basename "$(readlink -f "$SYS/bus/platform/devices/$unit.i2c/driver")"))"
        else
            echo "  driver:        NOT bound"
        fi
        kids=0
        for child in "$node"/*@*; do
            [ -d "$child" ] || continue
            kids=$((kids + 1))
            compat=""
            [ -f "$child/compatible" ] && compat=$(tr '\0' ' ' < "$child/compatible")
            echo "  child device:  ${child##*/}  $compat"
        done
        [ "$kids" = 0 ] && echo "  child devices: none declared (so no reset/power GPIO is being driven for anything on this bus)"
    done
else
    echo "$DT not available."
fi

# ---------------------------------------------------------------------------
hr "5. Pin mux (are the SDA/SCL pads actually set to I2C?)"
pm_found=0
for f in "$SYS"/kernel/debug/pinctrl/*/pinmux-pins; do
    [ -f "$f" ] || continue
    pm_found=1
    echo "$f:"
    if grep -i "i2c" "$f" >/dev/null 2>&1; then
        grep -i "i2c" "$f" | sed 's/^/    /'
    else
        echo "    no pin is claimed by any i2c device"
        echo "    -> the pads are still in whatever state iBoot left them."
        add_summary "pinmux: no pins claimed by I2C (pads not muxed by Linux)."
    fi
done
[ "$pm_found" = 0 ] && echo "pinctrl debugfs not available (debugfs not mounted or no pinctrl driver)."

# ---------------------------------------------------------------------------
hr "6. Power domains (kernel view)"
gs="$SYS/kernel/debug/pm_genpd/pm_genpd_summary"
if [ -f "$gs" ]; then
    echo "Lines mentioning i2c in $gs:"
    grep -i "i2c" "$gs" | sed 's/^/    /'
    grep -qi "i2c" "$gs" || echo "    (none - no genpd power domain is named or attached for i2c)"
else
    echo "pm_genpd_summary not available."
fi

# ---------------------------------------------------------------------------
hr "7. PMGR power-gate registers (hardware view, via /dev/mem)"
# Register layout as used by Linux drivers/pmdomain/apple/pmgr-pwrstate.c:
#   bits 3:0  target state     bits 7:4  actual state
#   0xF = active, 0x4 = clock gated, 0x0 = power gated
#   bit 31 = reset asserted,   bit 10 = device disabled
ps_state() {
    case "$1" in
        15) echo "ACTIVE" ;;
        4)  echo "clock-gated" ;;
        0)  echo "POWER-GATED" ;;
        *)  echo "state $1" ;;
    esac
}
if [ ! -c /dev/mem ]; then
    echo "/dev/mem not available: cannot read PMGR registers."
elif ! have devmem; then
    echo "devmem tool not available: cannot read PMGR registers."
elif [ ! -d "$DT" ]; then
    echo "No device tree: cannot locate PMGR power-state registers."
else
    ps_found=0
    for lab in $(find "$DT" -name label 2>/dev/null); do
        name=$(tr -d '\0' < "$lab")
        case "$name" in
            i2c*|I2C*) ;;
            *) continue ;;
        esac
        node=$(dirname "$lab")
        parent=$(dirname "$node")
        off="${node##*@}"
        base="${parent##*@}"
        case "$off"  in ""|*[!0-9a-fA-F]*) continue ;; esac
        case "$base" in ""|*[!0-9a-fA-F]*) continue ;; esac
        addr=$(printf '0x%x' $(( 0x$base + 0x$off )))
        val=$(devmem "$addr" 32 2>/dev/null)
        if [ -z "$val" ]; then
            echo "  $name  @ $addr : read failed"
            continue
        fi
        ps_found=1
        actual=$(( (val >> 4) & 0xf ))
        target=$(( val & 0xf ))
        extra=""
        [ $(( (val >> 31) & 1 )) = 1 ] && extra="$extra RESET-ASSERTED"
        [ $(( (val >> 10) & 1 )) = 1 ] && extra="$extra DEV-DISABLED"
        echo "  $name  @ $addr = $val : actual=$(ps_state $actual) target=$(ps_state $target)$extra"
        if [ "$actual" != 15 ] || [ -n "$extra" ]; then
            add_summary "PMGR: $name is NOT active (actual=$(ps_state $actual)$extra)."
        fi
    done
    if [ "$ps_found" = 0 ]; then
        echo "No PMGR power-state node labelled i2c* found in the device tree,"
        echo "so the register addresses are unknown and nothing was read."
        echo "(Without such nodes the kernel also cannot switch these domains on.)"
        add_summary "PMGR: device tree has no i2c power-state nodes; gate status unknown."
    fi
fi

# ---------------------------------------------------------------------------
if [ "$REGS" = 1 ]; then
    hr "8. I2C controller status registers (--regs)"
    # Offsets from Linux drivers/i2c/busses/i2c-pasemi-core.c:
    #   SMSTA 0x14 (status), CTL 0x1c (control)
    #   SMSTA bit 27 = XEN (transfer ended), bit 21 = MTN (NACK received)
    echo "WARNING: reading a controller whose power domain is off can crash"
    echo "the kernel. Only controllers with a bound driver are read."
    if [ ! -c /dev/mem ] || ! have devmem; then
        echo "/dev/mem or devmem not available."
    else
        for n in $BUSES; do
            eval "mmio=\$MMIO_$n"
            [ -n "$mmio" ] || continue
            if [ ! -e "$SYS/bus/platform/devices/$mmio.i2c/driver" ]; then
                echo "  bus $n (0x$mmio): driver not bound, skipped"
                continue
            fi
            smsta=$(devmem $(printf '0x%x' $(( 0x$mmio + 0x14 ))) 32 2>/dev/null)
            ctl=$(devmem $(printf '0x%x' $(( 0x$mmio + 0x1c ))) 32 2>/dev/null)
            echo "  bus $n (0x$mmio): SMSTA=$smsta CTL=$ctl"
        done
    fi
fi

# ---------------------------------------------------------------------------
hr "SUMMARY"
if [ -n "$SUMMARY" ]; then
    echo "$SUMMARY" | sed '/^$/d; s/^/  * /'
else
    echo "  (nothing conclusive)"
fi
cat <<'EOF'

How to read this:
  * "controller works but NO device answered (all NACK)"
      The I2C block is clocked and the lines are idle-high, but the chips on
      the bus are unpowered or held in reset. Look for regulator / reset GPIOs
      that audioOS turns on before talking to them.
  * "BUS STUCK / TIMEOUT"
      The controller cannot finish a transfer. Check, in this order:
      section 7 (is the i2c power domain ACTIVE?), section 5 (are the pads
      muxed to I2C?), then whether a device on the bus is holding SDA/SCL low
      because it is half-powered.
  * Section 7 shows a domain that is not ACTIVE
      That alone explains errors on that bus: the block is gated.
EOF
