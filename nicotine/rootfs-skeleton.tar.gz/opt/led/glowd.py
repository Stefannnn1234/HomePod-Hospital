#!/usr/bin/python3
"""glowd.py - the top panel of Nicotine (HomePod 1st gen): Sound Glow and touch.

One program owns the top-board MCU (I2C3, address 0x55):

  Sound Glow   soft color blobs drift over the 19 LEDs and breathe with the
               music, in the spirit of Apple's Sound Glow (GLOW_ENABLED).
  Touch        + / - change the volume, a tap on the centre is play/pause,
               two taps next, three taps previous track (TOUCH_ENABLED).
               Holding the centre for 3 s opens (or closes) the Bluetooth
               pairing window; while it is open the centre and inner ring
               pulse blue, with three quick blinks when a device has paired.
               The decoding is in touch.py, the actions in touch-action.

Started and stopped by /usr/sbin/homepod-glow. It runs while either of the
two is enabled.

Inputs
  /run/homepod/meter        32 bytes written by hpfeed 30 times a second
                            (u32 seq, u32 playing, f32 rms, peak, low, mid, high, onset)
  /etc/homepod-glow.conf    GLOW_ENABLED, GLOW_BRIGHTNESS (1..100), GLOW_PALETTE,
                            TOUCH_ENABLED, TOUCH_DRYRUN, TOUCH_ICON_SWAP;
                            re-read when it changes, no restart needed
  /run/homepod/airplay.meta shairport-sync metadata FIFO (cover art), read only
                            while Sound Glow is on and the palette is "auto"
  /run/homepod/bt.pairing, bt.pair-event   written by homepod-bluetooth (pairing window)
  the touch surface         command 0x43, polled 25..30 times a second
Output
  LED frames (command 0x11) to the MCU, /run/homepod/glow.state (key=value)
  for "homepod-glow status" and the web UI, and /opt/led/touch-action
  up|down|playpause|next|prev|pair|unmute, started in the background.

What this program sends to the MCU: LED frames (0x11), the touch poll (0x43),
the mode byte "touch scanning on, AutoLED off" (0x15 0x01, every 30 s: what
peppy-keepalive used to send; homepod-glow stops that script while this
program runs) and the read-only version query (0x01). Nothing else, ever.

Behaviour
  - Sound Glow: 30 frames a second while audio plays; 1 s after it stops the
    glow fades out over 2.5 s. The level is normalised against the loudest
    recent passage, so a low sender volume still glows.
  - The + and - symbols are lit dimly while music plays and for a few seconds
    after a touch, and flash on a volume step. Play/pause is acknowledged
    with a short pulse of the centre LED when Sound Glow is not drawing.
  - When nothing is lit one all-off frame is sent and no more LED frames
    until something changes.
  - Volume up is the dangerous direction: touch.py drops anything unclear,
    and the actions are rate-limited here (5 a second at most).
  - If the MCU stops answering the program backs off (0.4 s doubling to 30 s
    between attempts) and keeps running. It never retries in a tight loop.
  - On SIGTERM/SIGINT the LEDs are switched off before exit.

  glowd.py            run (normally via homepod-glow)
  glowd.py --bench    time the frame generator on this machine and exit
"""
import colorsys, math, mmap, os, random, select, signal, stat, struct, subprocess, sys, time, zlib

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import peppy                                     # noqa: E402  (framing, LED positions, gamma)
import touch                                     # noqa: E402  (touch report decoder)

RUN = os.environ.get("HOMEPOD_GLOW_RUN", "/run/homepod")
CONF = os.environ.get("HOMEPOD_GLOW_CONF", "/etc/homepod-glow.conf")
HELPER = os.environ.get("HOMEPOD_GLOW_HELPER", "/usr/libexec/hpartcolors")
TESTDEV = os.environ.get("HOMEPOD_GLOW_DEV", "")     # test hook: "unix:/path" instead of /dev/i2c-N
METER = RUN + "/meter"
META = RUN + "/airplay.meta"
STATE = RUN + "/glow.state"
ARTFILE = RUN + "/glow-art.img"
ACTION = os.environ.get("HOMEPOD_GLOW_ACTION", os.path.join(HERE, "touch-action"))
DSPCONF = RUN + "/dsp.conf"
TOUCHMUTE = RUN + "/touch.muted"                 # touch-action leaves this while its own mute is on
BTPAIRING = RUN + "/bt.pairing"                  # homepod-bluetooth: exists while a pairing window is open
BTPAIREVENT = RUN + "/bt.pair-event"             # ... and what last happened to it: "paired 7", "closed 8"
ICONTEST = RUN + "/glow.icontest"                # "homepod-glow icontest" creates it

FPS = 30
CEILING = 0.40           # hard cap on the global LED level (linear light); peppy.py's own cap is 0.50
DEFAULT_BRIGHTNESS = 60  # percent of the slider; level = CEILING * (percent/100)^2  -> 0.144
HOLD_S = 1.0             # keep glowing this long after the last audible sample
FADE_OUT_S = 2.5
FADE_IN_S = 0.8
AMBIENT = 0.30           # share of the brightness that does not depend on the level
TOUCH_PERIOD = 0.04      # touch poll while nothing is animated (25 a second)
MODE_PERIOD = 30.0       # repeat the mode byte this often (the MCU falls back to blinking after ~60 s)
ICON_ON = 0.10           # the + and - symbols while music plays / after a touch (share of full PWM)
ICON_FLASH = 0.35        # ... and for FLASH_S after a volume step
FLASH_S = 0.15
ICON_FADE_S = 0.4
ICON_HOLD_S = 5.0        # keep the symbols lit this long after the last touch
ACK_S = 0.45             # centre-LED pulse for play/pause
ACK_LEVEL = 0.06
PAIR_PERIOD = 2.4        # Bluetooth pairing window: slow blue pulse on the centre and inner ring
PAIR_LEVEL = 0.10        # ... peak, as a share of full PWM (like the symbols; not scaled by brightness)
PAIR_DONE_S = 1.2        # confirmation when a device has paired (three quick blinks)
PAIR_END_S = 0.7         # ... and when the window closes without one (a single fade)
PAIR_LEDS = (12, 13, 14, 15, 16, 17, 18)         # inner ring and centre
REFRESH_S = 2.0          # repeat a static frame this often
ACTION_GAP = 0.2         # at most 5 actions a second
UNMUTE_AFTER_S = 5.0     # a touch "pause" (mute) is lifted when the stream has been gone this long
NLED = peppy.NLED
assert CEILING <= peppy.MAX_LEVEL and ICON_FLASH <= CEILING and PAIR_LEVEL * 1.5 <= CEILING

PALETTES = {
    # name: three colors, 0..1 before the LED gamma table
    "nicotine": ((1.00, 0.25, 0.10), (0.10, 0.35, 1.00), (0.70, 0.10, 0.90)),
    "aurora":   ((0.10, 1.00, 0.45), (0.05, 0.55, 1.00), (0.55, 0.20, 1.00)),
    "sunset":   ((1.00, 0.45, 0.05), (1.00, 0.12, 0.30), (0.60, 0.10, 0.80)),
    "ocean":    ((0.00, 0.45, 1.00), (0.00, 0.90, 0.80), (0.25, 0.15, 0.90)),
    "ember":    ((1.00, 0.15, 0.02), (1.00, 0.50, 0.05), (0.90, 0.05, 0.15)),
    "white":    ((1.00, 0.80, 0.60), (1.00, 0.90, 0.80), (0.90, 0.75, 0.60)),
}
DEFAULT_PALETTE = "nicotine"
PALETTE_NAMES = ("auto",) + tuple(PALETTES) + ("custom",)   # auto = cover art, else the default palette; custom = GLOW_COLOR


def log(msg):
    try:
        sys.stderr.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
        sys.stderr.flush()
    except OSError:
        pass


# ---- settings --------------------------------------------------------------
MAX_COLORS = 12
MODES = ("blobs", "pulse", "meter", "bands", "sparkle")          # Sound Glow animations (react to the music)
EFFECTS = ("off", "solid", "breathe", "rainbow", "comet", "fire", "twinkle", "wave", "heartbeat")   # always on


def parse_colors(v):
    """'ff8800' or 'ff8800,0088ff,aa00ff,...' (up to 12 hex colors, no '#') -> tuple of (r, g, b) 0..1"""
    out = []
    for part in v.replace("#", "").split(",")[:MAX_COLORS]:
        part = part.strip()
        if len(part) == 6 and all(ch in "0123456789abcdefABCDEF" for ch in part):
            out.append(tuple(int(part[i:i + 2], 16) / 255.0 for i in (0, 2, 4)))
    return tuple(out)


def custom_palette(cols):
    """the chosen colors -> the list the animation uses (a single color gets a lighter and a
    deeper neighbor so the glow still moves; more than three take turns, a few seconds each)"""
    cols = [tuple(c) for c in cols]
    if not cols:
        return PALETTES[DEFAULT_PALETTE]
    if len(cols) > 3:
        return tuple(cols)
    if len(cols) == 1:
        c = cols[0]
        light = tuple(min(1.0, v * 0.55 + 0.45 * max(c)) for v in c)
        deep = tuple(v * 0.55 for v in c)
        return (c, light, deep)
    while len(cols) < 3:
        cols.append(cols[-1])
    return tuple(cols)


def load_conf(path=None):
    c = {"enabled": 0, "brightness": DEFAULT_BRIGHTNESS, "palette": "auto",
         "touch": 1, "dryrun": 0, "swap": 0, "lights": 1, "color": (),
         "mode": "blobs", "effect": "off"}
    try:
        with open(path or CONF) as f:
            for line in f:
                line = line.split("#", 1)[0].strip()
                if "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k = k.strip(); v = v.strip().strip('"').strip("'")
                if k == "GLOW_ENABLED":
                    c["enabled"] = 1 if v in ("1", "yes", "on", "true") else 0
                elif k == "GLOW_BRIGHTNESS" and v.isdigit():
                    c["brightness"] = max(1, min(100, int(v)))
                elif k == "GLOW_PALETTE" and v in PALETTE_NAMES:
                    c["palette"] = v
                elif k == "TOUCH_ENABLED":
                    c["touch"] = 1 if v in ("1", "yes", "on", "true") else 0
                elif k == "TOUCH_LIGHTS":
                    c["lights"] = 0 if v in ("0", "no", "off", "false") else 1
                elif k == "GLOW_MODE" and v in MODES:
                    c["mode"] = v
                elif k == "GLOW_EFFECT" and v in EFFECTS:
                    c["effect"] = v
                elif k == "GLOW_COLOR":
                    c["color"] = parse_colors(v)
                elif k == "TOUCH_DRYRUN":
                    c["dryrun"] = 1 if v in ("1", "yes", "on", "true") else 0
                elif k == "TOUCH_ICON_SWAP":
                    c["swap"] = 1 if v in ("1", "yes", "on", "true") else 0
    except OSError:
        pass
    return c


def level_for(percent):
    """slider percent -> global LED level (linear light), never above CEILING"""
    p = max(1, min(100, percent)) / 100.0
    return min(CEILING, CEILING * p * p)


# ---- meter -----------------------------------------------------------------
class MeterIn:
    """Reads hpfeed's meter block. ok is False while there is no fresh data."""
    S = struct.Struct("<II6f")

    def __init__(self, path=METER):
        self.path = path
        self.m = None
        self.seq = -1
        self.t_seq = 0.0
        self.t_open = -1e9
        self.ok = False
        self.playing = 0
        self.rms = self.peak = self.low = self.mid = self.high = self.onset = 0.0

    def _open(self, now):
        self.t_open = now
        self.close()
        try:
            fd = os.open(self.path, os.O_RDONLY)
            try:
                if os.fstat(fd).st_size >= 32:
                    self.m = mmap.mmap(fd, 32, mmap.MAP_SHARED, mmap.PROT_READ)
            finally:
                os.close(fd)
        except (OSError, ValueError):
            self.m = None
        self.seq = -1
        self.t_seq = now

    def close(self):
        if self.m is not None:
            try:
                self.m.close()
            except (OSError, ValueError):
                pass
            self.m = None

    def read(self, now):
        m = self.m
        if m is None:
            if now - self.t_open >= 2.0:
                self._open(now)
            self.ok = False
            return False
        un = self.S.unpack_from
        for _ in range(4):
            a = un(m, 0)
            if not a[0] & 1 and a == un(m, 0):
                break
        else:
            return self.ok                       # writer was mid-update four times: keep the last values
        if a[0] != self.seq:
            self.seq = a[0]
            self.t_seq = now
            (_, self.playing, self.rms, self.peak, self.low, self.mid, self.high, self.onset) = a
            self.ok = True
        elif now - self.t_seq > 0.5:
            # the feeder stopped updating: it is gone or was replaced. Look again later.
            self.ok = False
            self.playing = 0
            if now - self.t_open >= 2.0:
                self._open(now)
        return self.ok


def feed_playing():
    """Fallback when hpfeed has no meter: its play/idle state file."""
    try:
        with open(RUN + "/feed.state") as f:
            return f.read(8).startswith("play")
    except OSError:
        return False


def bt_streaming():
    try:
        with open(RUN + "/bt.streaming") as f:
            return f.read(2).strip() == "1"
    except OSError:
        return False


# ---- the MCU ---------------------------------------------------------------
class Dev:
    """The MCU, with back-off: LED frames (0x11), touch poll (0x43), mode byte (0x15);
    opening sends the version query (0x01, read-only)."""
    PACK = struct.Struct(">2H57H")
    TRIES = 10               # per transfer; the MCU does not acknowledge while it is busy
    ANSWER_S = 0.004         # wait this long after a command before reading its answer

    def __init__(self):
        self.p = None
        self.fails = 0
        self.retry_at = 0.0
        self.errors = 0
        self.last_err = ""
        self.t_logged = -1e9
        self.buf = bytearray(4 + 0x76 + 1)       # header, 2 icon values + 57 LED values, checksum
        self.buf[0] = 0x11
        self.buf[1] = 0x76
        self.vals = [0] * 57
        self.icons = [0, 0]                      # the two symbol LEDs, 16-bit PWM
        self.seq = 1
        self.retries = 0                         # transfers that needed another try
        self.lut = None
        self.level = 0.0
        self.hw = None
        self.lit = False                         # True once a non-black frame may be showing

    def _open(self):
        if TESTDEV.startswith("unix:"):
            import socket
            s = socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET)
            tv = struct.pack("ll", 1, 0)             # blocking, like the I2C device, but never for long
            s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVTIMEO, tv)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_SNDTIMEO, tv)
            s.connect(TESTDEV[5:])
            p = peppy.Peppy.__new__(peppy.Peppy)
            p.fd = s.detach()
            p.seq = 1
            p.gamma = None
        else:
            try:
                p = peppy.Peppy()
            except SystemExit as e:              # peppy.py reports "bus not found" this way
                raise OSError(str(e))
        try:
            v = p.version()                      # read-only: is the MCU alive, which LED board
        except Exception:
            os.close(p.fd)
            raise
        if len(v) < 3 or v[2] < 4:
            os.close(p.fd)
            raise OSError("LED board version %s does not take the 19-LED frame" % v.hex())
        p.load_gamma()
        self.hw = v.hex()
        return p

    def set_level(self, level):
        """(re)build the three gamma tables with the global level folded in"""
        level = max(0.0, min(level, CEILING))
        if self.lut is not None and abs(level - self.level) < 1e-6:
            return
        self.level = level
        p = self.p
        self.lut = [[int(p._pwm(i / 1024.0, ch) * level) for i in range(1025)] for ch in range(3)]

    def ready(self, now):
        """True if frames can be sent. Opens the device when a retry is due."""
        if self.p is not None:
            return True
        if now < self.retry_at:
            return False
        try:
            self.p = self._open()
        except Exception as e:                   # OSError, IOError from peppy, socket errors
            self._failed(now, "MCU not reachable: %s" % e)
            return False
        if self.fails:
            log("MCU answering again (version %s)" % self.hw)
        self.fails = 0
        self.lut = None
        return True

    def _failed(self, now, why):
        self.fails += 1
        self.errors += 1
        self.last_err = why
        self.retry_at = now + min(30.0, 0.2 * (1 << min(self.fails, 8)))
        if self.p is not None:
            try:
                os.close(self.p.fd)
            except OSError:
                pass
            self.p = None
        if now - self.t_logged > 600.0 or self.fails == 1:
            self.t_logged = now
            log("%s (attempt %d, next in %.1f s)" % (why, self.fails, self.retry_at - now))

    def _xfer(self, fn, pause=None):
        """one I2C transfer, repeated while the MCU does not acknowledge (it is busy).
        Writes: a growing pause as in Apple's driver (16 us doubling, about 16 ms in all).
        Reads pass a fixed pause instead."""
        for n in range(self.TRIES):
            try:
                return fn()
            except OSError as e:
                last = e
                self.retries += 1
                time.sleep(pause if pause else 16e-6 * (1 << n))
        raise last

    def send(self, now):
        """write self.icons and self.vals as one LED frame; False (and back-off) on failure"""
        b = self.buf
        self.PACK.pack_into(b, 4, self.icons[0], self.icons[1], *self.vals)
        b[122] = 0
        b[122] = (-sum(b)) & 0xFF
        fd = self.p.fd
        try:
            self._xfer(lambda: os.write(fd, b))
        except OSError as e:
            self._failed(now, "LED frame not accepted: %s" % e)
            return False
        self.lit = True
        return True

    def _command(self, cmd, data=b""):
        """framed command with an answer of unknown length -> its data bytes.

        The MCU needs 3 to 5 ms to prepare an answer. Reading earlier works too, but the
        kernel then spins on the bus for that long (measured on the pod: 3.7 ms of CPU per
        poll against 0.14 ms), so wait first. The first read takes 6 bytes, which is the
        whole answer when it carries 0 or 1 data bytes (the usual case: "no touch")."""
        seq = self.seq
        self.seq = seq + 1 if seq < 255 else 1
        f = bytes((cmd, len(data), seq, 0)) + data
        f += bytes(((-sum(f)) & 0xFF,))
        fd = self.p.fd
        self._xfer(lambda: os.write(fd, f))
        for _ in range(3):                       # an answer to an older command may still be waiting
            time.sleep(self.ANSWER_S)
            r = self._xfer(lambda: os.read(fd, 6), 0.0015)
            if len(r) < 5:
                raise OSError("short answer to 0x%02x: %s" % (cmd, r.hex()))
            total = 5 + r[1]
            if len(r) < total:
                n = total - len(r)
                r += self._xfer(lambda: os.read(fd, n), 0.0015)
            r = r[:total]
            if len(r) != total or sum(r) & 0xFF:
                raise OSError("bad answer to 0x%02x: %s" % (cmd, r[:8].hex()))
            if r[0] == (cmd | 0x80) and r[2] == seq:
                if r[3]:
                    raise OSError("MCU status 0x%02x for command 0x%02x" % (r[3], cmd))
                return r[4:4 + r[1]]
        raise OSError("no answer to 0x%02x" % cmd)

    def poll(self, now):
        """touch poll: the 74-byte report, b"" when the MCU has none, None on failure (back-off)"""
        try:
            d = self._command(0x43)
        except OSError as e:
            self._failed(now, "touch poll failed: %s" % e)
            return None
        return d if len(d) == touch.REPORT_LEN else b""

    def mode(self, now):
        """touch scanning on, AutoLED (the boot-time blinking) off; False on failure (back-off)"""
        try:
            self._command(0x15, b"\x01")
        except OSError as e:
            self._failed(now, "mode byte not accepted: %s" % e)
            return False
        return True

    def black(self, now=None, tries=1):
        """all LEDs off. Used when idle and on exit."""
        v = self.vals
        for i in range(57):
            v[i] = 0
        self.icons[0] = self.icons[1] = 0
        for n in range(tries):
            if self.p is None:
                return False
            if self.send(time.monotonic() if now is None else now):
                self.lit = False
                return True
            if n + 1 < tries:
                time.sleep(0.05)
                self.retry_at = 0.0
                self.ready(time.monotonic())
        return False


# ---- animation -------------------------------------------------------------
class Anim:
    NB = 3
    TAB_N = 256
    TAB_SCALE = TAB_N / 6.0                      # table covers exp(-u) for u in 0..6

    def __init__(self):
        self.lx = [p[0] for p in peppy.POS]
        self.ly = [p[1] for p in peppy.POS]
        self.tab = [math.exp(-i / self.TAB_SCALE) for i in range(self.TAB_N)] + [0.0]
        # per blob: angle, angular speed (rad/s), radius phase, radius speed, extra spin from beats
        self.th = [0.0, 2.1, 4.2]
        self.w = [0.23, -0.17, 0.12]
        self.ph = [0.0, 1.7, 3.9]
        self.f = [0.13, 0.19, 0.16]
        self.spin = [0.0, 0.0, 0.0]
        self.kick = [0.9, -0.7, 0.5]
        self.col = [list(c) for c in PALETTES[DEFAULT_PALETTE]]
        self.target = [list(c) for c in PALETTES[DEFAULT_PALETTE]]
        self.pal = [tuple(c) for c in PALETTES[DEFAULT_PALETTE]]
        self.rot = 0.0                           # which of a long palette the three blobs are on
        self.reset_level()
        self.loud = self.e_low = self.e_mid = self.e_high = 0.0
        self.beat = 0.0
        self.master = 0.0
        self.cx = [0.0] * 3
        self.cy = [0.0] * 3
        self.k = [0.0] * 3
        self.amp = [0.0] * 3

    ROT_S = 6.0                                  # seconds per step through a palette of more than three colors

    def set_palette(self, cols, snap=False):
        cols = [tuple(c) for c in cols] or [tuple(c) for c in PALETTES[DEFAULT_PALETTE]]
        if cols != self.pal:
            self.pal = cols
            self.rot = 0.0
        self._targets(snap)

    def _targets(self, snap=False):
        n = len(self.pal)
        base = int(self.rot) % n if n > 3 else 0
        for k in range(3):
            c = self.pal[(base + k) % n]
            self.target[k][0], self.target[k][1], self.target[k][2] = c
            if snap:
                self.col[k][0], self.col[k][1], self.col[k][2] = c

    # Reference levels never fall below these (about -84 dBFS full band): AirPlay's
    # volume range is 60 dB, and music 60 dB down is still far above a 16-bit noise floor.
    FLOOR = 6e-5
    FLOOR_BAND = 4e-5
    FLOOR_HIGH = 2.5e-5

    def reset_level(self):
        """forget the loudness of the last source: the next one sets its own scale"""
        self.ref = self.FLOOR
        self.refl = self.refm = self.FLOOR_BAND
        self.refh = self.FLOOR_HIGH

    def step(self, dt, active, m, synth_t=None):
        """advance the state by dt seconds from the meter values; returns master (0 = dark)"""
        if synth_t is None:
            rms, low, mid, high, onset = m.rms, m.low, m.mid, m.high, m.onset
        else:                                    # no meter: a slow, quiet breathing
            rms = 0.012
            low = 0.012 + 0.008 * math.sin(synth_t * 1.3)
            mid = 0.010 + 0.006 * math.sin(synth_t * 0.9 + 1.0)
            high = 0.006 + 0.004 * math.sin(synth_t * 1.7 + 2.0)
            onset = 0.0
            self.ref = self.refl = self.refm = self.refh = 0.02
        # normalise against the loudest recent passage (the reference decays with a 10 s time constant)
        d = math.exp(-dt / 10.0)
        fl = self.FLOOR_BAND
        r = self.ref * d
        self.ref = r = rms if rms > r else (r if r > self.FLOOR else self.FLOOR)
        r = self.refl * d
        self.refl = rl = low if low > r else (r if r > fl else fl)
        r = self.refm * d
        self.refm = rm = mid if mid > r else (r if r > fl else fl)
        r = self.refh * d
        self.refh = rh = high if high > r else (r if r > self.FLOOR_HIGH else self.FLOOR_HIGH)
        up = 1.0 - math.exp(-dt * 22.0)          # attack ~45 ms
        dn = 1.0 - math.exp(-dt * 3.8)           # release ~260 ms
        x = rms / self.ref
        self.loud += (x - self.loud) * (up if x > self.loud else dn)
        x = low / rl; x *= x                     # squared: quiet bass stays quiet, kicks stand out
        self.e_low += (x - self.e_low) * (up if x > self.e_low else dn)
        x = mid / rm
        self.e_mid += (x - self.e_mid) * (up if x > self.e_mid else dn)
        x = high / rh
        self.e_high += (x - self.e_high) * (up if x > self.e_high else dn)
        # beats: the meter's onset value, held briefly; a new one nudges the blobs along
        b = self.beat - dt * 3.5
        if onset > b:
            if onset > 0.3 and b < 0.15:
                for k in range(3):
                    self.spin[k] += self.kick[k] * onset
            b = onset
        self.beat = b = b if b > 0.0 else 0.0
        # fade in / out
        if active:
            mm = self.master + dt / FADE_IN_S
            self.master = mm = mm if mm < 1.0 else 1.0
        else:
            mm = self.master - dt / FADE_OUT_S
            self.master = mm = mm if mm > 0.0 else 0.0
        # blobs: position, size, brightness
        loud = self.loud
        drift = 1.0 + 1.2 * loud
        sd = math.exp(-dt * 4.0)
        env = (self.e_low, self.e_mid, self.e_high)
        ts = self.TAB_SCALE
        for k in range(3):
            self.spin[k] *= sd
            th = self.th[k] + dt * (self.w[k] * drift + self.spin[k])
            if th > 6.283185307179586:
                th -= 6.283185307179586
            elif th < 0.0:
                th += 6.283185307179586
            self.th[k] = th
            ph = self.ph[k] + dt * self.f[k]
            if ph > 6.283185307179586:
                ph -= 6.283185307179586
            self.ph[k] = ph
            rho = 0.55 + 0.25 * math.sin(ph)
            self.cx[k] = rho * math.cos(th)
            self.cy[k] = rho * math.sin(th)
            e = env[k]
            if k == 0:
                s = 0.50 * (0.85 + 0.45 * e + 0.20 * b)      # bass pumps the first blob's size
            else:
                s = 0.46 * (0.90 + 0.25 * e)
            self.k[k] = ts / (2.0 * s * s)
            a = AMBIENT + (1.0 - AMBIENT) * (0.35 * loud + 0.65 * e)
            if k == 0:
                a += 0.15 * b
            self.amp[k] = mm * (a if a < 1.0 else 1.0)
        # long palettes: move on to the next colors every ROT_S seconds
        if len(self.pal) > 3:
            old = int(self.rot)
            self.rot += dt / self.ROT_S
            if int(self.rot) != old:
                if self.rot > 1e6:
                    self.rot = 0.0
                self._targets(False)
        # colors drift towards the current palette (about 1.5 s)
        g = 1.0 - math.exp(-dt * 2.0)
        for k in range(3):
            c = self.col[k]; t = self.target[k]
            c[0] += (t[0] - c[0]) * g
            c[1] += (t[1] - c[1]) * g
            c[2] += (t[2] - c[2]) * g
        return mm

    def render(self, lut, vals):
        """fill vals[0:57] with PWM values for the current state. Hot loop: no containers are made."""
        lx = self.lx; ly = self.ly; tab = self.tab
        lr, lg, lb = lut
        c = self.col
        a = self.amp[0]; r0 = c[0][0] * a; g0 = c[0][1] * a; b0 = c[0][2] * a
        a = self.amp[1]; r1 = c[1][0] * a; g1 = c[1][1] * a; b1 = c[1][2] * a
        a = self.amp[2]; r2 = c[2][0] * a; g2 = c[2][1] * a; b2 = c[2][2] * a
        x0 = self.cx[0]; y0 = self.cy[0]; k0 = self.k[0]
        x1 = self.cx[1]; y1 = self.cy[1]; k1 = self.k[1]
        x2 = self.cx[2]; y2 = self.cy[2]; k2 = self.k[2]
        j = 0
        for i in range(19):
            x = lx[i]; y = ly[i]
            dx = x - x0; dy = y - y0
            n = int((dx * dx + dy * dy) * k0)
            w0 = tab[n if n < 256 else 256]
            dx = x - x1; dy = y - y1
            n = int((dx * dx + dy * dy) * k1)
            w1 = tab[n if n < 256 else 256]
            dx = x - x2; dy = y - y2
            n = int((dx * dx + dy * dy) * k2)
            w2 = tab[n if n < 256 else 256]
            n = int((w0 * r0 + w1 * r1 + w2 * r2) * 1024.0)
            vals[j] = lr[n if n < 1024 else 1024]
            n = int((w0 * g0 + w1 * g1 + w2 * g2) * 1024.0)
            vals[j + 1] = lg[n if n < 1024 else 1024]
            n = int((w0 * b0 + w1 * b1 + w2 * b2) * 1024.0)
            vals[j + 2] = lb[n if n < 1024 else 1024]
            j += 3


# ---- other animations ---------------------------------------------------------
# Rings: LEDs 0..11 outer, 12..17 inner, 18 centre. FRAC[i] = where around the speaker it sits, 0..1.
_ANG = [math.atan2(y, x) for (x, y) in peppy.POS]
FRAC = [(a % (2.0 * math.pi)) / (2.0 * math.pi) for a in _ANG]
_OUT_ORDER = sorted(range(12), key=lambda i: FRAC[i])
OUT_RANK = {i: n for n, i in enumerate(_OUT_ORDER)}


def _mix(a, b, t):
    return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t)


def _clip(x):
    return 0.0 if x < 0.0 else 1.0 if x > 1.0 else x


class Fx:
    """Sound Glow animations besides the blobs, and the always-on effects. Colors come from
    anim.col (the three smoothed palette colors); anim.master fades everything in and out."""

    def __init__(self):
        self.sp = [0.0] * 19                     # sparkle / twinkle brightness per LED
        self.sc = [0] * 19                       # ... and which color it uses
        self.rng = random.Random()

    @staticmethod
    def put(lut, vals, i, c, a):
        lr, lg, lb = lut
        j = 3 * i
        n = int(_clip(c[0] * a) * 1024.0)
        vals[j] = lr[n]
        n = int(_clip(c[1] * a) * 1024.0)
        vals[j + 1] = lg[n]
        n = int(_clip(c[2] * a) * 1024.0)
        vals[j + 2] = lb[n]

    # -- reactive animations (GLOW_MODE)
    def mode(self, name, anim, lut, vals, dt):
        c0, c1, c2 = anim.col
        m = anim.master
        loud = _clip(anim.loud)
        put = self.put
        if name == "pulse":
            a = m * (0.18 + 0.82 * _clip(loud * 1.1 + 0.25 * anim.beat))
            col = _mix(c0, c1, _clip(anim.e_high))
            for i in range(18):
                put(lut, vals, i, col, a)
            put(lut, vals, 18, c2, min(1.0, a * 1.2))
        elif name == "meter":
            lit = _clip(loud * 1.25) * 12.0
            for i in range(12):
                r = OUT_RANK[i]
                v = _clip(lit - r)
                t = r / 11.0
                col = _mix(c0, c1, t * 2.0) if t < 0.5 else _mix(c1, c2, t * 2.0 - 1.0)
                put(lut, vals, i, col, m * (0.05 + 0.95 * v))
            e = _clip(anim.e_mid * 1.2)
            for i in range(12, 18):
                put(lut, vals, i, c1, m * (0.06 + 0.94 * e))
            put(lut, vals, 18, c2, m * (0.06 + 0.94 * _clip(anim.e_low + 0.4 * anim.beat)))
        elif name == "bands":
            for i in range(12):
                put(lut, vals, i, c0, m * (0.08 + 0.92 * _clip(anim.e_low)))
            for i in range(12, 18):
                put(lut, vals, i, c1, m * (0.08 + 0.92 * _clip(anim.e_mid)))
            put(lut, vals, 18, c2, m * (0.08 + 0.92 * _clip(anim.e_high)))
        else:                                    # sparkle
            rate = dt * (2.0 + 14.0 * loud + 30.0 * anim.beat)
            n = int(rate) + (1 if self.rng.random() < rate - int(rate) else 0)
            for _ in range(n):
                i = self.rng.randrange(19)
                self.sp[i] = 1.0
                self.sc[i] = self.rng.randrange(3)
            d = math.exp(-dt * 4.5)
            cols = (c0, c1, c2)
            for i in range(19):
                self.sp[i] *= d
                put(lut, vals, i, cols[self.sc[i]], m * (0.04 + 0.96 * self.sp[i]))

    # -- always-on effects (GLOW_EFFECT)
    def effect(self, name, t, dt, anim, lut, vals):
        c0, c1, c2 = anim.col
        m = anim.master
        put = self.put
        if name == "solid":
            for i in range(19):
                put(lut, vals, i, c0, m * 0.9)
        elif name == "breathe":
            x = 0.5 - 0.5 * math.cos(2.0 * math.pi * t / 5.0)
            col = _mix(c0, c1, x)
            for i in range(19):
                put(lut, vals, i, col, m * (0.12 + 0.88 * x))
        elif name == "rainbow":
            for i in range(19):
                h = (FRAC[i] + t * 0.07) % 1.0
                r, g, b = colorsys.hsv_to_rgb(h, 1.0, 1.0)
                put(lut, vals, i, (r, g, b), m * 0.8)
        elif name == "comet":
            head = (t * 0.18) % 1.0
            head2 = (-t * 0.12) % 1.0
            for i in range(12):
                d = (head - FRAC[i]) % 1.0
                w = math.exp(-d * 9.0)
                put(lut, vals, i, _mix(c0, c1, _clip(d * 3.0)), m * (0.03 + 0.97 * w))
            for i in range(12, 18):
                d = (FRAC[i] - head2) % 1.0
                put(lut, vals, i, c2, m * (0.03 + 0.6 * math.exp(-d * 5.0)))
            put(lut, vals, 18, c1, m * (0.25 + 0.2 * math.sin(t * 2.0)))
        elif name == "fire":
            for i in range(19):
                n = 0.5 + 0.5 * (0.5 * math.sin(t * 7.3 + i * 1.7) + 0.3 * math.sin(t * 12.1 + i * 4.1)
                                 + 0.2 * math.sin(t * 3.3 + i * 2.3))
                h = _clip(n) ** 1.5
                if i >= 12:
                    h = min(1.0, h * 1.25)
                put(lut, vals, i, (1.0, 0.35 * h ** 1.6, 0.02 * h ** 3), m * 0.95 * (0.1 + 0.9 * h))
        elif name == "twinkle":
            rate = dt * 5.0
            n = int(rate) + (1 if self.rng.random() < rate - int(rate) else 0)
            for _ in range(n):
                i = self.rng.randrange(19)
                if self.sp[i] <= 0.0:
                    self.sp[i] = 1.0
                    self.sc[i] = self.rng.randrange(3)
            cols = (c0, c1, c2)
            for i in range(19):
                v = 0.0
                if self.sp[i] > 0.0:
                    v = math.sin(math.pi * (1.0 - self.sp[i]))
                    self.sp[i] -= dt / 1.4
                    if self.sp[i] < 0.0:
                        self.sp[i] = 0.0
                put(lut, vals, i, cols[self.sc[i]], m * (0.05 + 0.95 * v))
        elif name == "wave":
            for i in range(19):
                a = FRAC[i] * 2.0 * math.pi
                ring = 0.0 if i < 12 else 0.8 if i < 18 else 1.6
                s1 = 0.5 + 0.5 * math.sin(2.0 * a - t * 0.9 + ring)
                s2 = 0.5 + 0.5 * math.sin(a + t * 0.5)
                col = _mix(_mix(c0, c1, s1), c2, 0.5 * s2)
                put(lut, vals, i, col, m * (0.3 + 0.7 * s2))
        else:                                    # heartbeat
            p = (t % 1.25) / 1.25
            env = math.exp(-((p - 0.08) / 0.05) ** 2) + 0.7 * math.exp(-((p - 0.26) / 0.06) ** 2)
            env = _clip(env)
            col = _mix(c0, c1, env)
            for i in range(19):
                put(lut, vals, i, col, m * (0.06 + 0.94 * env))


# ---- cover art ---------------------------------------------------------------
def art_palette(lines):
    """helper output -> three vivid colors, or None when the cover has no usable color"""
    import colorsys
    cols = []
    for ln in lines:
        f = ln.split()
        if len(f) == 4 and all(x.isdigit() for x in f):
            r, g, b = (min(255, int(x)) / 255.0 for x in f[:3])
            h, s, _ = colorsys.rgb_to_hsv(r, g, b)
            cols.append((h, min(1.0, 0.25 + 0.9 * s)))   # the diffuser washes colors out: push saturation
    if not cols:
        return None
    if len(cols) == 1:
        h, s = cols[0]
        cols = [(h, s), ((h + 0.07) % 1.0, s), ((h - 0.07) % 1.0, s * 0.8)]
    elif len(cols) == 2:
        (h0, s0), (h1, s1) = cols
        d = ((h1 - h0 + 0.5) % 1.0) - 0.5                # shortest way round the hue circle
        cols.append(((h0 + 0.35 * d) % 1.0, 0.85 * max(s0, s1)))
    return [colorsys.hsv_to_rgb(h, s, 1.0) for h, s in cols[:3]]


class Art:
    """Follows shairport-sync's metadata FIFO and turns cover art into a palette.
       Nothing here blocks: the FIFO is non-blocking and the image helper runs as a child."""
    PICT = b"50494354"
    COPL = b"636f706c"
    MAXBUF = 3 << 20

    def __init__(self):
        self.fd = -1
        self.buf = bytearray()
        self.scan = 0
        self.t_open = -1e9
        self.crc = None
        self.proc = None
        self.t_proc = 0.0
        self.palette = None                      # list of 3 colors from the current cover
        self.changed = False
        self.images = 0
        self.note = ""

    def fileno(self):
        return self.fd

    def open(self, now):
        if self.fd >= 0 or now - self.t_open < 5.0:
            return
        self.t_open = now
        try:
            if not stat.S_ISFIFO(os.stat(META).st_mode):
                return
            # O_RDWR: we hold a write end too, so the FIFO never reads as end-of-file
            # and select() sleeps until shairport-sync really writes something.
            self.fd = os.open(META, os.O_RDWR | os.O_NONBLOCK)
            try:
                import fcntl
                fcntl.fcntl(self.fd, 1031, 1 << 20)      # F_SETPIPE_SZ: room for a whole cover
            except OSError:
                pass
        except OSError:
            self.fd = -1

    def close(self):
        if self.fd >= 0:
            try:
                os.close(self.fd)
            except OSError:
                pass
            self.fd = -1
        self.buf = bytearray()
        self.scan = 0
        self._reap(kill=True)

    def forget(self):
        if self.palette is not None:
            self.palette = None
            self.crc = None
            self.changed = True

    def poll(self, now):
        """read what is waiting, handle complete items, collect the helper's answer"""
        if self.proc is not None:
            self._reap(now=now)
        if self.fd < 0:
            return
        got = 0
        while got < (1 << 20):
            try:
                d = os.read(self.fd, 65536)
            except BlockingIOError:
                break
            except OSError:
                self.close()
                return
            if not d:
                break
            self.buf += d
            got += len(d)
        if not got:
            return
        buf = self.buf
        while True:
            e = buf.find(b"</item>", self.scan)
            if e < 0:
                self.scan = max(0, len(buf) - 6)
                break
            item = bytes(buf[:e])
            del buf[:e + 7]
            self.scan = 0
            self._item(item, now)
        if len(buf) > self.MAXBUF:               # not a stream we understand: start over
            del buf[:]
            self.scan = 0

    def _item(self, item, now):
        s = item.find(b"<item><type>")
        if s < 0:
            return
        head = item[s:s + 120]
        c = head.find(b"<code>")
        if c < 0 or not head.startswith(b"<item><type>73736e63</type>"):
            return                               # only 'ssnc' items matter here
        code = head[c + 6:c + 14]
        if code != self.PICT and code != self.COPL:
            return
        d = item.find(b'<data encoding="base64">', s)
        if d < 0:
            if code == self.PICT:                # zero-length picture: the track has no cover
                self.forget()
            return
        e = item.find(b"</data>", d)
        if e < 0 or e - d < 64:
            return
        import binascii
        try:
            raw = binascii.a2b_base64(item[d + 24:e])
        except (binascii.Error, ValueError):
            return
        if code == self.COPL:
            if b"ArtworkData" not in raw:
                return
            raw = self._from_plist(raw)
            if not raw:
                return
        self._image(raw, now)

    @staticmethod
    def _from_plist(raw):
        """AirPlay 2 now-playing plist -> artwork bytes (kMRMediaRemoteNowPlayingInfoArtworkData)"""
        try:
            import plistlib
            top = plistlib.loads(raw)
        except Exception:
            return None
        todo = [top]
        n = 0
        while todo and n < 2000:
            n += 1
            o = todo.pop()
            if isinstance(o, dict):
                v = o.get("kMRMediaRemoteNowPlayingInfoArtworkData")
                if isinstance(v, (bytes, bytearray)) and len(v) > 64:
                    return bytes(v)
                todo.extend(o.values())
            elif isinstance(o, (list, tuple)):
                todo.extend(o)
        return None

    def _image(self, raw, now):
        if len(raw) < 64 or len(raw) > (2 << 20):
            return
        crc = zlib.crc32(raw)
        if crc == self.crc:
            return                               # the same cover again (AirPlay repeats it)
        self._reap(kill=True)
        try:
            with open(ARTFILE, "wb") as f:
                f.write(raw)
            import subprocess
            self.proc = subprocess.Popen([HELPER, ARTFILE], stdin=subprocess.DEVNULL,
                                         stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        except (OSError, ValueError) as e:
            self.proc = None
            self.note = "helper: %s" % e
            return
        self.crc = crc
        self.t_proc = now
        self.images += 1

    def _reap(self, now=None, kill=False):
        p = self.proc
        if p is None:
            return
        if p.poll() is None:
            if not kill and now is not None and now - self.t_proc < 5.0:
                return
            try:
                p.kill()
            except OSError:
                pass
            try:
                p.wait(1.0)
            except Exception:
                pass
            out = b""
        else:
            try:
                out = p.stdout.read(512)
            except OSError:
                out = b""
        try:
            p.stdout.close()
        except OSError:
            pass
        self.proc = None
        try:
            os.unlink(ARTFILE)
        except OSError:
            pass
        if kill:
            return
        lines = out.decode("ascii", "replace").splitlines()
        pal = art_palette(lines) if lines and lines[-1].startswith("ok") else None
        self.note = lines[-1][:60] if lines else "helper gave no answer"
        if pal != self.palette:
            self.palette = pal
            self.changed = True


# ---- main ------------------------------------------------------------------
# ---- touch actions ---------------------------------------------------------
class Actions:
    """Runs /opt/led/touch-action NAME in the background, one at a time and at most
    five a second. Never blocks: the LED loop only starts it and looks whether it is done.
    Two requests may wait; a third "up" is dropped (too little volume is the safe error),
    anything else replaces the newest waiting one."""

    def __init__(self):
        self.proc = None
        self.t_spawn = -1e9
        self.wait = []
        self.dry = False
        self.ran = 0
        self.dropped = 0

    def request(self, now, name):
        if self.dry:
            log("touch (dry run): would run %s %s" % (ACTION, name))
            return
        if len(self.wait) >= 2:
            self.dropped += 1
            if name == "up":
                return
            self.wait[-1] = name
        else:
            self.wait.append(name)
        self.pump(now)

    def pump(self, now):
        if self.proc is not None:
            if self.proc.poll() is None:
                if now - self.t_spawn > 10.0:
                    log("touch: action still running after 10 s, killed")
                    try:
                        self.proc.kill()
                    except OSError:
                        pass
                return
            self.proc = None
        if not self.wait or now - self.t_spawn < ACTION_GAP:
            return
        name = self.wait.pop(0)
        self.t_spawn = now
        try:
            self.proc = subprocess.Popen([ACTION, name], stdin=subprocess.DEVNULL, stdout=sys.stderr,
                                         stderr=sys.stderr, close_fds=True, start_new_session=True)
            self.ran += 1
        except OSError as e:
            self.proc = None
            log("touch: cannot run %s: %s" % (ACTION, e))

    def busy(self):
        return self.proc is not None or bool(self.wait)

    def close(self):
        self.wait = []
        if self.proc is not None and self.proc.poll() is None:
            try:
                self.proc.wait(timeout=2.0)
            except Exception:
                pass


def touch_muted():
    """True while a mute that touch-action switched on is still in force"""
    if not os.path.exists(TOUCHMUTE):
        return False
    try:
        with open(DSPCONF) as f:
            return any(ln.strip() == "mute=1" for ln in f)
    except OSError:
        return False


def pairing_open():
    """True while homepod-bluetooth has a timed pairing window open (not for "always open")"""
    try:
        with open(BTPAIRING) as f:
            v = f.read(32).strip()
    except OSError:
        return False
    return v.isdigit() and v != "0"


def pair_event():
    """(word, serial) of the last pairing-window event, or None"""
    try:
        with open(BTPAIREVENT) as f:
            p = f.read(64).split()
    except OSError:
        return None
    if len(p) == 2 and p[0] in ("opened", "paired", "closed", "timeout") and p[1].isdigit():
        return p[0], int(p[1])
    return None


# ---- main loop -------------------------------------------------------------
def write_state(d):
    try:
        tmp = STATE + ".tmp"
        with open(tmp, "w") as f:
            for k in sorted(d):
                f.write("%s=%s\n" % (k, d[k]))
        os.replace(tmp, STATE)
    except OSError:
        pass


def hexcol(c):
    return "#%02x%02x%02x" % tuple(int(255 * max(0.0, min(1.0, v)) + 0.5) for v in c)


def run():
    flags = {"stop": False, "reload": True}

    def on_term(*_):
        flags["stop"] = True

    def on_hup(*_):
        flags["reload"] = True

    signal.signal(signal.SIGTERM, on_term)
    signal.signal(signal.SIGINT, on_term)
    signal.signal(signal.SIGHUP, on_hup)

    conf = load_conf()
    dev = Dev()
    meter = MeterIn()
    art = Art()
    anim = Anim()
    act = Actions()
    act.dry = bool(conf["dryrun"])
    dec = None                    # touch.Decoder while the MCU is being polled
    mono = time.monotonic
    gstate = "idle"               # Sound Glow: "idle" or "play" (play includes the fade-out)
    source = "default"
    conf_mtime = None
    next_conf = 0.0
    next_state = 0.0
    next_mode = 0.0
    next_refresh = 0.0
    next_mutecheck = 0.0
    last_sound = -1e9
    last_touch = -1e9
    last_playing = -1e9
    idle_since = mono()
    frames = 0
    t_prev = mono()
    t_tick = t_prev
    deadline = t_prev
    period = 1.0 / FPS
    want_state = True
    icon = [0.0, 0.0]             # current level of the two symbols, index 0 = plus (before swap)
    flash = [-1e9, -1e9]          # flash until
    ack_t = -1e9
    icontest_t = None
    sent = None                   # (icons, LED values) of the last frame written
    ev_count = {"up": 0, "down": 0, "playpause": 0, "next": 0, "prev": 0, "pair": 0, "reject": 0}
    fx = Fx()
    pairing = False               # a Bluetooth pairing window is open
    pair_t0 = 0.0                 # ... since
    pair_seen = pair_event()      # last event of that window already shown
    pair_done = (-1e9, "")        # confirmation: (start, "paired" | "closed")
    next_paircheck = 0.0
    last_event = ""
    t_reject_log = -1e9
    log("started: glow %s, brightness %d%% (level %.3f, ceiling %.2f), palette %s, %d fps, touch %s"
        % ("on" if conf["enabled"] else "off", conf["brightness"], level_for(conf["brightness"]), CEILING,
           conf["palette"], FPS, ("dry run" if conf["dryrun"] else "on") if conf["touch"] else "off"))

    def pick_palette(snap=False):
        nonlocal source
        if conf["palette"] == "auto":
            if art.palette is not None and not bt_streaming():
                anim.set_palette(art.palette, snap)
                source = "art"
            else:
                anim.set_palette(PALETTES[DEFAULT_PALETTE], snap)
                source = "default"
        elif conf["palette"] == "custom":
            anim.set_palette(custom_palette(conf["color"]), snap)
            source = "custom"
        else:
            anim.set_palette(PALETTES[conf["palette"]], snap)
            source = conf["palette"]

    def on_event(e, now):
        nonlocal last_touch, ack_t, last_event, want_state, t_reject_log, next_paircheck
        kind = e[0]
        if kind == "down":
            last_touch = now
            return
        if kind == "vol":
            name = "up" if e[1] > 0 else "down"
            last_touch = now
            flash[0 if e[1] > 0 else 1] = now + FLASH_S
            ev_count[name] += 1
            last_event = "%s (%s)" % (name, e[2])
            if e[2] == "tap" or ev_count[name] % 4 == 1:
                log("touch: volume %s (%s)" % (name, e[2]))
            act.request(now, name)
        elif kind == "centre":
            name = {1: "playpause", 2: "next", 3: "prev"}.get(e[1])
            last_touch = now
            if name is None:
                last_event = "centre x%d (ignored)" % e[1]
                return
            ev_count[name] += 1
            last_event = name
            log("touch: %s" % name)
            ack_t = now
            act.request(now, name)
        elif kind == "longpress":
            last_touch = now
            ev_count["pair"] += 1
            last_event = "pair (centre held)"
            log("touch: centre held: Bluetooth pairing window")
            ack_t = now
            act.request(now, "pair")
            next_paircheck = now + 0.3
        elif kind == "reject":
            ev_count["reject"] += 1
            last_event = "ignored (%s)" % e[1]
            if now - t_reject_log > 5.0:
                t_reject_log = now
                log("touch: ignored (%s)" % e[1])
        want_state = True

    pick_palette(True)
    try:
        while not flags["stop"]:
            now = mono()
            tick = now - t_tick
            t_tick = now
            if tick > 0.2:
                tick = 0.2
            # -- settings (once a second, or at once on SIGHUP)
            if now >= next_conf or flags["reload"]:
                next_conf = now + 1.0
                try:
                    mt = os.stat(CONF).st_mtime_ns
                except OSError:
                    mt = 0
                if mt != conf_mtime or flags["reload"]:
                    flags["reload"] = False
                    conf_mtime = mt
                    new = load_conf()
                    if new != conf:
                        log("settings: glow %d, brightness %d%%, palette %s, mode %s, effect %s, touch %d%s"
                            % (new["enabled"], new["brightness"], new["palette"], new["mode"], new["effect"], new["touch"],
                               " (dry run)" if new["dryrun"] else ""))
                    conf = new
                    if not conf["enabled"] and not conf["touch"]:
                        log("glow and touch both disabled in %s: leaving" % CONF)
                        break
                    act.dry = bool(conf["dryrun"])
                    if dev.p is not None:
                        dev.set_level(level_for(conf["brightness"]))
                    pick_palette()
                    want_state = True
                if conf["enabled"] and conf["palette"] == "auto":
                    art.open(now)
                    if source == "art" and bt_streaming():
                        pick_palette()           # Bluetooth took over: its music has no cover
                        want_state = True
                    if art.palette is not None and gstate == "idle" and (
                            now - idle_since > 300.0 or bt_streaming()):
                        art.forget()             # stale cover: do not show it for the next source
                elif art.fd >= 0:
                    art.close()
                if os.path.exists(ICONTEST):
                    try:
                        os.unlink(ICONTEST)
                    except OSError:
                        pass
                    icontest_t = now
                    log("icon test: first value for 2 s, then the second")
            glow_on = bool(conf["enabled"])
            touch_on = bool(conf["touch"])
            # -- cover art
            if art.fd >= 0 or art.proc is not None:
                art.poll(now)
            if art.changed:
                art.changed = False
                pick_palette()
                want_state = True
            # -- is there audio?
            have_meter = meter.read(now)
            synth = None
            if have_meter:
                playing = bool(meter.playing)
                if playing and meter.rms > 2e-5:     # anything above -94 dBFS counts as sound
                    last_sound = now
            else:
                playing = meter.m is None and feed_playing()
                if playing:
                    last_sound = now
                    synth = now
            active = now - last_sound < HOLD_S
            effect_on = glow_on and conf["effect"] != "off"
            if effect_on:
                active = True                    # an always-on effect does not wait for music
                if not have_meter and synth is None:
                    synth = now
            if playing:
                last_playing = now

            # -- the MCU: mode byte, touch
            ok = dev.ready(now)                  # opens it when a retry is due
            if ok and now >= next_mode:
                next_mode = now + MODE_PERIOD
                ok = dev.mode(now)
            if ok and touch_on:
                rep = dev.poll(now)
                if rep is None:
                    ok = False
                else:
                    if dec is None:
                        dec = touch.Decoder(now)
                    for e in dec.feed(now, rep or None):
                        on_event(e, now)
            if not ok or not touch_on:
                dec = None                       # start over (and re-arm) when polling resumes
            if dev.p is None:
                next_mode = 0.0                  # send the mode byte again when the MCU is back
                sent = None
            act.pump(now)
            # -- a touch "pause" on AirPlay is a mute; lift it once the stream itself has stopped
            if now >= next_mutecheck:
                next_mutecheck = now + 1.0
                if now - last_playing > UNMUTE_AFTER_S and not act.busy() and touch_muted():
                    log("touch: the stream has stopped, lifting the mute")
                    act.request(now, "unmute")

            # -- Bluetooth pairing window (homepod-bluetooth pair): look twice a second
            if now >= next_paircheck:
                next_paircheck = now + (0.25 if (pairing or act.busy()) else 0.5)
                po = pairing_open()
                if po and not pairing:
                    pair_t0 = now
                pairing = po
                pe = pair_event()
                if pe is not None and pe != pair_seen:
                    pair_seen = pe
                    if pe[0] == "paired":
                        pair_done = (now, "paired")
                    elif pe[0] in ("closed", "timeout"):
                        pair_done = (now, "closed")
                    want_state = True

            # -- Sound Glow
            animating = False
            if gstate == "idle" and glow_on and active and dev.p is not None:
                dev.set_level(level_for(conf["brightness"]))
                pick_palette(True)
                anim.reset_level()
                gstate = "play"
                t_prev = now
                want_state = True
            if gstate == "play":
                dt = now - t_prev
                t_prev = now
                if dt > 0.2:
                    dt = 0.2
                master = anim.step(dt, active and glow_on, meter, synth)
                if (master <= 0.0 and not (active and glow_on)) or dev.p is None:
                    anim.master = 0.0
                    gstate = "idle"
                    idle_since = now
                    want_state = True
                else:
                    if effect_on:
                        fx.effect(conf["effect"], now, dt, anim, dev.lut, dev.vals)
                    elif conf["mode"] != "blobs":
                        fx.mode(conf["mode"], anim, dev.lut, dev.vals, dt)
                    else:
                        anim.render(dev.lut, dev.vals)
                    animating = True
            if gstate != "play":
                v = dev.vals
                for i in range(57):
                    v[i] = 0
            # -- the + and - symbols, the play/pause pulse, the icon test
            want_icons = touch_on and conf["lights"] and (now - last_playing < HOLD_S or now - last_touch < ICON_HOLD_S)
            target = ICON_ON if want_icons else 0.0
            step = tick / ICON_FADE_S * ICON_ON
            iv = [0, 0]
            for i in (0, 1):
                if icon[i] < target:
                    icon[i] = min(target, icon[i] + step)
                    animating = True
                elif icon[i] > target:
                    icon[i] = max(target, icon[i] - step)
                    animating = True
                lv = icon[i]
                if now < flash[i] and conf["lights"]:
                    lv = ICON_FLASH
                    animating = True
                iv[i] = int(65535 * min(lv, CEILING))
            if icontest_t is not None:
                t = now - icontest_t
                iv = [int(65535 * ICON_FLASH) if t < 2.0 else 0, int(65535 * ICON_FLASH) if 2.5 <= t < 4.5 else 0]
                animating = True
                if t >= 5.0:
                    icontest_t = None
            elif conf["swap"]:
                iv.reverse()
            if now - ack_t < ACK_S and gstate != "play":
                x = (now - ack_t) / ACK_S
                a = int(65535 * ACK_LEVEL * math.sin(math.pi * x))
                dev.vals[54] = dev.vals[55] = dev.vals[56] = a      # LED 18, the centre one
                animating = True
            # -- Bluetooth pairing: slow blue pulse while the window is open, then a confirmation
            pv = None
            if pairing:
                x = 0.5 - 0.5 * math.cos(2.0 * math.pi * (now - pair_t0) / PAIR_PERIOD)
                pv = (0.0, 0.0, PAIR_LEVEL * (0.15 + 0.85 * x))
            elif pair_done[1] == "paired" and now - pair_done[0] < PAIR_DONE_S:
                x = (now - pair_done[0]) / PAIR_DONE_S * 3.0          # three blinks, blue-white
                a = PAIR_LEVEL * 1.5 * math.sin(math.pi * (x - int(x))) ** 2
                pv = (a * 0.5, a * 0.7, a)
            elif pair_done[1] == "closed" and now - pair_done[0] < PAIR_END_S:
                a = PAIR_LEVEL * (1.0 - (now - pair_done[0]) / PAIR_END_S) ** 2
                pv = (0.0, 0.0, a)
            if pv is not None:
                r, g, b = (int(65535 * min(c, CEILING)) for c in pv)
                v = dev.vals
                for i in PAIR_LEDS:
                    v[3 * i], v[3 * i + 1], v[3 * i + 2] = r, g, b
                animating = True
            dev.icons[0], dev.icons[1] = iv
            # -- write a frame when something moves, or to refresh a static picture
            if dev.p is not None:
                cur = (iv[0], iv[1], tuple(dev.vals))
                lit = any(iv) or any(dev.vals)
                if lit or dev.lit:
                    if animating or cur != sent or now >= next_refresh:
                        if dev.send(now):
                            sent = cur
                            next_refresh = now + REFRESH_S
                            dev.lit = lit
                            if gstate == "play":
                                frames += 1
                        else:
                            sent = None
                            if gstate == "play":
                                anim.master = 0.0
                                gstate = "idle"
                                idle_since = now
                            want_state = True

            # (the first frames of a fade-in are still black and are not sent: report "play" once one is)
            if (want_state or now >= next_state) and not (gstate == "play" and not dev.lit and active):
                want_state = False
                next_state = now + (2.0 if gstate == "play" else 5.0)
                if not glow_on:
                    st = "off"
                elif gstate == "play":
                    st = "play" if active else "fade"
                else:
                    st = "idle" if dev.p is not None or not dev.fails else "nomcu"
                write_state({"state": st, "fps": FPS if gstate == "play" else 0, "frames": frames,
                             "errors": dev.errors, "retries": dev.retries,
                             "brightness": conf["brightness"], "palette": conf["palette"],
                             "source": source, "meter": 1 if have_meter else 0,
                             "colors": ",".join(hexcol(c) for c in anim.target),
                             "level": "%.3f" % (dev.level if gstate == "play" else level_for(conf["brightness"])),
                             "mcu": dev.hw or "", "mcu_ok": 1 if dev.p is not None else 0,
                             "art": art.note, "last_error": dev.last_err,
                             "touch": ("dryrun" if conf["dryrun"] else "on") if touch_on else "off",
                             "touch_armed": 1 if (dec is not None and dec.armed) else 0,
                             "touch_events": "up:%d down:%d playpause:%d next:%d prev:%d pair:%d ignored:%d" % (
                                 ev_count["up"], ev_count["down"], ev_count["playpause"],
                                 ev_count["next"], ev_count["prev"], ev_count["pair"], ev_count["reject"]),
                             "pairing": 1 if pairing else 0,
                             "touch_last": last_event, "actions": "%d run, %d dropped" % (act.ran, act.dropped)})

            # -- wait for the next tick (no catching up after a slow transfer)
            if animating:
                period = 1.0 / FPS
            elif touch_on and dev.p is not None:
                period = TOUCH_PERIOD
            else:
                period = 0.25
            deadline += period
            now = mono()
            if deadline < now - period or deadline > now + period:
                deadline = now + period if deadline > now + period else now
            while True:
                left = deadline - mono()
                if left <= 0.0005 or flags["stop"] or flags["reload"]:
                    break
                try:
                    r, _, _ = select.select([art.fd] if art.fd >= 0 else [], [], [], left)
                except (OSError, ValueError, InterruptedError):
                    break
                if r:
                    art.poll(mono())
    finally:
        # LEDs off, whatever happened
        try:
            if dev.p is None:
                dev.retry_at = 0.0
                if dev.lit:
                    dev.ready(mono())
            if dev.p is not None:
                if dev.lut is None:
                    dev.set_level(0.0)
                dev.black(tries=3)
        except Exception as e:
            log("could not switch the LEDs off: %s" % e)
        act.close()
        art.close()
        meter.close()
        write_state({"state": "stopped", "fps": 0, "frames": frames, "errors": dev.errors,
                     "brightness": conf["brightness"], "palette": conf["palette"], "touch": "off"})
        log("stopped after %d frames, %d MCU errors" % (frames, dev.errors))
    return 0


def bench():
    """time the per-frame work (no I/O) on this machine"""
    anim = Anim()
    dev = Dev()
    p = peppy.Peppy.__new__(peppy.Peppy)
    p.gamma = None
    p.load_gamma()
    dev.p = p
    dev.set_level(level_for(DEFAULT_BRIGHTNESS))
    m = MeterIn("/nonexistent")
    n = 20000
    t0 = time.perf_counter()
    for i in range(n):
        t = i / 30.0
        m.rms = 0.1 + 0.05 * math.sin(t); m.low = 0.08 * abs(math.sin(t * 6.3))
        m.mid = 0.04; m.high = 0.02; m.onset = 1.0 if i % 15 == 0 else 0.0
        anim.step(1 / 30.0, True, m)
    t1 = time.perf_counter()
    for i in range(n):
        anim.render(dev.lut, dev.vals)
    t2 = time.perf_counter()
    b = dev.buf
    for i in range(n):
        dev.PACK.pack_into(b, 4, 0, 0, *dev.vals)
        b[122] = 0
        b[122] = (-sum(b)) & 0xFF
    t3 = time.perf_counter()
    mt = MeterIn("/nonexistent")
    us = lambda a, c: (c - a) / n * 1e6
    total = us(t0, t3)
    print("per frame on this machine: step %.1f us, render %.1f us, pack+checksum %.1f us, total %.1f us"
          % (us(t0, t1), us(t1, t2), us(t2, t3), total))
    print("at %d fps: %.2f %% of one core here" % (FPS, total * FPS / 1e4))
    print("peak PWM value in the last frame: %d of 65535 (level %.3f)" % (max(dev.vals), dev.level))
    del mt
    return 0


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--bench":
        sys.exit(bench())
    if len(sys.argv) > 1:
        print(__doc__)
        sys.exit(0 if sys.argv[1] in ("-h", "--help") else 2)
    sys.exit(run())
