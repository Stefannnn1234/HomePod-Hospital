#!/usr/bin/python3
"""touch.py - turn the HomePod (1st gen) top panel's raw touch reports into
button events: volume up / down, play-pause, next, previous, long press.

The top-board MCU answers command 0x43 with one byte (0x04) while nothing is
going on, and with a 74-byte HID report (report id 1) while the surface is
being touched and for about a second afterwards:

    0      0x00
    1      report id (1)
    2..3   scan counter, LE16 (one scan is about 23 ms)
    6..9   MCU time stamp
    14..43 15 raw sensor counts, LE16 (baseline about 20000)
    44..73 15 baseline-subtracted deltas, signed LE16

Noise in the deltas stays within about +-35, crosstalk under 100; a finger
gives 250..680 on the sensors under it. Sensor map, from Nic's taps on a
real unit (recordings in test/touch-cap*.log):

    plus    sensors 6 and 8 (7 weaker)
    minus   sensors 12 and 13 (11 weaker)
    centre  sensor 10 (9 weaker)

This module is pure: no I/O, the caller passes in the time. glowd.py feeds it
one poll result per tick and acts on the events.

Events (tuples):
    ("down", zone)              a finger landed on "plus", "minus" or "centre"
    ("vol", +1 | -1, "tap")     released after a short touch of + or -
    ("vol", +1 | -1, "repeat")  + or - is being held (first after HOLD_DELAY,
                                then every REPEAT_PERIOD, HOLD_CAP at most)
    ("centre", n)               n short taps on the centre (n = 1, 2, 3...),
                                sent TAP_WINDOW after the last one
    ("longpress", "centre")     the centre has been held for LONG_S (sent once, while
                                the finger is still down; letting go then does nothing)
    ("reject", why)             a touch that was ignored: "palm", "slide",
                                "stuck", "stale", "gap", "long"

Volume up is the dangerous direction, so anything unclear produces nothing:
a second zone or many sensors at once (palm, wet hand), a touch that moves
to another zone, reports that stop arriving or stop changing, a touch that
is already there when the program starts, a hold longer than HOLD_CAP.
"""
import struct

NSENS = 15
REPORT_LEN = 74
PLUS, MINUS, CENTRE = "plus", "minus", "centre"

ON = 150.0            # zone score that starts a touch
OFF = 70.0            # ... and the score below which it has ended
DOMINANCE = 1.6       # the touched zone must beat the next one by this factor
PALM_LEVEL = 100      # a sensor counts as "covered" above this delta
PALM_COUNT = 5        # this many covered sensors = not a finger
SETTLE_S = 1.0        # ignore everything this long after start
GAP_S = 0.15          # no report for this long while touched = released
SPARSE_S = 0.30       # two looks at the panel further apart than this cannot be trusted
STALE_S = 0.30        # scan counter not moving for this long = dead data
TAP_MAX_S = 0.60      # longer than this is a hold, not a tap
LONG_S = 3.0          # centre held this long = long press (Bluetooth pairing window)
HOLD_DELAY = 0.40     # + / - held this long starts repeating
REPEAT_PERIOD = 0.25  # about 4 steps a second
HOLD_CAP = 8.0        # a hold never repeats for longer than this (stuck sensor)
TAP_WINDOW = 0.40     # wait this long after a centre tap for another one
QUIET_S = 0.30        # after a rejected touch, this much quiet before a new one counts

_DELTAS = struct.Struct("<15h")


def parse(report):
    """74-byte report -> (scan counter, tuple of 15 deltas), or None if it is not one"""
    if report is None or len(report) != REPORT_LEN or report[0] != 0 or report[1] != 1:
        return None
    return report[2] | report[3] << 8, _DELTAS.unpack_from(report, 44)


def scores(d):
    """deltas -> (plus, minus, centre) zone scores"""
    return (d[6] + d[8]) * 0.5, (d[12] + d[13]) * 0.5, float(d[10])


class Decoder:
    ZONES = (PLUS, MINUS, CENTRE)

    def __init__(self, now=0.0):
        self.t_start = now
        self.armed = False        # becomes True once the panel has been seen untouched
        self.zone = None          # zone being touched
        self.t_down = 0.0
        self.t_seen = 0.0         # last report that showed the touch
        self.t_feed = now         # last call of feed()
        self.repeats = 0
        self.next_repeat = 0.0
        self.long_fired = False   # this centre touch has already given its long press
        self.taps = 0             # centre taps collected so far
        self.tap_deadline = 0.0
        self.quiet_from = None    # after a rejected touch: untouched since then
        self.block = False        # a rejected touch is still down, or has only just lifted
        self.counter = None
        self.t_counter = now
        self.touched = False      # for the caller: something is on the panel right now
        self.n_reports = 0

    # -- one poll result -------------------------------------------------
    def feed(self, now, report):
        """report: 74 bytes, or None when the MCU had nothing. Returns a list of events."""
        ev = []
        gap = now - self.t_feed
        self.t_feed = now
        if gap > SPARSE_S and self.zone is not None:
            self._reject(ev, "gap", now)          # we were not looking; do not guess what happened

        p = parse(report)
        if p is None:
            self.touched = False
            if self.zone is not None and now - self.t_seen > GAP_S:
                self._release(ev, now)
            self._idle(ev, now, True)
            return ev
        cnt, d = p
        self.n_reports += 1
        if cnt != self.counter:
            self.counter = cnt
            self.t_counter = now
        elif now - self.t_counter > STALE_S:
            # the same scan over and over: the MCU's data is not live
            if self.zone is not None:
                self._reject(ev, "stale", now)
            self.touched = False
            self._idle(ev, now, False)
            return ev

        sc = scores(d)
        best = max(range(3), key=lambda i: sc[i])
        top = sc[best]
        second = max(sc[i] for i in range(3) if i != best)
        covered = sum(1 for v in d if v > PALM_LEVEL)
        other = max(d[0], d[1], d[2], d[3], d[4], d[5], d[14])
        palm = (covered >= PALM_COUNT or second >= ON or (other >= PALM_LEVEL and other > top)
                or (top >= ON and top < DOMINANCE * second))
        anything = top >= OFF or other >= ON or covered > 0
        self.touched = anything

        if self.zone is None:
            if not anything:
                self._idle(ev, now, True)
                return ev
            self.quiet_from = None
            if self.block:
                return ev                          # the rest of a rejected touch
            if not self.armed or now - self.t_start < SETTLE_S:
                self.block = True                  # it was there before we were; wait for it to lift
                return ev
            if palm:
                if top >= ON or other >= ON or covered >= PALM_COUNT:
                    self.block = True
                    ev.append(("reject", "palm"))
                return ev
            if top >= ON:
                self.zone = self.ZONES[best]
                self.t_down = self.t_seen = now
                self.repeats = 0
                self.long_fired = False
                self.next_repeat = now + HOLD_DELAY
                if self.zone != CENTRE:
                    self.taps = 0                  # a volume touch ends a centre tap sequence
                ev.append(("down", self.zone))
            return ev

        # -- a touch is in progress
        zi = self.ZONES.index(self.zone)
        if palm:
            self._reject(ev, "palm", now)
            return ev
        if sc[zi] < OFF:
            if top >= ON:
                self._reject(ev, "slide", now)     # the finger is on another zone now
            else:
                self._release(ev, now)
                self._idle(ev, now, not anything)
            return ev
        self.t_seen = now
        held = now - self.t_down
        if held > HOLD_CAP:
            self._reject(ev, "stuck", now)
            return ev
        if self.zone == CENTRE and not self.long_fired and held >= LONG_S:
            self.long_fired = True
            self.taps = 0
            ev.append(("longpress", CENTRE))
            return ev
        if self.zone != CENTRE and now >= self.next_repeat:
            self.repeats += 1
            self.next_repeat = max(self.next_repeat + REPEAT_PERIOD, now + REPEAT_PERIOD * 0.5)
            ev.append(("vol", 1 if self.zone == PLUS else -1, "repeat"))
        return ev

    # -- helpers -----------------------------------------------------------
    def _reject(self, ev, why, now):
        self.zone = None
        self.long_fired = False
        self.taps = 0
        self.block = True
        self.quiet_from = None
        ev.append(("reject", why))

    def _release(self, ev, now):
        zone, held = self.zone, self.t_seen - self.t_down
        self.zone = None
        if zone == CENTRE:
            if self.long_fired:
                self.long_fired = False
                self.taps = 0                      # the long press was the whole gesture
            elif held <= TAP_MAX_S:
                self.taps += 1
                self.tap_deadline = now + TAP_WINDOW
            else:
                self.taps = 0
                ev.append(("reject", "long"))
        elif self.repeats == 0:
            if held <= TAP_MAX_S:
                ev.append(("vol", 1 if zone == PLUS else -1, "tap"))
            else:
                ev.append(("reject", "long"))      # held, but our polling missed the repeat point

    def _idle(self, ev, now, untouched):
        if untouched:
            if not self.armed and now - self.t_start >= SETTLE_S:
                self.armed = True
            if self.block:
                if self.quiet_from is None:
                    self.quiet_from = now
                elif now - self.quiet_from >= QUIET_S:
                    self.block = False
                    self.quiet_from = None
        else:
            self.quiet_from = None
        if self.taps and self.zone is None and now >= self.tap_deadline:
            n, self.taps = self.taps, 0
            ev.append(("centre", n))


def replay(path, poll=0.033, decoder=None, t0=None):
    """Run a recording ("<seconds> <hex>" lines, changes only) through a decoder as the
    daemon would see it: one look every `poll` seconds, the MCU repeating its latest
    report until about a second after the last change. Returns [(time, event)]."""
    rec = []
    with open(path) as f:
        for ln in f:
            if ln.startswith("#"):
                continue
            p = ln.split(None, 1)
            if len(p) != 2 or p[1].startswith("ERR"):
                continue
            try:
                rec.append((float(p[0]), bytes.fromhex(p[1].strip())))
            except ValueError:
                pass
    if not rec:
        return []
    start = rec[0][0] if t0 is None else t0
    dec = decoder or Decoder(start - 2.0)
    out = []
    t = start - 1.5
    end = rec[-1][0] + 2.0
    i = 0
    cur = None
    t_cur = -1e9
    while t <= end:
        while i < len(rec) and rec[i][0] <= t:
            cur, t_cur = rec[i][1], rec[i][0]
            i += 1
        # the recording holds changes only; a report that is not replaced within 100 ms
        # means the MCU had gone back to "nothing" (the recorder logged that as 04)
        rep = cur if (cur is not None and len(cur) == REPORT_LEN and t - t_cur < 0.1) else None
        for e in dec.feed(t, rep):
            out.append((round(t, 3), e))
        t += poll
    return out


if __name__ == "__main__":
    import sys
    for path in sys.argv[1:]:
        print(path)
        for t, e in replay(path):
            print("  %8.3f  %s" % (t, " ".join(str(x) for x in e)))
