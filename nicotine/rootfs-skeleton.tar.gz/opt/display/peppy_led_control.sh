#!/bin/bash
# peppy_led_control.sh — Control HomePod volume button LEDs via I2C
#
# This script provides basic LED control for the HomePod's top display.
# The LEDs are driven by a TI TLC5971 LED driver which is controlled
# by the Cypress CY8C4245 PSoC (peppy MCU). All LED commands go
# through the PSoC via I2C.
#
# Usage: peppy_led_control.sh <command> [args...]
#
# Commands:
#   stop_blink          - Stop autonomous LED blinking (disable AutoLED)
#   start_blink         - Re-enable autonomous LED blinking
#   touch_on            - Enable touch sensing + disable AutoLED
#   touch_off           - Disable touch sensing + disable AutoLED
#   all_off             - Turn off everything (touch + AutoLED)
#   led_state <s> <i> <b> - Set LED state (state, indices_mask, brightness)
#   brightness <0-255>  - Set global LED brightness
#   gpio <set> <rst>    - GPIO control (set_mask, reset_mask)
#   version             - Read MCU firmware version
#   wake                - Wake the MCU
#   raw <cmd> [data...] - Send raw I2C command

set -e

PEPPY_ADDR=0x55
BUS="${PEPPY_BUS:-}"

find_bus() {
    for bus in /dev/i2c-*; do
        num="${bus#/dev/i2c-}"
        if i2cdetect -y -r "$num" 0x55 0x55 2>/dev/null | grep -q "55"; then
            echo "$num"
            return 0
        fi
    done
    return 1
}

if [ -z "$BUS" ]; then
    BUS=$(find_bus 2>/dev/null) || {
        echo "ERROR: Set PEPPY_BUS=<num> or ensure peppy is on an I2C bus"
        exit 1
    }
fi

send_cmd() {
    local cmd="$1"
    shift
    i2cset -y "$BUS" "$PEPPY_ADDR" "$cmd" "$@" 2>/dev/null
}

case "${1:-help}" in
    stop_blink)
        # Command 0x15, mode=0x01: TouchScan=1, AutoLED=0
        send_cmd 0x15 0x01
        echo "AutoLED disabled (blinking stopped)"
        ;;
    start_blink)
        # Command 0x15, mode=0x03: TouchScan=1, AutoLED=1
        send_cmd 0x15 0x03
        echo "AutoLED enabled (blinking will resume)"
        ;;
    touch_on)
        send_cmd 0x15 0x01
        echo "Touch sensing enabled, AutoLED disabled"
        ;;
    touch_off)
        send_cmd 0x15 0x00
        echo "Touch sensing disabled, AutoLED disabled"
        ;;
    all_off)
        send_cmd 0x15 0x00
        echo "All modes disabled"
        ;;
    led_state)
        # _setLEDState: state, indices, brightness
        # This may require multi-byte I2C writes
        state="${2:-0}"
        indices="${3:-0xff}"
        brightness="${4:-0x80}"
        echo "LED state control requires multi-byte I2C write."
        echo "The LED state command sends a data structure, not simple registers."
        echo "Try: i2cset -y $BUS 0x55 0x11 $state $indices $brightness i"
        i2cset -y "$BUS" "$PEPPY_ADDR" 0x11 "$state" "$indices" "$brightness" i 2>/dev/null && \
            echo "Sent." || echo "Failed (may need different format)"
        ;;
    brightness)
        bval="${2:-0x80}"
        echo "Setting global brightness to $bval..."
        echo "Note: Global brightness command format is not fully known."
        echo "The driver uses a complex protocol involving the 'Update'/'Update2' strings."
        ;;
    gpio)
        set_mask="${2:-0x00}"
        rst_mask="${3:-0x00}"
        # Command 0x20: GPIO control (3 bytes: data, 1 byte response)
        i2cset -y "$BUS" "$PEPPY_ADDR" 0x20 "$set_mask" "$rst_mask" 0x00 i 2>/dev/null && \
            echo "GPIO set=$set_mask reset=$rst_mask" || echo "GPIO command failed"
        ;;
    version)
        send_cmd 0x01
        echo -n "Version: "
        i2cget -y "$BUS" "$PEPPY_ADDR" 0x01 w 2>/dev/null || echo "(read failed)"
        ;;
    wake)
        send_cmd 0x01
        echo "Wake command sent"
        ;;
    raw)
        shift
        cmd="$1"
        shift
        if [ $# -eq 0 ]; then
            i2cset -y "$BUS" "$PEPPY_ADDR" "$cmd" 2>/dev/null
        else
            i2cset -y "$BUS" "$PEPPY_ADDR" "$cmd" "$@" i 2>/dev/null
        fi
        echo "Raw command $cmd sent"
        ;;
    help|*)
        echo "Usage: $0 <command> [args...]"
        echo ""
        echo "Commands:"
        echo "  stop_blink          Stop volume button LED blinking"
        echo "  start_blink         Resume autonomous LED blinking"
        echo "  touch_on            Enable touch, disable AutoLED"
        echo "  touch_off           Disable touch, disable AutoLED"
        echo "  all_off             Disable all modes"
        echo "  led_state <s> <i> <b>  Set LED state"
        echo "  gpio <set> <rst>    GPIO control"
        echo "  version             Read firmware version"
        echo "  wake                Wake the MCU"
        echo "  raw <cmd> [data...] Send raw I2C command"
        echo ""
        echo "Environment: PEPPY_BUS=<num> (default: auto-detect)"
        echo ""
        echo "I2C Command Reference:"
        echo "  0x01  Version Info / Wake"
        echo "  0x11  Set LED Multi-Display State"
        echo "  0x15  Set Touchpad Scan (bit0=Touch, bit1=AutoLED)"
        echo "  0x20  GPIO Control"
        echo "  0x23  Raw Command Passthrough"
        echo "  0x28  LED MD State Read"
        echo "  0x38  CLCG Data Read"
        echo "  0x39  CLCG Data Write (16 bytes)"
        ;;
esac
